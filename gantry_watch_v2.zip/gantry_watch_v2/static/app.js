"use strict";

/* ================================================================ helpers */
const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];
const AXES = ["gantry", "trolley", "hoist"];

function el(tag, attrs = {}, ...children) {
  const node = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (v === null || v === undefined || v === false) continue;
    if (k === "class") node.className = v;
    else if (k === "text") node.textContent = v;
    else if (k.startsWith("on")) node.addEventListener(k.slice(2), v);
    else node.setAttribute(k, v === true ? "" : v);
  }
  for (const c of children.flat()) if (c !== null && c !== undefined) node.append(c);
  return node;
}

async function api(method, url, body) {
  const opts = { method };
  if (body instanceof FormData) opts.body = body;
  else if (body !== undefined) {
    opts.headers = { "Content-Type": "application/json" };
    opts.body = JSON.stringify(body);
  }
  let res;
  try {
    res = await fetch(url, opts);
  } catch {
    throw { errors: ["Can't reach the analyzer. Check that its window is still open."] };
  }
  const data = await res.json().catch(() => ({}));
  if (!res.ok || data.ok === false) throw { errors: data.errors || [`Request failed (${res.status}).`] };
  return data;
}

let toastTimer;
function toast(msg, isError = false) {
  const t = $("#toast");
  t.textContent = msg;
  t.classList.toggle("error", isError);
  t.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => (t.hidden = true), isError ? 6000 : 2600);
}

function showProblems(box, errors, title) {
  if (!errors || !errors.length) { box.hidden = true; box.replaceChildren(); return; }
  box.replaceChildren(
    el("strong", { text: title || (errors.length === 1 ? "One thing needs fixing:" : `${errors.length} things need fixing:`) }),
    el("ul", {}, errors.map(e => el("li", { text: e })))
  );
  box.hidden = false;
}

function fmtSize(bytes) {
  if (bytes < 1024 * 1024) return `${Math.max(1, Math.round(bytes / 1024))} KB`;
  return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
}
function fmtTime(ts) {
  return new Date(ts * 1000).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}
function machineFromName(name) {
  const stem = name.replace(/\.[^.]+$/, "");
  const m = stem.match(/^[A-Za-z]+\d+/);
  return m ? m[0] : stem;
}

function askName(title, initial = "", okLabel = "Save") {
  const dlg = $("#nameDialog");
  $("#nameDialogTitle").textContent = title;
  $("#nameDialogOk").textContent = okLabel;
  const input = $("#nameDialogInput");
  input.value = initial;
  return new Promise(resolve => {
    dlg.addEventListener("close", () => resolve(dlg.returnValue === "ok" ? input.value.trim() : null), { once: true });
    dlg.showModal();
    input.select();
  });
}

/* ================================================================ state */
const state = {
  profiles: [],
  app: {},
  editing: null,       // profile name shown in the settings form
  savedSnapshot: "",   // JSON of last saved settings, for change tracking
  currentJob: null,
  pollTimer: null,
  codesLoaded: false,
};

/* ================================================================ tabs */
function showTab(name) {
  $$(".tabs button").forEach(b => b.setAttribute("aria-selected", b.dataset.tab === name));
  $$(".tab-panel").forEach(p => (p.hidden = p.id !== `tab-${name}`));
  if (name === "codes" && !state.codesLoaded) loadCodes();
  if (name === "data" || name === "reports") loadLibrary();
  history.replaceState(null, "", `#${name}`);
}
$$(".tabs button").forEach(b => b.addEventListener("click", () => showTab(b.dataset.tab)));
$$("[data-goto]").forEach(a => a.addEventListener("click", e => {
  e.preventDefault();
  showTab(a.dataset.goto);
  if (a.dataset.section) setTimeout(() => document.getElementById(a.dataset.section)?.scrollIntoView({ block: "start" }), 0);
}));

/* ================================================================ settings form */
const MOTION_ROWS = [
  ["acceleration_mps2", "Acceleration", "m/s²"],
  ["deceleration_mps2", "Deceleration", "m/s²"],
  ["top_speed_mps", "Top speed", "m/s"],
  ["offset_s", "Time offset", "s", "Extra time real moves take (ramps, control delay)"],
];
const THRESHOLD_FIELDS = [
  ["hoist_safe_height_m", "Hoist safe height", "m", "Below this height a lift (Step 4) before travel is expected. At or above it, a lift step counts as minor waste."],
  ["step_match_tolerance_m", "Position match tolerance", "m", "How close the final position must be to the reference to count as reached."],
  ["necessity_tolerance_m", "Necessity tolerance", "m", "How close a reposition must end to the next workorder's position to count as necessary."],
  ["aborted_min_target_distance_m", "Minimum distance for abort check", "m", "Moves with a shorter target distance are never judged aborted."],
  ["aborted_completion_pct", "Abort completion", "%", "A move covering less than this share of its target distance is flagged aborted."],
  ["performance_slow_threshold_pct", "Slow threshold", "%", "How much longer than expected a move may take before it's flagged slow."],
];
const POWER_FIELDS = [
  ["voltage_v", "Supply voltage", "V", "Used only for files without drive-voltage columns."],
  ["power_factor", "Power factor", "", "Between 0 and 1. Use the drive nameplate value."],
  ["cost_per_kwh", "Cost per kWh", "currency", "Leave empty to hide the cost columns in reports."],
];
const COLUMN_ROWS = [
  ["group", "Position"],
  ["reference", "Reference position", "Target position sent to the drive", "text"],
  ["actual_candidates", "Actual position", "First name found in the file is used", "list"],
  ["speed_candidates", "Speed", "For reference; speed is computed from position", "list"],
  ["group", "Power"],
  ["power_columns.current", "Drive current", "Drive 1, drive 2", "list"],
  ["power_columns.voltage", "Drive voltage", "Drive 1, drive 2 (same order as current)", "list"],
  ["power_columns.legacy", "Legacy drive current", "Older exports with no voltage columns", "list"],
];

// Two-column form row: label (220px) | field, with helper text under the field.
function formRow(id, label, field, help) {
  return el("div", { class: "form-row" },
    el("label", { class: "form-label", for: id, text: label }),
    el("div", { class: "form-field" }, field, help ? el("p", { class: "help", text: help }) : null));
}

function numberInput(path, unit, extra = {}) {
  const input = el("input", { type: "number", step: "any", "data-path": path, "data-kind": "number", ...extra });
  if (!unit) return input;
  return el("span", { class: "unit-input" }, input, el("span", { class: "unit", "data-unit": unit, text: unit }));
}

function buildSettingsForm() {
  const mBody = $("#motionTable tbody");
  for (const [key, label, unit, help] of MOTION_ROWS) {
    mBody.append(el("tr", {},
      el("th", { scope: "row" }, label, help ? el("small", { text: help }) : null),
      AXES.map(a => el("td", {}, numberInput(`axes.${a}.${key}`, unit, { "aria-label": `${a} ${label}`, min: "0" })))
    ));
  }

  const tGrid = $("#thresholdFields");
  for (const [key, label, unit, help] of THRESHOLD_FIELDS) {
    tGrid.append(formRow(`f-${key}`, label,
      numberInput(`thresholds.${key}`, unit, { id: `f-${key}`, min: "0", max: unit === "%" && key.startsWith("aborted") ? "100" : null }),
      help));
  }

  const pGrid = $("#powerFields");
  for (const [key, label, unit, help] of POWER_FIELDS) {
    pGrid.append(formRow(`f-${key}`, label,
      numberInput(`power.${key}`, unit === "currency" ? "USD" : unit, { id: `f-${key}`, min: "0", max: key === "power_factor" ? "1" : null }),
      help));
  }
  pGrid.append(formRow("f-currency", "Currency",
    el("input", { id: "f-currency", class: "w-sm", type: "text", maxlength: "8", "data-path": "power.currency", "data-kind": "text", placeholder: "AED" }),
    "Shown in report cost columns, e.g. AED, USD, EUR."));

  const cBody = $("#columnsTable tbody");
  for (const [key, label, help, kind] of COLUMN_ROWS) {
    if (key === "group") { cBody.append(el("tr", { class: "group" }, el("th", { colspan: "4", text: label }))); continue; }
    cBody.append(el("tr", {},
      el("th", { scope: "row" }, label, el("small", { text: help })),
      AXES.map(a => {
        const path = key.startsWith("power_columns")
          ? `columns.power_columns.${a}.${key.split(".")[1]}`
          : `columns.${key}.${a}`;
        const attrs = { "data-path": path, "data-kind": kind, spellcheck: "false", "aria-label": `${a} ${label}` };
        return el("td", {}, kind === "list"
          ? el("textarea", { ...attrs, rows: "2" })
          : el("input", { type: "text", ...attrs }));
      })
    ));
  }
}

function getPath(obj, path) { return path.split(".").reduce((o, k) => (o == null ? undefined : o[k]), obj); }
function setPath(obj, path, value) {
  const keys = path.split(".");
  let o = obj;
  keys.slice(0, -1).forEach(k => (o = o[k] ??= {}));
  o[keys.at(-1)] = value;
}

function fillForm(settings) {
  for (const input of $$("#settingsForm [data-path]")) {
    const v = getPath(settings, input.dataset.path);
    input.value = input.dataset.kind === "list" ? (v || []).join(", ") : (v ?? "");
    input.classList.remove("invalid");
  }
  for (const r of $$('input[name="expected_next_move_type"]')) r.checked = Number(r.value) === Number(settings.expected_next_move_type);
  updateCurrencyUnit();
}

function collectForm() {
  const out = {};
  for (const input of $$("#settingsForm [data-path]")) {
    let v = input.value.trim();
    if (input.dataset.kind === "list") v = v.split(/[,\n]/).map(s => s.trim()).filter(Boolean);
    else if (input.dataset.kind === "number") v = v === "" ? null : Number(v);
    setPath(out, input.dataset.path, v);
  }
  const r = $('input[name="expected_next_move_type"]:checked');
  out.expected_next_move_type = r ? Number(r.value) : 1;
  return out;
}

function updateCurrencyUnit() {
  const cur = ($('[data-path="power.currency"]').value || "").trim() || "—";
  $$('[data-unit="USD"]').forEach(u => (u.textContent = `${cur}/kWh`));
}

function setSaveStatus(kind, text) {
  const note = $("#dirtyNote");
  note.className = `save-status ${kind}`;
  note.textContent = text;
}

function markDirty() {
  const dirty = JSON.stringify(collectForm()) !== state.savedSnapshot;
  $("#saveBtn").disabled = !dirty;
  setSaveStatus(dirty ? "dirty" : "ok", dirty ? "Unsaved changes. Reports use the last saved settings." : "All changes saved.");
  return dirty;
}

function clientCheck() {
  let ok = true;
  for (const input of $$('#settingsForm [data-kind="number"]')) {
    const required = input.dataset.path !== "power.cost_per_kwh";
    const v = input.value.trim();
    const bad = (required && v === "") || (v !== "" && (Number.isNaN(Number(v)) || Number(v) < 0));
    input.classList.toggle("invalid", bad);
    if (bad) ok = false;
  }
  return ok;
}

async function loadProfileIntoForm(name) {
  const data = await api("GET", `/api/profiles/${encodeURIComponent(name)}`);
  state.editing = name;
  fillForm(data.settings);
  state.savedSnapshot = JSON.stringify(collectForm());
  $("#editProfileName").textContent = name;
  $("#deleteBtn").disabled = state.profiles.length <= 1;
  showProblems($("#settingsErrors"), []);
  markDirty();
}

async function saveProfile(name) {
  const box = $("#settingsErrors");
  if (!clientCheck()) {
    showProblems(box, ["Some fields are empty or not valid numbers. They're highlighted in red."]);
    setSaveStatus("error", "Not saved: fix the highlighted fields.");
    box.scrollIntoView({ block: "center" });
    return false;
  }
  try {
    const data = await api("PUT", `/api/profiles/${encodeURIComponent(name)}`, { settings: collectForm() });
    state.profiles = data.profiles;
    showProblems(box, []);
    return true;
  } catch (e) {
    showProblems(box, e.errors);
    setSaveStatus("error", `Not saved: ${e.errors.length === 1 ? e.errors[0] : `${e.errors.length} problems, listed above.`}`);
    box.scrollIntoView({ block: "center" });
    return false;
  }
}

async function setActiveProfile(name) {
  const data = await api("PUT", "/api/app-settings", { active_profile: name });
  state.app = data.app;
  renderProfileSelect();
  await loadProfileIntoForm(name);
}

function renderProfileSelect() {
  const sel = $("#activeProfile");
  sel.replaceChildren(...state.profiles.map(p => el("option", { value: p, text: p, selected: p === state.app.active_profile })));
}

$("#activeProfile").addEventListener("change", async e => {
  const name = e.target.value;
  if (markDirty() && !confirm(`Discard unsaved changes to "${state.editing}"?`)) {
    e.target.value = state.editing;
    return;
  }
  try { await setActiveProfile(name); loadLibrary(); toast(`Using profile "${name}"`); }
  catch (err) { toast(err.errors[0], true); }
});

$("#settingsForm").addEventListener("input", e => {
  if (e.target.dataset.path === "power.currency") updateCurrencyUnit();
  e.target.classList?.remove("invalid");
  markDirty();
});
$("#settingsForm").addEventListener("submit", e => e.preventDefault());

$("#saveBtn").addEventListener("click", async () => {
  if (await saveProfile(state.editing)) {
    await loadProfileIntoForm(state.editing);
    toast(`Saved "${state.editing}"`);
  }
});

$("#saveAsBtn").addEventListener("click", async () => {
  const name = await askName("Save as new profile", "", "Save profile");
  if (!name) return;
  if (state.profiles.includes(name) && !confirm(`"${name}" already exists. Overwrite it?`)) return;
  if (await saveProfile(name)) {
    await setActiveProfile(name);
    toast(`Saved "${name}" and switched to it`);
  }
});

function closeMenu() { $(".menu").open = false; }

$("#resetBtn").addEventListener("click", async () => {
  closeMenu();
  const data = await api("GET", "/api/defaults");
  fillForm(data.settings);
  markDirty();
  toast("Factory defaults loaded. Save to keep them.");
});

$("#exportBtn").addEventListener("click", () => {
  closeMenu();
  window.location = `/api/profiles/${encodeURIComponent(state.editing)}/xml`;
});

$("#importBtn").addEventListener("click", () => { closeMenu(); $("#importInput").click(); });
$("#importInput").addEventListener("change", async e => {
  const file = e.target.files[0];
  e.target.value = "";
  if (!file) return;
  const name = await askName("Import profile", file.name.replace(/\.xml$/i, "").replace(/[^A-Za-z0-9 _-]/g, "_").slice(0, 40), "Import");
  if (!name) return;
  if (state.profiles.includes(name) && !confirm(`"${name}" already exists. Overwrite it?`)) return;
  const fd = new FormData();
  fd.append("file", file);
  fd.append("name", name);
  try {
    const data = await api("POST", "/api/profiles/import", fd);
    state.profiles = data.profiles;
    await setActiveProfile(name);
    toast(`Imported "${name}"`);
  } catch (err) { showProblems($("#settingsErrors"), err.errors); }
});

$("#deleteBtn").addEventListener("click", async () => {
  closeMenu();
  const name = state.editing;
  if (!confirm(`Delete the profile "${name}"? This can't be undone.`)) return;
  try {
    const data = await api("DELETE", `/api/profiles/${encodeURIComponent(name)}`);
    state.profiles = data.profiles;
    state.app = data.app;
    renderProfileSelect();
    await loadProfileIntoForm(state.app.active_profile);
    toast(`Deleted "${name}"`);
  } catch (err) { toast(err.errors[0], true); }
});

/* application settings */
function fillAppSettings() {
  $("#appPort").value = state.app.port;
  $("#appNetwork").checked = !!state.app.allow_network;
  $("#appBrowser").checked = state.app.open_browser !== false;
}
$("#saveAppBtn").addEventListener("click", async () => {
  const port = Number($("#appPort").value);
  try {
    const data = await api("PUT", "/api/app-settings", {
      port, allow_network: $("#appNetwork").checked, open_browser: $("#appBrowser").checked,
    });
    const portChanged = data.app.port !== state.runningPort || data.app.allow_network !== state.app.allow_network;
    state.app = data.app;
    $("#appPort").classList.remove("invalid");
    toast(portChanged ? "Saved. Restart the analyzer to apply." : "Application settings saved");
  } catch (err) {
    $("#appPort").classList.add("invalid");
    toast(err.errors[0], true);
  }
});

window.addEventListener("beforeunload", e => {
  if (state.editing && markDirty()) { e.preventDefault(); e.returnValue = ""; }
});

/* ================================================================ dates */
function fmtDate(iso) {
  if (!iso) return "";
  const [y, m, d] = iso.split("-");
  return `${d}.${m}.${y}`;
}
function fmtDateTime(ts) {
  const d = new Date(ts * 1000);
  const p = n => String(n).padStart(2, "0");
  return `${p(d.getDate())}.${p(d.getMonth() + 1)}.${d.getFullYear()} ${p(d.getHours())}:${p(d.getMinutes())}`;
}
function addDays(iso, n) {
  const d = new Date(`${iso}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() + n);
  return d.toISOString().slice(0, 10);
}
function dateSpan(dates) {
  if (!dates.length) return "not analyzed yet";
  if (dates.length === 1) return fmtDate(dates[0]);
  return `${fmtDate(dates[0])} to ${fmtDate(dates.at(-1))}`;
}

/* ================================================================ PLC data tab */
state.library = { files: [], machines: [], lanes: [], dates: [] };
let libTimer = null;

function openFilePicker() { $("#fileInput").click(); }
const dz = $("#dropzone");
dz.addEventListener("click", openFilePicker);
dz.addEventListener("keydown", e => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); openFilePicker(); } });
$("#fileInput").addEventListener("change", e => { uploadFiles([...e.target.files]); e.target.value = ""; });
["dragenter", "dragover"].forEach(t => dz.addEventListener(t, e => { e.preventDefault(); dz.classList.add("over"); }));
["dragleave", "drop"].forEach(t => dz.addEventListener(t, e => { e.preventDefault(); dz.classList.remove("over"); }));
dz.addEventListener("drop", e => uploadFiles([...e.dataTransfer.files]));

function uploadFiles(files) {
  const err = $("#uploadError");
  err.hidden = true;
  const ok = files.filter(f => /\.(csv|xlsx|xls)$/i.test(f.name));
  const skipped = files.filter(f => !ok.includes(f));
  if (skipped.length) toast(`Skipped (not CSV or Excel): ${skipped.map(f => f.name).join(", ")}`, true);
  if (!ok.length) return;
  const existing = new Set(state.library.files.map(f => f.name.toLowerCase()));
  const replacing = ok.filter(f => existing.has(f.name.toLowerCase()));
  if (replacing.length && !confirm(`${replacing.map(f => f.name).join(", ")} ${replacing.length === 1 ? "is" : "are"} already uploaded. Replace with the new ${replacing.length === 1 ? "file" : "files"}?`)) return;

  const fd = new FormData();
  ok.forEach(f => fd.append("files", f, f.name));
  const total = ok.reduce((n, f) => n + f.size, 0);
  const box = $("#uploadProgress");
  const bar = $(".bar span", box);
  const text = $("p", box);
  box.hidden = false;
  bar.style.width = "0";
  text.textContent = `Uploading ${ok.length} file${ok.length === 1 ? "" : "s"} (${fmtSize(total)})…`;

  // XMLHttpRequest instead of fetch, for upload progress on large files.
  const xhr = new XMLHttpRequest();
  xhr.open("POST", "/api/files");
  xhr.upload.onprogress = e => { if (e.lengthComputable) bar.style.width = `${(100 * e.loaded / e.total).toFixed(0)}%`; };
  xhr.onload = () => {
    let data = {};
    try { data = JSON.parse(xhr.responseText); } catch { /* ignore */ }
    if (xhr.status !== 200 || data.ok === false) {
      box.hidden = true;
      err.textContent = (data.errors || [`Upload failed (${xhr.status}).`]).join(" ");
      err.hidden = false;
      return;
    }
    bar.style.width = "100%";
    text.textContent = `Uploaded ${data.added.length} file${data.added.length === 1 ? "" : "s"}. Analyzing now; you can keep working.`;
    setTimeout(() => (box.hidden = true), 4000);
    applyLibrary(data);
  };
  xhr.onerror = () => {
    box.hidden = true;
    err.textContent = "Upload failed. Check that the analyzer window is still open.";
    err.hidden = false;
  };
  xhr.send(fd);
}

const STATUS_TEXT = {
  ready: "Ready", analyzing: "Analyzing…", pending: "Waiting", error: "Couldn't analyze",
  outdated: "Settings changed", new: "New rows",
};
const STATUS_TIP = {
  outdated: "Analyzed with different settings. It's updated automatically when you build a report.",
  new: "New rows from the NAS. They're analyzed when a report needs them (or right away, if that's switched on in the NAS settings).",
  pending: "Queued for analysis.",
};

function renderFigures() {
  const lib = state.library;
  const box = $("#libFigures");
  box.hidden = !lib.files.length;
  if (!lib.files.length) return;
  const working = lib.files.filter(f => ["analyzing", "pending"].includes(f.status)).length;
  const errors = lib.files.filter(f => f.status === "error").length;
  const figs = [
    [lib.files.length, "PLC files"],
    [lib.machines.length, "Cranes"],
    [lib.lanes.length, "Lanes"],
    [lib.dates.length, "Days of data"],
    working ? [working, "Being analyzed"] : [errors, "Files with errors"],
  ];
  box.replaceChildren(...figs.map(([n, label]) =>
    el("div", { class: "figure" }, el("span", { class: "num", text: n }), el("span", { class: "lbl", text: label }))));
}

function renderLibrary() {
  const lib = state.library;
  renderFigures();
  const q = $("#libSearch").value.trim().toLowerCase();
  const rows = lib.files.filter(f => !q || [f.machine, f.lane, f.name, f.source === "nas" ? "nas" : "upload", ...f.dates.map(fmtDate)].some(v => v.toLowerCase().includes(q)));
  $("#libEmpty").hidden = lib.files.length > 0;
  $("#libTable").hidden = lib.files.length === 0;
  const working = lib.files.filter(f => ["analyzing", "pending"].includes(f.status)).length;
  $("#libSummary").textContent = lib.files.length
    ? `${lib.files.length} file${lib.files.length === 1 ? "" : "s"}, ${lib.machines.length} crane${lib.machines.length === 1 ? "" : "s"} in ${lib.lanes.length} lane${lib.lanes.length === 1 ? "" : "s"}` +
      (lib.dates.length ? `, ${dateSpan(lib.dates)}` : "") + (working ? `. Analyzing ${working}…` : "")
    : "";
  $("#libTable tbody").replaceChildren(...rows.map(f => el("tr", {},
    el("td", {}, el("span", { class: "machine-chip", text: f.machine })),
    el("td", {}, el("span", { class: "lane-tag", text: f.lane })),
    el("td", {}, f.source === "nas"
      ? el("span", { class: "src nas", text: "NAS", title: `Pulled from InfluxDB, machine ${f.nas_tag}. ${(f.rows || 0).toLocaleString()} rows.` })
      : el("span", { class: "src upload", text: "Upload" })),
    el("td", { class: "fname", title: f.name, text: f.name }),
    el("td", { class: "num", text: dateSpan(f.dates) }),
    el("td", { class: "num", text: f.n_moves ?? "" }),
    el("td", { class: "num", text: f.n_pickups ?? "" }),
    el("td", { class: "num", text: fmtDateTime(f.synced_at || f.uploaded_at) }),
    el("td", {}, el("span", { class: `state ${f.status}`, text: STATUS_TEXT[f.status] || f.status,
      title: f.status === "error" ? f.error : STATUS_TIP[f.status] || "" })),
    el("td", {}, el("button", { class: "icon-btn", title: "Delete this file", "aria-label": `Delete ${f.name}`, text: "×",
      onclick: async () => {
        const extra = f.source === "nas" ? " Rows older than 48 hours are not pulled again; use Pull again in the NAS settings to re-read them." : "";
        if (!confirm(`Delete ${f.name}? Its data will no longer be in reports.${extra}`)) return;
        try { applyLibrary(await api("DELETE", `/api/files/${f.id}`)); toast(`Deleted ${f.name}`); }
        catch (e) { toast(e.errors[0], true); }
      } }))
  )));
}
$("#libSearch").addEventListener("input", renderLibrary);

function applyLibrary(data) {
  const firstLoad = !state.library.loaded;
  state.library = { ...data, loaded: true };
  renderLibrary();
  renderFilters(firstLoad);
  const working = data.files.some(f => ["analyzing", "pending"].includes(f.status));
  clearTimeout(libTimer);
  if (working) libTimer = setTimeout(loadLibrary, 2000);
}
async function loadLibrary() {
  try { applyLibrary(await api("GET", "/api/files")); } catch { /* retried on next action */ }
}

/* ================================================================ Reports tab: filters */
const flt = { lanes: new Set(), machines: new Set(), machineTouched: false, includeTouched: false };

function modeValue() { return $('input[name="mode"]:checked').value; }

function updateModeHelp() {
  const period = modeValue() === "period";
  $("#modeHelp").textContent = period
    ? "One set for the whole date range, plus an overview with totals per day, per lane and per crane."
    : "One set per day: Summary, Operation and (optionally) a report per crane.";
  if (!flt.includeTouched) $("#optMachine").checked = !period;
  updateSelectionText();
}
$$('input[name="mode"]').forEach(r => r.addEventListener("change", updateModeHelp));
$("#optMachine").addEventListener("change", () => { flt.includeTouched = true; updateSelectionText(); });

function visibleMachines() {
  return state.library.machines.filter(m => !flt.lanes.size || flt.lanes.has(m.lane));
}

function daysInRange(m) {
  const a = $("#dateFrom").value, b = $("#dateTo").value;
  return m.dates.filter(d => (!a || d >= a) && (!b || d <= b)).length;
}

// Latest day that at least half the cranes have data for - skips a day that
// only holds a few minutes spilling over midnight from one crane's file.
function mainLatestDate() {
  const lib = state.library;
  const count = {};
  lib.machines.forEach(m => m.dates.forEach(d => (count[d] = (count[d] || 0) + 1)));
  const need = Math.max(1, Math.ceil(lib.machines.length / 2));
  return [...lib.dates].reverse().find(d => count[d] >= need) || lib.date_max;
}

function renderFilters(firstLoad) {
  const lib = state.library;
  const has = lib.machines.length > 0;
  $("#filtersEmpty").hidden = has;
  $("#filtersBody").hidden = !has;
  if (!has) return;

  if (lib.date_min) {
    for (const id of ["#dateFrom", "#dateTo"]) { $(id).min = lib.date_min; $(id).max = lib.date_max; }
    if (firstLoad || !$("#dateFrom").value) { const d = mainLatestDate(); $("#dateFrom").value = d; $("#dateTo").value = d; }
    $("#dataSpan").textContent = `Data available ${dateSpan(lib.dates)} (${lib.dates.length} day${lib.dates.length === 1 ? "" : "s"}).`;
  } else {
    $("#dataSpan").textContent = "Dates appear once the files are analyzed.";
  }

  // keep selections that still exist
  for (const l of [...flt.lanes]) if (!lib.lanes.includes(l)) flt.lanes.delete(l);
  const names = new Set(lib.machines.map(m => m.machine));
  for (const m of [...flt.machines]) if (!names.has(m)) flt.machines.delete(m);
  if (!flt.machineTouched) lib.machines.forEach(m => flt.machines.add(m.machine));

  $("#laneChips").replaceChildren(...lib.lanes.map(l => el("button", {
    type: "button", "aria-pressed": String(flt.lanes.has(l)), text: l, title: `Lane ${l}`,
    onclick: () => { flt.lanes.has(l) ? flt.lanes.delete(l) : flt.lanes.add(l); renderFilters(false); },
  })));
  renderCranes();
}

function renderCranes() {
  $("#craneGrid").replaceChildren(...visibleMachines().map(m => {
    const n = daysInRange(m);
    const input = el("input", { type: "checkbox", value: m.machine, checked: flt.machines.has(m.machine) });
    input.addEventListener("change", () => {
      flt.machineTouched = true;
      input.checked ? flt.machines.add(m.machine) : flt.machines.delete(m.machine);
      updateSelectionText();
    });
    return el("label", { class: n ? "" : "nodata", title: n ? `${n} day${n === 1 ? "" : "s"} of data in the selected dates` : "No data in the selected dates" },
      input, m.machine, el("small", { text: n ? `${n}d` : "–" }));
  }));
  updateSelectionText();
}

function selectedMachines() {
  return visibleMachines().filter(m => flt.machines.has(m.machine)).map(m => m.machine);
}

function updateSelectionText() {
  const a = $("#dateFrom").value, b = $("#dateTo").value;
  const cranes = selectedMachines();
  const withData = visibleMachines().filter(m => cranes.includes(m.machine) && daysInRange(m) > 0).length;
  let msg;
  if (!a || !b) msg = "Choose a start and end date.";
  else if (a > b) msg = "The start date is after the end date.";
  else if (!cranes.length) msg = "Select at least one crane.";
  else {
    const days = Math.round((new Date(b) - new Date(a)) / 86400000) + 1;
    const span = a === b ? fmtDate(a) : `${fmtDate(a)} to ${fmtDate(b)} (${days} days)`;
    msg = `${modeValue() === "period" ? "One period report" : "Daily reports"} for ${span}, ${cranes.length} crane${cranes.length === 1 ? "" : "s"}` +
      (withData < cranes.length ? `, ${withData} with data` : "") + ".";
  }
  $("#selectionText").textContent = msg;
  $("#buildBtn").disabled = !a || !b || a > b || !cranes.length;
}

["#dateFrom", "#dateTo"].forEach(id => $(id).addEventListener("change", renderCranes));
$$("[data-range]").forEach(b => b.addEventListener("click", () => {
  const lib = state.library;
  if (!lib.date_max) return;
  const r = b.dataset.range;
  const end = r === "all" ? lib.date_max : mainLatestDate();
  $("#dateTo").value = end;
  $("#dateFrom").value = r === "all" ? lib.date_min : r === "latest" ? end
    : [addDays(end, -(Number(r) - 1)), lib.date_min].sort().at(-1);
  renderCranes();
}));
$("#cranesAll").addEventListener("click", () => { flt.machineTouched = true; visibleMachines().forEach(m => flt.machines.add(m.machine)); renderCranes(); });
$("#cranesNone").addEventListener("click", () => { flt.machineTouched = true; visibleMachines().forEach(m => flt.machines.delete(m.machine)); renderCranes(); });

$("#buildBtn").addEventListener("click", async () => {
  const err = $("#buildError");
  err.hidden = true;
  if (state.editing && markDirty() &&
      !confirm(`"${state.editing}" has unsaved settings changes. Build with the last saved settings?`)) return;
  const visible = visibleMachines().map(m => m.machine);
  const chosen = selectedMachines();
  const all = chosen.length === visible.length;
  try {
    const data = await api("POST", "/api/reports", {
      mode: modeValue(), date_from: $("#dateFrom").value, date_to: $("#dateTo").value,
      lanes: [...flt.lanes], machines: all ? [] : chosen,
      include_machine_reports: $("#optMachine").checked, json: $("#optJson").checked,
    });
    startWatching(data.job);
    loadHistory();
  } catch (e) {
    err.textContent = e.errors.join(" ");
    err.hidden = false;
  }
});

/* ================================================================ Reports tab: results */
function isRunning(job = state.currentJob) {
  return job && ["queued", "running"].includes(job.status);
}

function startWatching(job) {
  state.currentJob = { ...job, log: [...(job.log || [])] };
  renderJob();
  clearInterval(state.pollTimer);
  if (isRunning()) state.pollTimer = setInterval(pollJob, 1000);
}

async function pollJob() {
  const job = state.currentJob;
  if (!job) return;
  try {
    const res = await fetch(`/api/reports/${job.id}?log_from=${job.log.length}`);
    if (!res.ok) throw new Error();
    const data = await res.json();
    state.currentJob = { ...data, log: job.log.concat(data.log) };
    renderJob();
    if (!isRunning()) {
      clearInterval(state.pollTimer);
      loadHistory();
      loadLibrary();
    }
  } catch {
    clearInterval(state.pollTimer);
    $("#statusLine").textContent = "Lost contact with the analyzer. Check that its window is still open, then refresh.";
  }
}

const KIND_LABEL = { overview: "Overview", summary: "Summary", operation: "Operation", machine: "Crane", json: "Raw data" };
const KIND_ORDER = { overview: 0, summary: 1, operation: 2, machine: 3, json: 4 };

function filtersSummary(f) {
  const lanes = f.lanes.length ? `lane${f.lanes.length === 1 ? "" : "s"} ${f.lanes.join(", ")}` : "all lanes";
  const cranes = f.machines.length ? f.machines.join(", ") : "all cranes";
  return `${cranes}; ${lanes}`;
}

function renderJob() {
  const job = state.currentJob;
  $("#resultEmpty").hidden = true;
  $("#resultBody").hidden = false;
  $("#resultTitle").textContent = job.title;
  $("#resultMeta").textContent = `${filtersSummary(job.filters)}. Profile "${job.profile}", built ${fmtDateTime(job.created)}.`;

  const pdfs = job.outputs.filter(o => o.name.endsWith(".pdf")).length;
  const groups = [...new Set(job.outputs.map(o => o.group))];
  const status = $("#statusLine");
  status.className = `status ${job.status === "queued" ? "running" : job.status}`;
  const text = {
    queued: "Waiting for earlier work to finish…",
    running: job.log.length ? job.log.at(-1).trim() : "Starting…",
    done: job.note || (pdfs
      ? `${pdfs} report${pdfs === 1 ? "" : "s"}` + (job.filters.mode === "daily" ? ` for ${groups.length} day${groups.length === 1 ? "" : "s"}` : "") +
        `, built in ${Math.max(1, Math.round(job.finished - job.started))} s`
      : "Finished, but no reports were produced. See the log."),
    failed: job.error || "Stopped. See the log.",
  }[job.status];
  status.replaceChildren(el("span", { class: "dot" }), el("span", { text }));

  showProblems($("#problems"), job.problems, job.problems.length ? "Some data couldn't be used:" : "");
  const zip = $("#zipAllBtn");
  zip.hidden = job.status !== "done" || !job.outputs.length;
  zip.href = `/api/reports/${job.id}/zip`;

  const byGroup = {};
  for (const o of job.outputs) (byGroup[o.group] ??= []).push(o);
  $("#groupBlocks").replaceChildren(...Object.keys(byGroup).sort().map(group => {
    const items = byGroup[group].sort((a, b) => KIND_ORDER[a.kind] - KIND_ORDER[b.kind] || (a.machine || "").localeCompare(b.machine || ""));
    return el("div", { class: "group-block" },
      el("header", {},
        el("h3", { text: items[0].group_label }),
        Object.keys(byGroup).length > 1
          ? el("a", { class: "btn small", href: `/api/reports/${job.id}/zip?group=${encodeURIComponent(group)}`, text: "Download day (.zip)" }) : null),
      items.map(o => {
        const url = `/api/reports/${job.id}/files/${o.relpath}`;
        return el("div", { class: "report-row" },
          el("span", { class: `kind ${o.kind}`, text: o.machine && ["machine", "json"].includes(o.kind) ? `${KIND_LABEL[o.kind]} ${o.machine}` : KIND_LABEL[o.kind] }),
          el("span", { class: "name", text: o.name, title: o.name }),
          el("span", { class: "actions" },
            o.name.endsWith(".pdf") ? el("a", { class: "btn small ghost", href: `${url}?view=1`, target: "_blank", rel: "noopener", text: "Open" }) : null,
            el("a", { class: "btn small", href: url, text: "Download" })));
      }));
  }));

  const logBox = $("#logBox");
  const atBottom = logBox.scrollTop + logBox.clientHeight >= logBox.scrollHeight - 8;
  logBox.textContent = job.log.join("\n");
  if (atBottom) logBox.scrollTop = logBox.scrollHeight;
  if (job.status === "failed") $("details.log").open = true;
}

async function loadHistory() {
  const data = await fetch("/api/reports").then(r => r.json());
  $("#historyPanel").hidden = !data.reports.length;
  const cur = state.currentJob && state.currentJob.id;
  $("#historyBody").replaceChildren(...data.reports.map(r => el("tr", { class: r.id === cur ? "current" : "" },
    el("td", {},
      el("div", { class: "title", text: r.title }),
      el("div", { class: "sub", text: `${filtersSummary(r.filters)}. Built ${fmtDateTime(r.created)}.` })),
    el("td", { class: "sub", text: r.status === "done" ? (r.outputs.length ? `${r.outputs.filter(o => o.name.endsWith(".pdf")).length} reports` : "no data") : r.status === "failed" ? "failed" : "building…" }),
    el("td", {},
      el("button", { class: "btn small", text: "Show", onclick: () => showReport(r.id) }),
      " ",
      el("button", { class: "btn small ghost", text: "Delete", disabled: isRunning(r), onclick: async () => {
        if (!confirm(`Delete "${r.title}"? You can build it again any time.`)) return;
        await api("DELETE", `/api/reports/${r.id}`);
        if (r.id === cur) { state.currentJob = null; $("#resultBody").hidden = true; $("#resultEmpty").hidden = false; }
        loadHistory();
      } })))));
  return data.reports;
}

async function showReport(id) {
  const data = await fetch(`/api/reports/${id}`).then(r => r.json());
  startWatching(data);
  loadHistory();
  window.scrollTo({ top: 0, behavior: "smooth" });
}

/* ================================================================ codes tab */
let codeGroups = [];
async function loadCodes() {
  try {
    const data = await api("GET", "/api/codes");
    codeGroups = data.groups;
    state.codesLoaded = true;
    $("#codesFile").textContent = data.file
      ? `From ${data.file}: ${data.groups.length} columns, ${data.groups.reduce((n, g) => n + g.codes.length, 0)} codes`
      : "No Columns_info file found. Built-in names are used for Step, MoveType and LandingType.";
    renderCodes();
  } catch (e) {
    $("#codesFile").textContent = e.errors[0];
  }
}

function highlight(text, q) {
  if (!q) return [text];
  const i = text.toLowerCase().indexOf(q);
  if (i < 0) return [text];
  return [text.slice(0, i), el("mark", { text: text.slice(i, i + q.length) }), text.slice(i + q.length)];
}

function renderCodes() {
  const q = $("#codesSearch").value.trim().toLowerCase();
  const filtered = codeGroups.map(g => ({
    ...g,
    codes: g.codes.filter(c => !q || String(c.code) === q || c.description.toLowerCase().includes(q)
      || g.column.toLowerCase().includes(q) || (g.plc_column || "").toLowerCase().includes(q)),
  })).filter(g => g.codes.length);
  const slug = s => `code-${s.toLowerCase().replace(/[^a-z0-9]+/g, "-")}`;
  $("#codeGroups").replaceChildren(...filtered.map(g =>
    el("a", { href: `#${slug(g.column)}` }, g.plc_column || g.column, el("span", { text: g.codes.length }))));
  const firstGroup = $("#codeGroups a");
  if (firstGroup) setCurrent($("#codeGroups"), firstGroup);
  $("#codeTables").replaceChildren(...(filtered.length ? filtered.map(g =>
    el("section", { class: "card", id: slug(g.column) },
      el("h2", { class: "card-title" }, g.plc_column || g.column,
        g.plc_column && g.plc_column.toLowerCase() !== g.column.toLowerCase()
          ? el("span", { class: "file-name", text: `"${g.column}" in Columns_info` }) : null),
      el("table", { class: "code-table" }, el("tbody", {},
        g.codes.map(c => el("tr", {}, el("td", { text: c.code }), el("td", {}, highlight(c.description, q)))))))
  ) : [el("p", { class: "lead", text: `Nothing matches "${q}".` })]));
}
$("#codesSearch").addEventListener("input", renderCodes);
$("#replaceCodesBtn").addEventListener("click", () => $("#codesInput").click());
$("#codesInput").addEventListener("change", async e => {
  const file = e.target.files[0];
  e.target.value = "";
  if (!file) return;
  const fd = new FormData();
  fd.append("file", file);
  try {
    await api("POST", "/api/codes", fd);
    state.codesLoaded = false;
    await loadCodes();
    toast("Code descriptions replaced");
  } catch (err) { toast(err.errors[0], true); }
});

/* ================================================================ NAS sync */
let nasSaved = "";            // form values as last saved, to spot unsaved changes
let nasFormLoaded = false;
let nasMachinesSaved = "";
let nasWasRunning = false;
let nasTimer = null;

function nasFormValues() {
  const out = {};
  $$("[data-nas]").forEach(i => {
    const k = i.dataset.nas;
    if (i.type === "checkbox") out[k] = i.checked;
    else if ("num" in i.dataset) out[k] = i.value === "" ? null : Number(i.value);
    else out[k] = i.value.trim();
  });
  const token = $("#nas-token").value.trim();
  if (token) out.token = token;
  return out;
}

function fillNasForm(d) {
  $$("[data-nas]").forEach(i => {
    const v = d[i.dataset.nas];
    if (i.type === "checkbox") i.checked = !!v; else i.value = v ?? "";
  });
  $("#nas-token").value = "";
  $("#nas-token").placeholder = d.token_set ? "Saved. Type a new token to replace it" : "InfluxDB API token";
  nasSaved = JSON.stringify(nasFormValues());
}

function nasDirty() { return JSON.stringify(nasFormValues()) !== nasSaved; }

function nasMsg(kind, text) {
  const m = $("#nasMsg");
  m.className = `nas-msg ${kind}`;
  m.textContent = text;
}

function fmtClock(ts) {
  const d = new Date(ts * 1000);
  const today = new Date().toDateString() === d.toDateString();
  const p = n => String(n).padStart(2, "0");
  return today ? `${p(d.getHours())}:${p(d.getMinutes())}` : fmtDateTime(ts);
}

function nasWhenText(d) {
  const ls = d.last_sync;
  let last = "Last sync: never";
  if (ls) {
    const text = (ls.message || "").replace(/\.$/, "");
    last = `Last sync: ${fmtClock(ls.finished)}, ${ls.status === "error" ? "failed: " + text : text}`;
  }
  let next;
  if (d.state.running) next = `Syncing now: ${d.state.step || "starting"}`;
  else if (!d.auto) next = "Next: automatic sync is off";
  else if (!d.configured) next = "Next: fill in the connection details";
  else next = `Next: ${fmtClock(d.next_sync_at)}`;
  return { last, next, failed: ls && ls.status === "error" };
}

function laneOf(crane) { const m = (crane || "").match(/^[A-Za-z]+/); return m ? m[0].toUpperCase() : "?"; }

function nasMachineRows() {
  return $$("#nasMachines tr[data-tag]").map(tr => ({
    tag: tr.dataset.tag, crane: $("input[type=text]", tr).value.trim(), enabled: $("input[type=checkbox]", tr).checked,
  }));
}

function renderNasMachines(machines) {
  const body = $("#nasMachines");
  if (!machines.length) {
    body.replaceChildren(el("tr", {}, el("td", { colspan: "7", class: "hint", text: "No machines yet. Fill in the connection details, then press Find machines." })));
  } else {
    body.replaceChildren(...machines.map(m => {
      const lane = el("span", { class: "lane-tag", text: laneOf(m.crane) });
      const crane = el("input", { type: "text", value: m.crane, maxlength: "30", spellcheck: "false", "aria-label": `Crane name for ${m.tag}` });
      crane.addEventListener("input", () => { lane.textContent = laneOf(crane.value); nasMachinesChanged(); });
      const on = el("input", { type: "checkbox", checked: m.enabled, "aria-label": `Sync ${m.tag}` });
      on.addEventListener("change", nasMachinesChanged);
      return el("tr", { "data-tag": m.tag },
        el("td", {}, on),
        el("td", {}, el("span", { class: "machine", text: m.tag }), m.error ? el("div", { class: "row-error", text: m.error }) : null),
        el("td", {}, crane),
        el("td", {}, lane),
        el("td", { class: "num", text: m.last_row || "not yet" }),
        el("td", { class: "num", text: (m.rows_total || 0).toLocaleString() }),
        el("td", {}, !m.last_row ? null : el("button", { type: "button", class: "btn small ghost", text: "Pull again",
          title: "Read this machine again from the first-sync date. Rows already stored are skipped.",
          onclick: async () => {
            if (!confirm(`Pull ${m.crane} again from the first-sync date on the next sync? Rows already stored are skipped.`)) return;
            try { renderNas(await api("POST", "/api/nas/machines/reset", { tag: m.tag }), { machines: true }); nasMsg("ok", `${m.crane} will be read again on the next sync.`); }
            catch (e) { nasMsg("error", e.errors.join(" ")); }
          } })));
    }));
  }
  nasMachinesSaved = JSON.stringify(nasMachineRows());
  $("#nasMachinesSave").disabled = true;
}

function nasMachinesChanged() {
  $("#nasMachinesSave").disabled = JSON.stringify(nasMachineRows()) === nasMachinesSaved;
}

function renderNasCard(d) {
  const card = $("#nasCard");
  const enabled = d.machines.filter(m => m.enabled).length;
  const w = nasWhenText(d);
  card.classList.toggle("error", !!w.failed && !d.state.running);
  if (!d.configured) {
    $("#nasCardText").textContent = "Pull PLC data straight from InfluxDB on the NAS instead of uploading files.";
  } else {
    const what = `${enabled} machine${enabled === 1 ? "" : "s"}, ${d.auto ? `every ${d.interval_min} min` : "automatic sync off"}.`;
    $("#nasCardText").textContent = `${what} ${w.last}. ${w.next}.`;
  }
  $("#nasCardSetup").textContent = d.configured ? "NAS settings" : "Set up";
  const sync = $("#nasCardSync");
  sync.hidden = !d.configured;
  sync.disabled = d.state.running;
  sync.textContent = d.state.running ? "Syncing…" : "Sync now";
}

function renderNas(d, force = {}) {
  state.nas = d;
  if (force.form || !nasFormLoaded) { fillNasForm(d); nasFormLoaded = true; }
  if (force.machines || $("#nasMachinesSave").disabled) renderNasMachines(d.machines);
  const w = nasWhenText(d);
  const when = $("#nasWhen");
  when.textContent = `${w.last}  •  ${w.next}`;
  when.style.color = w.failed && !d.state.running ? "var(--danger)" : "";
  $("#nasSyncBtn").hidden = d.state.running;
  $("#nasStopBtn").hidden = !d.state.running;
  $("#nasTokenHelp").textContent = d.token_set
    ? "A token is saved on this PC. Leave blank to keep it."
    : "Saved on this PC only. Leave blank to keep the saved token.";
  renderNasCard(d);
  if (nasWasRunning && !d.state.running) loadLibrary();  // a sync just finished
  nasWasRunning = d.state.running;
}

async function loadNas() {
  clearTimeout(nasTimer);
  try {
    renderNas(await api("GET", "/api/nas"));
  } catch { /* shown by the header status */ }
  nasTimer = setTimeout(loadNas, state.nas && state.nas.state.running ? 2000 : 15000);
}

async function nasAction(button, busyText, fn) {
  const all = ["#nasSaveBtn", "#nasTestBtn", "#nasFindBtn", "#nasSyncBtn"].map(id => $(id));
  all.forEach(b => (b.disabled = true));
  nasMsg("busy", busyText);
  try { await fn(); }
  catch (e) { nasMsg("error", (e.errors || [String(e)]).join(" ")); }
  finally { all.forEach(b => (b.disabled = false)); }
}

async function saveNas() {
  const d = await api("PUT", "/api/nas", nasFormValues());
  renderNas(d, { form: true });
  return d;
}

$("#s-nas").addEventListener("input", e => {
  if (!e.target.matches("[data-nas], #nas-token")) return;
  if (nasDirty()) nasMsg("dirty", "Unsaved NAS changes.");
  else if ($("#nasMsg").classList.contains("dirty")) nasMsg("ok", "");
});

$("#nasSaveBtn").addEventListener("click", () => nasAction(null, "Saving…", async () => {
  await saveNas();
  nasMsg("ok", "NAS settings saved.");
}));
$("#nasTestBtn").addEventListener("click", () => nasAction(null, "Testing the connection…", async () => {
  const r = await api("POST", "/api/nas/test", nasFormValues());
  nasMsg("ok", r.message + (nasDirty() ? " Save the settings to keep them." : ""));
}));
$("#nasFindBtn").addEventListener("click", () => nasAction(null, "Looking for machines…", async () => {
  const r = await api("POST", "/api/nas/find", nasFormValues());
  renderNas(r, { machines: true });
  nasMsg("ok", r.message + " Check the crane names below." + (nasDirty() ? " Save the NAS settings to keep the connection details." : ""));
}));
async function syncNow() {
  if (nasDirty()) {
    if (!confirm("Save the NAS settings first, then sync?")) return;
    await saveNas();
  }
  const r = await api("POST", "/api/nas/sync");
  renderNas(r);
  nasMsg("ok", r.started ? "Sync started. New rows are added to the PLC data tab as they arrive." : "A sync is already running.");
  loadNas();
}
$("#nasSyncBtn").addEventListener("click", () => nasAction(null, "Starting the sync…", syncNow));
$("#nasCardSync").addEventListener("click", async () => {
  try {
    const r = await api("POST", "/api/nas/sync");
    renderNas(r);
    toast(r.started ? "NAS sync started" : "A sync is already running");
    loadNas();
  } catch (e) { toast(e.errors.join(" "), true); }
});
$("#nasStopBtn").addEventListener("click", async () => {
  renderNas(await api("POST", "/api/nas/stop"));
  nasMsg("busy", "Stopping after the current request…");
});
$("#nasMachinesSave").addEventListener("click", async () => {
  try {
    renderNas(await api("PUT", "/api/nas/machines", { machines: nasMachineRows() }), { machines: true });
    nasMsg("ok", "Machines saved.");
  } catch (e) { nasMsg("error", e.errors.join(" ")); }
});

/* ================================================================ header: live status */
async function refreshLiveStatus() {
  const box = $("#liveStatus");
  try {
    const d = await fetch("/building/status").then(r => r.json());
    // Short text for the header; the full detail is in the tooltip.
    let text = "Ready", detail = `Ready. ${d.counters.items_today} file(s) analyzed today, ${d.counters.issues_today} issue(s).`;
    if (d.status === "working" && d.current_job) {
      const job = d.current_job;
      text = job.items_total > 1 ? `Working, ${job.items_done} of ${job.items_total}` : "Working";
      detail = `${job.step} (${job.items_done} of ${job.items_total})`;
    } else if (d.status === "error") {
      text = `Error: ${d.last_error || "see the log"}`;
      detail = text;
    }
    box.className = `live-status ${d.status}`;
    box.title = detail;
    box.replaceChildren(el("span", { text }));
  } catch {
    box.className = "live-status error";
    box.replaceChildren(el("span", { text: "Analyzer not reachable" }));
  }
}

/* ================================================================ header: company logo */
// Loads static/logo.svg, else static/logo.png; uses it as the favicon too.
// A mostly dark logo gets a small white plate in dark mode so it stays visible.
function loadLogo() {
  const img = $("#logo");
  const candidates = ["/static/logo.svg", "/static/logo.png"];
  const tryNext = () => {
    const src = candidates.shift();
    if (!src) return;
    img.onerror = tryNext;
    img.onload = () => {
      $("#logoPlate").hidden = false;
      $("#favicon").href = src;
      if (isDarkImage(img)) $("#logoPlate").classList.add("on-plate");
    };
    img.src = src;
  };
  tryNext();
}

function isDarkImage(img) {
  try {
    const c = document.createElement("canvas");
    const w = (c.width = 64), h = (c.height = Math.max(1, Math.round(64 * img.naturalHeight / Math.max(1, img.naturalWidth))));
    const ctx = c.getContext("2d");
    ctx.drawImage(img, 0, 0, w, h);
    const px = ctx.getImageData(0, 0, w, h).data;
    let sum = 0, n = 0;
    for (let i = 0; i < px.length; i += 4) {
      if (px[i + 3] < 128) continue; // ignore transparent pixels
      sum += 0.2126 * px[i] + 0.7152 * px[i + 1] + 0.0722 * px[i + 2];
      n++;
    }
    return n > 0 && sum / n < 110;
  } catch {
    return true; // can't measure: the plate is the safe choice
  }
}

/* ================================================================ sub-navigation (underline tabs) */
function setCurrent(nav, link) {
  $$("a", nav).forEach(a => a.setAttribute("aria-current", String(a === link)));
}
function trackSections(nav) {
  nav.addEventListener("click", e => { const a = e.target.closest("a"); if (a) setCurrent(nav, a); });
  if (!("IntersectionObserver" in window)) return;
  const links = $$("a", nav);
  const observer = new IntersectionObserver(entries => {
    const visible = entries.filter(e => e.isIntersecting).sort((a, b) => a.boundingClientRect.top - b.boundingClientRect.top);
    if (visible.length) {
      const link = links.find(a => a.getAttribute("href") === `#${visible[0].target.id}`);
      if (link) setCurrent(nav, link);
    }
  }, { rootMargin: "-60px 0px -60% 0px" });
  links.forEach(a => { const sec = document.getElementById(a.getAttribute("href").slice(1)); if (sec) observer.observe(sec); });
}

/* ================================================================ start */
(async function init() {
  buildSettingsForm();
  loadLogo();
  trackSections($("#settingsNav"));
  $("#codeGroups").addEventListener("click", e => { const a = e.target.closest("a"); if (a) setCurrent($("#codeGroups"), a); });
  setCurrent($("#settingsNav"), $("#settingsNav a"));
  refreshLiveStatus();
  setInterval(refreshLiveStatus, 5000);
  loadNas();
  try {
    const s = await api("GET", "/api/state");
    state.profiles = s.profiles;
    state.app = s.app;
    state.runningPort = s.running_port;
    renderProfileSelect();
    fillAppSettings();
    if (s.running_port && s.running_port !== s.app.port) {
      $("#portHelp").textContent = `Currently running on ${s.running_port}; ${s.app.port} applies after a restart. Avoid 5000, 5002, 5030 and 5050.`;
    }
    await loadProfileIntoForm(s.app.active_profile);
  } catch (e) {
    toast(e.errors ? e.errors[0] : "Couldn't load settings.", true);
  }
  updateModeHelp();
  await loadLibrary();
  try {
    const reports = await loadHistory();
    if (reports.length) await showReport(reports[0].id);
  } catch { /* no saved reports */ }
  const tab = location.hash.slice(1);
  if (["data", "reports", "settings", "codes"].includes(tab)) showTab(tab);
})();
