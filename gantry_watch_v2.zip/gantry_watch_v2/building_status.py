"""
building_status.py
===================
Read-only status page for the "Engineering Building" dashboard:

    GET /building/status  ->  JSON (see build_status() for the shape)

One "item" = one crane-day: a single PLC export (one crane, one day)
analyzed by the platform.

Rules this file follows so the page can never slow down or break the
analyzer:
  - the answer is cached for CACHE_SECONDS; most calls just return the cache;
  - it only reads what the analyzer already has in memory (no file reads,
    no analysis, never creates the library);
  - it never waits for a lock: if the library is busy writing, the last
    answer is served instead;
  - every error is caught; the page then answers with status "error" and the
    message, still with HTTP 200 and well within 100 ms.

Registered from app.py with: building_status.register(app, lambda: library)
"""
import threading
import time
from datetime import datetime

from flask import Blueprint, jsonify, request

PLATFORM_NAME = "PLC Crane Performance & Energy Analyzer"
CACHE_SECONDS = 5.0
ERROR_WINDOW_S = 3600  # an error newer than this, with nothing running, shows status "error"

# The people who would do this work by hand, in the order the work happens,
# for ONE item (one crane-day PLC export). "automated" = the platform does it.
TEAM = [
    {"role": "PLC Data Exporter",
     "description": "Downloads each crane's daily PLC log from InfluxDB on the NAS. Automated by the NAS "
                    "sync, which pulls new rows every 30 minutes with a read-only token.",
     "automated": True, "manual_minutes_per_item": 5},
    {"role": "Data Coordinator",
     "description": "Cleans each export (removes InfluxDB's annotation rows and result/table columns), "
                    "files it by crane, lane and date, and checks the columns are present.",
     "automated": True, "manual_minutes_per_item": 10},
    {"role": "Data Quality Analyst",
     "description": "Maps the position, reference, current and voltage columns, fills short signal "
                    "gaps, and splits moves that run past midnight onto the right day.",
     "automated": True, "manual_minutes_per_item": 20},
    {"role": "Motion Sequence Analyst",
     "description": "Rebuilds each workorder from MoveType and WorkorderIdent, decodes Step/StepInfo "
                    "codes, and flags abnormal step order, unneeded lifts and manual interventions.",
     "automated": True, "manual_minutes_per_item": 60},
    {"role": "Performance Analyst",
     "description": "Finds the axis that moved and compares actual move time with the expected time "
                    "from acceleration, deceleration, top speed and offset (perfect / slow / aborted).",
     "automated": True, "manual_minutes_per_item": 60},
    {"role": "Necessity Analyst",
     "description": "Checks whether each reposition ended where the next workorder started, whether "
                    "each pickup had a setdown, and groups unnecessary attempts into cases.",
     "automated": True, "manual_minutes_per_item": 45},
    {"role": "Energy Analyst",
     "description": "Calculates power and energy per drive and axis from current and voltage, and the "
                    "wasted energy and cost of unnecessary moves.",
     "automated": True, "manual_minutes_per_item": 30},
    {"role": "Report Writer",
     "description": "Produces the per-crane, summary, operation and period PDF reports with tables "
                    "and speed charts, filtered by dates, lanes and cranes.",
     "automated": True, "manual_minutes_per_item": 40},
    {"role": "Parameter Owner (Team Lead)",
     "description": "Sets and approves motion limits, thresholds, tariffs, column mappings and code "
                    "descriptions in Settings, and spot-checks verdicts.",
     "automated": False, "manual_minutes_per_item": 5},
    {"role": "Performance Engineer",
     "description": "Reads the reports, investigates repeat patterns with operations, maintenance and "
                    "automation, and follows up on actions.",
     "automated": False, "manual_minutes_per_item": 15},
]

_cache = {"at": 0.0, "body": None}
_cache_lock = threading.Lock()


def _start_of_today():
    now = datetime.now()
    return datetime(now.year, now.month, now.day).timestamp()


def build_status(library):
    """Builds the status answer from in-memory state only."""
    body = {"platform": PLATFORM_NAME, "status": "idle", "current_job": None,
            "counters": {"items_today": 0, "items_last_hour": 0, "issues_today": 0},
            "last_error": None, "team": TEAM}
    if library is None:  # analyzer still starting
        return body

    # Never wait on the library: if it's mid-write, serve the previous answer.
    if not library.lock.acquire(timeout=0.02):
        raise TimeoutError("library busy")
    try:
        files = [dict(f) for f in library.files.values()]
        jobs = [{k: j.get(k) for k in ("status", "finished", "error", "problems", "title")}
                for j in library.jobs.values()]
    finally:
        library.lock.release()

    now = time.time()
    today, hour_ago = _start_of_today(), now - 3600

    done = [f for f in files if f.get("analyzed_at")]
    body["counters"]["items_today"] = sum(1 for f in done if f["analyzed_at"] >= today)
    body["counters"]["items_last_hour"] = sum(1 for f in done if f["analyzed_at"] >= hour_ago)

    # Issues: files that couldn't be analyzed + report runs that failed or
    # skipped data, today.
    errors = [(f["analyzed_at"], f"{f['name']}: {f.get('error')}") for f in done
              if f.get("status") == "error" and f["analyzed_at"] >= today]
    for j in jobs:
        if (j.get("finished") or 0) >= today:
            if j.get("status") == "failed":
                errors.append((j["finished"], f"{j.get('title')}: {j.get('error')}"))
            for p in j.get("problems") or []:
                errors.append((j["finished"], f"{j.get('title')}: {p}"))
    issue = getattr(library, "sync_issue", None)
    if issue and issue[0] >= today:
        errors.append(issue)
    body["counters"]["issues_today"] = len(errors)
    if errors:
        body["last_error"] = max(errors)[1]

    progress = library.progress or getattr(library, "sync_progress", None)
    pending = sum(1 for f in files if f.get("status") in ("pending", "analyzing"))
    running = any(j.get("status") in ("queued", "running") for j in jobs)
    if progress or pending or running:
        body["status"] = "working"
        if progress:
            body["current_job"] = {"step": progress["step"], "items_done": int(progress["done"]),
                                   "items_total": int(max(progress["total"], progress["done"]))}
        else:
            body["current_job"] = {"step": "Waiting to start", "items_done": 0,
                                   "items_total": pending or 1}
    elif errors and max(errors)[0] >= now - ERROR_WINDOW_S:
        body["status"] = "error"
    return body


def _answer(get_library):
    now = time.time()
    if _cache["body"] is not None and now - _cache["at"] < CACHE_SECONDS:
        return _cache["body"]
    # Only one request rebuilds; the others get the previous answer meanwhile.
    have_lock = _cache_lock.acquire(blocking=False)
    if not have_lock:
        if _cache["body"] is not None:
            return _cache["body"]
        have_lock = _cache_lock.acquire(timeout=0.05)
    try:
        try:
            body = build_status(get_library())
        except Exception as e:  # noqa: BLE001 - this page must never fail
            if isinstance(e, TimeoutError) and _cache["body"] is not None:
                return _cache["body"]
            body = {"platform": PLATFORM_NAME, "status": "error", "current_job": None,
                    "counters": {"items_today": 0, "items_last_hour": 0, "issues_today": 0},
                    "last_error": f"Status page error: {e}", "team": TEAM}
        _cache["body"], _cache["at"] = body, time.time()
        return body
    finally:
        if have_lock:
            _cache_lock.release()


def register(app, get_library):
    """get_library: returns the running Library, or None while starting.
    Must NOT create the library (that would make this page slow)."""
    bp = Blueprint("building_status", __name__)

    @bp.route("/building/status", methods=["GET", "OPTIONS"])
    def building_status():
        try:
            if request.method == "OPTIONS":
                resp = app.response_class(status=204)
            else:
                resp = jsonify(_answer(get_library))
        except Exception as e:  # noqa: BLE001
            resp = jsonify({"platform": PLATFORM_NAME, "status": "error", "current_job": None,
                            "counters": {"items_today": 0, "items_last_hour": 0, "issues_today": 0},
                            "last_error": f"Status page error: {e}", "team": TEAM})
        # The building dashboard runs on another address, so allow it to read this.
        resp.headers["Access-Control-Allow-Origin"] = "*"
        resp.headers["Access-Control-Allow-Methods"] = "GET, OPTIONS"
        resp.headers["Access-Control-Allow-Headers"] = "*"
        resp.headers["Cache-Control"] = "no-store"
        return resp

    app.register_blueprint(bp)
