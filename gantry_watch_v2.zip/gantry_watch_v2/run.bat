@echo off
setlocal
cd /d "%~dp0"
title PLC Crane Performance and Energy Analyzer

where python >nul 2>nul
if errorlevel 1 (
    where py >nul 2>nul
    if errorlevel 1 (
        echo ERROR: Python was not found on this computer.
        echo Install Python 3.10 or newer from https://www.python.org/downloads/
        echo During install, tick "Add python.exe to PATH". Then double-click this file again.
        pause
        exit /b 1
    )
    set PYCMD=py
) else (
    set PYCMD=python
)

echo Checking required packages (the first run may take a minute) ...
%PYCMD% -m pip install -r requirements.txt --quiet --disable-pip-version-check
if errorlevel 1 (
    echo WARNING: could not check/install packages ^(no internet?^). Trying to start anyway ...
)

%PYCMD% app.py
echo.
echo The analyzer has stopped.
pause
