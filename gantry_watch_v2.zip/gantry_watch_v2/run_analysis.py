#!/usr/bin/env python3
"""
run_analysis.py - optional command-line run (no browser)
=========================================================
The normal way to use the analyzer is the web UI (run.bat / run.sh).
This script is for scheduled/automated runs. It uses a saved settings profile
and writes reports to the folder you name with --output (nothing is written
unless you ask for it).

    python3 run_analysis.py --input "path/to/plc files" --output "path/to/reports" \
        [--profile "Default"] [--mode daily|period] [--json]
"""
import argparse
import os
import sys

ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(ROOT, "src"))

from settings_store import SettingsStore  # noqa: E402
from orchestrator import discover_input_files  # noqa: E402
from pipeline import run_pipeline, apply_columns_info  # noqa: E402
from app import columns_info_path  # noqa: E402


def main():
    store = SettingsStore(ROOT)
    p = argparse.ArgumentParser(description="PLC analysis without the web UI")
    p.add_argument("--input", required=True, help="Folder with PLC .csv/.xlsx files")
    p.add_argument("--output", required=True, help="Folder to write reports into")
    p.add_argument("--profile", default=store.load_app_settings()["active_profile"],
                   help=f"Settings profile (available: {', '.join(store.list_profiles())})")
    p.add_argument("--mode", choices=["daily", "period"], default="daily",
                   help="daily = one set per day; period = one set for everything found")
    p.add_argument("--json", action="store_true", help="Also write raw results as JSON")
    a = p.parse_args()

    if not os.path.isdir(a.input):
        sys.exit(f"ERROR: input folder not found: {a.input}")
    files = discover_input_files(a.input)
    if not files:
        sys.exit(f"No PLC data files found in '{a.input}'.")
    apply_columns_info(columns_info_path())
    print(f"Profile: {a.profile}. Found {len(files)} file(s).")
    run_pipeline(files, store.load_profile_config(a.profile), a.output, write_json=a.json, mode=a.mode)


if __name__ == "__main__":
    main()
