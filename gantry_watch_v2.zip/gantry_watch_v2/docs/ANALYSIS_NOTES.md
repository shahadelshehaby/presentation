> **Note:** this is the original project README, kept for its explanation of how the analysis works (sections 5-12). The "how to run" and "Daily Reports" parts are replaced by the web UI - see the main README.md.

# MoveType=3 PLC Analyzer — Multi-Machine, Multi-Day

> **This revision — what changed and why**
> 1. **Wasted-energy cost.** `config/golden_standard.xml` now has a
>    `<cost_per_kwh>` (and `<currency>`) setting under `<power>`. Reports show
>    a Cost column wherever energy appears: **cost = energy_kWh × cost_per_kwh
>    directly** — `total_energy_kwh` is already an integrated (time × power)
>    quantity (see `src/power_agent.py`'s trapezoidal integration), so do
>    **not** multiply by duration again; that would double-count time.
>    Leave `<cost_per_kwh>` blank/remove it to hide the cost columns.
> 2. **No more literal "nan" in reports.** A handful of blank cells in the
>    Current/Voltage columns used to poison an entire move's energy total
>    (a running-sum bug — see `src/power_agent.py`). Sporadic gaps are now
>    interpolated from neighbouring readings; if an axis has genuinely NO
>    usable readings for a move at all, the report says **"no consumption
>    data"** instead of a numeric 0 or "nan" — a real 0 means "measured and
>    it was zero", which is a different fact from "nothing to measure".
> 3. **Unnecessary MoveType=1/2 (pickup/setdown) workorders now join the
>    MoveType=3 case grouping and illustration.** A "case" in the Operation
>    report is now a single chronological run of events — MoveType=3
>    repositions AND pickup/setdown workorders — ending at the first
>    genuinely completed outcome (a real pickup after a reposition, or a
>    completed pickup+setdown cycle). Example: reposition (unnecessary) →
>    reposition (unnecessary) → pickup with no setdown (unnecessary) →
>    pickup+setdown (necessary, closes the case) is now ONE case. Each
>    case's move table in the Operation report is split into two sections:
>    **"Unnecessary attempts"** first, then the **"Necessary / closing
>    move"** (highlighted green) — see `src/operation_agent.py` and
>    `src/report_operation.py`.

A standalone Python project (no Jupyter notebook needed) that analyzes
MoveType=3 ("move-only") crane moves from 1-second PLC CSV exports, across
any number of machines and days, and writes one PDF report per machine per
day plus one daily cross-machine summary.

Three independent agents evaluate every move:

| Agent | File | Question it answers |
|---|---|---|
| **Sequence** | `src/sequence_agent.py` | Did the Step/StepInfo transitions follow the normal 3→4→5→6 pattern, with correct handling of MIs and lift-height waste? |
| **Performance** | `src/performance_agent.py` | Given this move's own travel distance, was the speed/time profile normal, slow, or aborted? |
| **Necessity** | `src/necessity_agent.py` | Did this move actually pre-position the crane for what the next workorder needed? |

`src/orchestrator.py` is the point where, for each MoveType=3 move, the three
agents' independent results get combined into one `MoveType3Result`.
`src/report_machine.py` turns that combined result into the per-machine PDF
("master report" for that machine/day). `src/report_summary.py` rolls every
machine's results for a day up into the daily Summary PDF.

## 1. Project layout

```
plc_move3_analyzer/
├── RUN_ANALYSIS.bat              <- double-click on Windows
├── RUN_ANALYSIS.command          <- double-click on Mac
├── RUN_ANALYSIS.sh               <- double-click on Linux
├── run_analysis.py               <- what the above actually run (command-line entrypoint)
├── requirements.txt
├── config/
│   └── golden_standard.xml      <- EDIT THIS to tune the machine's numbers
├── Columns_info.csv / .xlsx     <- column/enum reference, auto-detected
├── PLC data/                    <- put your machine files here (.csv or .xlsx)
│   ├── A205_2026-07-01.xlsx
│   ├── A206_2026-07-01.xlsx
│   └── A205_2026-07-02.xlsx
├── Daily Reports/                <- generated automatically
│   ├── 2026-07-01/
│   │   ├── A205_2026-07-01.pdf
│   │   ├── A206_2026-07-01.pdf
│   │   └── Summary_2026-07-01.pdf
│   └── 2026-07-02/
│       ├── A205_2026-07-02.pdf
│       └── Summary_2026-07-02.pdf
└── src/
    ├── config_loader.py          config/golden_standard.xml -> Python objects
    ├── columns.py                 enum names + dynamic axis-column resolution
    ├── data_loader.py             CSV/Excel load, timestamp parsing, workorder/phase split
    ├── sequence_agent.py          Agent 1
    ├── performance_agent.py       Agent 2
    ├── necessity_agent.py         Agent 3
    ├── orchestrator.py            runs all 3 agents per move, discovers input files
    ├── pdf_style.py                shared reportlab fonts/margins/colors
    ├── category_breakdown.py      shared Necessity x Performance table (machine + summary reports)
    ├── performance_chart.py       expected-vs-actual speed chart (matplotlib -> embedded PNG)
    ├── report_machine.py          per-machine-per-day PDF (combines all 3 agents)
    ├── report_summary.py          per-day cross-machine Summary PDF
    └── utils.py                    machine-name parsing, HH:MM:SS formatting
```

## 2. How to run

### Option A — double-click (no command line)

1. Make sure [Python 3.10+](https://www.python.org/downloads/) is installed
   on the computer (during install on Windows, tick **"Add python.exe to
   PATH"**). This is a one-time setup step per computer.
2. Put your machine files in `PLC data/`.
3. Double-click:
   - **Windows:** `RUN_ANALYSIS.bat`
   - **Mac:** `RUN_ANALYSIS.command`
   - **Linux:** `RUN_ANALYSIS.sh`

A console window opens, shows progress, and closes only after you press a
key — so you can always read what happened. Reports land in `Daily
Reports/<date>/`. Nothing else to type or run.

If Windows shows a "Windows protected your PC" SmartScreen prompt the first
time (common for any downloaded .bat/.command file), click **More info →
Run anyway**.

### Option B — command line

```bash
cd plc_move3_analyzer
pip install -r requirements.txt

python3 run_analysis.py \
    --input "PLC data" \
    --output "Daily Reports" \
    --config "config/golden_standard.xml" \
    --json          # optional: also dumps each machine's raw results as JSON
```

Both options do exactly the same thing — the double-click files just run
this same command for you.

Every CSV or Excel (.xlsx/.xls) file directly inside `PLC data/` is treated
as one machine, one day. Drop in as many equipment files as you like; `Daily
Reports/<date>/` folders are created automatically, one per date actually
found in the data (derived from the file's own `PLCTime` column, not just
the filename).

## 3. Columns_info (column code → description)

Drop `Columns_info.csv` or `Columns_info.xlsx` directly in the project
folder (next to `run_analysis.py`) and it's picked up automatically every
run — you'll see `Loaded column code descriptions from '...'` printed at the
top of the output. No path needs to be typed in; auto-detection checks for
`Columns_info.csv` / `.xlsx` / `.xls` (a few common spelling/casing variants
too). If it's missing, the program falls back to its own built-in Step /
MoveType / LandingType name tables and still works fine.

This file's own `column` values (`step`, `Landing `, `order`, `target`, etc.)
are mapped internally to the real PLC column names (`Step`, `LandingType`,
`MoveType`, `TargetType`) — you don't need to rename anything in your file.

## 4. Input file naming

Put one file per machine per day directly inside `PLC data/` — CSV or Excel,
either is fine (flat folder, same as the original project's "flat" layout).
The machine name is parsed from the leading letters+digits of the filename:

```
A205_2026-07-01.csv    -> machine "A205"
A205_2026-07-01.xlsx   -> machine "A205"
RMG12_dump.xlsx        -> machine "RMG12"
```

If a file doesn't match that pattern, the whole filename (minus the
extension) is used as the machine name — nothing crashes, it just won't
group as neatly.

## 5. Editing the golden-standard config

`config/golden_standard.xml` is the only file you should need to touch to
retune the system. It replaces the old "fit acceleration/deceleration/top
speed from a golden example CSV" step — since you already know these numbers
for your crane, just type them in:

```xml
<axis name="gantry">
  <acceleration_mps2>0.15</acceleration_mps2>
  <deceleration_mps2>0.15</deceleration_mps2>
  <top_speed_mps>3.00</top_speed_mps>
  <offset_s>2.5</offset_s>
</axis>
```

- `offset_s` is the fixed amount real moves take longer than the idealized
  instant-acceleration kinematic estimate (jerk-limited ramps + control-loop
  delay). If you don't know it, start at 0 and adjust after comparing a few
  reports against moves you trust.
- The file also holds every other tunable threshold (hoist safe height,
  necessity tolerance, abort-completion %, etc.) and the column-name
  candidate lists used to dynamically resolve each axis's actual-position
  column (handles `In_GANTRY1` / `GantryPos` / `In_GANTRY` naming differences
  across exports — add a new `<candidate>` line any time a new export uses a
  different name, no code changes required).

No re-running of a "build golden standard" script is needed — every run
reads this file fresh.

## 6. What "necessary" / "aborted" / "issue" mean

- **Sequence** flags: `normal`, `minor_waste` (Step 4 triggered but hoist was
  already ≥ safe height), `manual_intervention` (operator took over),
  `abnormal` (step out of order, or Step 4 triggered mid-sequence while
  already high enough).
- **Performance** verdicts: `perfect` (within the configured slow-threshold
  % of the expected time for that move's own distance), `issue` (slower than
  that), `aborted` (traveled well short of its intended distance — judged on
  actual distance traveled, never the original target distance), or
  `no_movement` (never reached Step 5/6 at all).
- **Necessity** verdicts: `necessary` (this move's ending position lines up
  with the next workorder's reference within tolerance) or `unnecessary`
  (it doesn't) — `unknown` if there's no following workorder in the file to
  check against (e.g. the very last workorder).

A move is flagged `REVIEW` in the exec-summary table if it has any abnormal
sequence step, a performance issue/abort, or is judged unnecessary.

## 7. Deviations from the original single-file reference project

These were deliberate simplifications/clarifications for this rebuild —
flagged here so nothing is a silent surprise:

- **No golden-example curve fitting.** Replaced entirely by the XML config
  (Section 5). If you'd rather fit accel/decel/top-speed from a trusted CSV
  again later, that logic can be re-added as a small script that writes into
  the same XML format — the three agents don't care how the numbers got there.
- **Folder/file names use `YYYY-MM-DD`, not `DD/MM/YYYY`.** A `/` cannot
  appear in a filename or folder name on virtually any filesystem, so dates
  are rendered like `2026-07-01` (matching the PLCTime format already used
  throughout the source data) instead of `01/07/2026`.
- **MoveType=1/2 workorders are never analyzed themselves** — exactly as in
  the original doc, they're only used as "next workorder" context for the
  Necessity agent.

## 9. Recent fixes / additions

- **Multi-day files.** A file that happens to span midnight (or several
  days) used to get filed under a single wrong date. Each move is now dated
  by its own phase's start time, so a file covering, say, June 29 - July 1
  correctly produces three separate `Daily Reports/<date>/` folders instead
  of one.
- **Table header wrapping.** Column headers like "Duration (s)" no longer
  visually run into the next column - headers now wrap properly within
  their own column width.
- **Performance chart.** Each workorder's Performance section now includes
  an expected-vs-actual speed chart (dashed = expected, solid = actual) for
  the dominant axis, real elapsed seconds on the x-axis. Built from the same
  `expected_time_s` / distance data already computed by the Performance
  agent - see `src/performance_chart.py`.
- **Manual intervention highlighting.** MI rows in the Step Sequence table
  now get their own light-blue row background, distinct from the yellow
  (minor waste) and red (abnormal) highlighting.
- **Move Category Breakdown per machine.** Each machine's own PDF now
  includes its own Necessity x Performance breakdown table (previously this
  only existed in the daily Summary).
- **Summary report restructured:** page 1 is the Per-Machine Rollup (as
  before); page 2 is now *only* the Move Category Breakdown, shown as one
  table per machine that reported that day.

## 8. Extending to more machines / more days

Nothing to configure — just keep dropping `MACHINE_DATE.csv` files into
`PLC data/` and re-run `run_analysis.py`. Each date automatically gets its
own subfolder under `Daily Reports/`, containing one PDF per machine that
reported that day plus one `Summary_<date>.pdf` and one `Operation_<date>.pdf`.

## 10. Power / Energy estimation (new)

`src/power_agent.py` estimates power and energy from the six drive-current
columns (`In_GANTRYDRIVE1/2`, `In_TROLLEYDRIVE1/2`, `In_HOISTDRIVE1/2`) — the
log has no voltage or power-factor channel, so a 3-phase AC power estimate is
used:

```
P_kW = sqrt(3) * voltage_v * (drive1_A + drive2_A) * power_factor / 1000
```

`voltage_v` and `power_factor` are configured in `config/golden_standard.xml`
(`<power>` section, defaults 400V / 0.85) — these are **assumptions**; edit
them to your crane's real nameplate values for accurate kWh figures. Energy
per phase is the trapezoidal integration of total power (summed across all
three axes) over the phase's elapsed time.

Every `MoveType3Result` now carries a `power` field and a `wasted_energy_kwh`
property (the move's full energy if — and only if — it was judged
**confirmed unnecessary**; `unknown`-necessity moves are never counted as
waste since there's no way to confirm they achieved nothing). Both the
per-machine report and the daily Summary now show total and wasted energy
columns/totals; per-workorder detail pages show the axis-by-axis energy
breakdown too.

## 11. Performance chart unit — m/min, not m/s

`src/performance_chart.py`'s expected-vs-actual speed chart now plots
**metres/minute**, not metres/second — this is a display-only change (a x60
multiply at chart-drawing time); the underlying kinematics, expected-time
calculation, and all other numbers in `golden_standard.xml` are still
defined and computed in m/s internally.

## 12. Operation report (new) — `Operation_<date>.pdf`

A new report focused purely on **necessity** and **wasted energy**, grouped
into **cases** (`src/operation_agent.py`):

- A case is a run of moves that starts right after the previous case ended
  and ends at (and includes) the first move judged **necessary** — e.g. 3
  unnecessary repositions followed by a necessary 4th move are grouped as
  one case, since the unnecessary moves only make sense in the context of
  what they were eventually "for". A move with `unknown` necessity (no
  following workorder, typically the last move of the day) does not close a
  case, since there's nothing to confirm it against. If a machine's data
  ends mid-case (no necessary move ever closes it), that trailing run is
  still reported as a final, "open" case rather than silently dropped.
- Necessity is shown alone here (necessary / unnecessary / unknown) — no
  performance good/bad split, since that's covered by the other reports.
- Page 1: a per-machine case rollup (cases, moves, necessary/unnecessary/
  unknown counts, total distance, total energy, wasted energy) plus a
  multi-machine ("N RMGs") chart (`src/operation_chart.py`) — one subplot
  per machine, showing cumulative distance traveled over the day, colored
  green/red/grey by necessity verdict, with dashed lines marking where each
  case ends.
- One section per case per machine after that: a per-move table (workorder,
  time, duration, axis, necessity, distance, energy) plus a case-level chart
  of cumulative distance for just that case's moves.
- Cumulative *distance* (not raw axis position) is charted throughout,
  since a case's moves can be driven by different dominant axes
  (gantry/trolley/hoist) — plotting distance avoids mixing incompatible
  position scales on one axis while still showing how far, and when, the
  crane actually moved.
