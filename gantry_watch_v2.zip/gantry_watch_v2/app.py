#!/usr/bin/env python3
"""
app.py - PLC Analyzer web UI
=============================
Start with run.bat (Windows) / run.sh (Mac/Linux), or:

    python app.py              # uses the port saved in Settings (default 8765)
    python app.py --port 8800  # another port, this start only

Then open http://localhost:<port> (opens automatically).

Uploaded PLC files and their analysis are kept in analyzer_data/ so they are
still there next time. Reports are built on demand from your filters (dates,
cranes, lanes, daily or period) and downloaded from the browser.
Ports 5000, 5002, 5030 and 5050 are refused on purpose.
The Engineering Building dashboard reads GET /building/status (building_status.py).
"""
import argparse
import glob
import io
import logging
import os
import shutil
import socket
import sys
import threading
import time
import webbrowser
import zipfile

PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(PROJECT_ROOT, "src"))

from flask import Flask, jsonify, request, send_file, send_from_directory, abort, Response  # noqa: E402

from settings_store import SettingsStore, SettingsError, FORBIDDEN_PORTS  # noqa: E402
from library import Library  # noqa: E402
from nas_sync import NasSync, InfluxError  # noqa: E402
from columns import load_columns_info, _COLUMN_NAME_ALIASES as COLUMN_NAME_ALIASES  # noqa: E402

ALLOWED_DATA_EXT = (".csv", ".xlsx", ".xls")
DEFAULT_PORT = 8765


def columns_info_path():
    for ext in ("xlsx", "xls", "csv"):
        for pattern in (f"Columns_info.{ext}", f"Columns info.{ext}", f"columns_info.{ext}"):
            matches = glob.glob(os.path.join(PROJECT_ROOT, pattern))
            if matches:
                return matches[0]
    return None


app = Flask(__name__, static_folder=os.path.join(PROJECT_ROOT, "static"), static_url_path="/static")
app.config["MAX_CONTENT_LENGTH"] = 2 * 1024 ** 3  # 2 GB per upload batch
store = SettingsStore(PROJECT_ROOT)
library = None  # created in main() / get_library(), so importing this module stays cheap


# Read-only status page for the Engineering Building dashboard
# (GET /building/status). Registered defensively: if anything in it fails,
# the analyzer still starts. It is given the library only once it exists.
try:
    import building_status
    building_status.register(app, lambda: library)
except Exception as _e:  # noqa: BLE001
    print(f"WARNING: building status page not available: {_e}")


nas = None  # NAS (InfluxDB) sync, created with the library


def get_library():
    global library, nas
    if library is None:
        library = Library(PROJECT_ROOT, store, columns_info_path)
        nas = NasSync(library.data_dir, library)
    return library


def get_nas():
    get_library()
    return nas


def _err(messages, status=400):
    if isinstance(messages, str):
        messages = [messages]
    return jsonify({"ok": False, "errors": messages}), status


@app.after_request
def no_cache(resp):
    # Always serve the latest page/script after an update.
    resp.headers["Cache-Control"] = "no-store"
    return resp


# ------------------------------------------------------------------- pages
@app.get("/")
def index():
    return send_from_directory(app.static_folder, "index.html")


# ----------------------------------------------------------------- settings
@app.get("/api/state")
def api_state():
    ci = columns_info_path()
    return jsonify({
        "profiles": store.list_profiles(),
        "app": store.load_app_settings(),
        "running_port": app.config.get("RUNNING_PORT"),
        "forbidden_ports": sorted(FORBIDDEN_PORTS),
        "columns_info_file": os.path.basename(ci) if ci else None,
    })


@app.get("/api/profiles/<name>")
def api_get_profile(name):
    try:
        return jsonify({"ok": True, "name": name, "settings": store.load_profile(name)})
    except SettingsError as e:
        return _err(e.errors, 404)


@app.get("/api/defaults")
def api_defaults():
    return jsonify({"ok": True, "settings": store.factory_defaults()})


@app.put("/api/profiles/<name>")
def api_save_profile(name):
    try:
        saved = store.save_profile(name, (request.get_json(silent=True) or {}).get("settings") or {})
        return jsonify({"ok": True, "name": name, "settings": saved, "profiles": store.list_profiles()})
    except SettingsError as e:
        return _err(e.errors)


@app.delete("/api/profiles/<name>")
def api_delete_profile(name):
    try:
        store.delete_profile(name)
        return jsonify({"ok": True, "profiles": store.list_profiles(), "app": store.load_app_settings()})
    except SettingsError as e:
        return _err(e.errors)


@app.get("/api/profiles/<name>/xml")
def api_profile_xml(name):
    try:
        text = store.profile_xml_text(name)
    except (SettingsError, OSError):
        abort(404)
    return Response(text, mimetype="application/xml",
                    headers={"Content-Disposition": f'attachment; filename="{name}.xml"'})


@app.post("/api/profiles/import")
def api_import_profile():
    up = request.files.get("file")
    if up is None:
        return _err("Choose an XML file to import.")
    try:
        name = request.form.get("name", "")
        saved = store.import_profile_xml(name, up.read())
        return jsonify({"ok": True, "name": name, "settings": saved, "profiles": store.list_profiles()})
    except SettingsError as e:
        return _err(e.errors)


@app.put("/api/app-settings")
def api_app_settings():
    try:
        return jsonify({"ok": True, "app": store.save_app_settings(request.get_json(silent=True) or {})})
    except SettingsError as e:
        return _err(e.errors)


# ----------------------------------------------------- code descriptions
@app.get("/api/codes")
def api_codes():
    path = columns_info_path()
    if not path:
        return jsonify({"ok": True, "file": None, "groups": []})
    try:
        df = load_columns_info(path)
    except Exception as e:
        return _err(f"Could not read {os.path.basename(path)}: {e}", 500)
    df.columns = [str(c).strip().lower() for c in df.columns]
    col, code, desc = df.columns[0], df.columns[1], df.columns[2]
    groups = {}
    for _, row in df.iterrows():
        g = str(row[col]).strip()
        if not g or g.lower() == "nan":
            continue
        try:
            c = int(row[code])
        except (TypeError, ValueError):
            continue
        groups.setdefault(g, []).append({"code": c, "description": str(row[desc]).strip()})

    def plc_name(file_name):
        key = file_name.strip().lower()
        return COLUMN_NAME_ALIASES.get(key.replace(" ", "").replace("_", ""), COLUMN_NAME_ALIASES.get(key))

    return jsonify({"ok": True, "file": os.path.basename(path),
                    "groups": [{"column": k, "plc_column": plc_name(k), "codes": v} for k, v in groups.items()]})


@app.post("/api/codes")
def api_upload_codes():
    up = request.files.get("file")
    if up is None or not up.filename.lower().endswith((".xlsx", ".xls", ".csv")):
        return _err("Choose a Columns_info file (.xlsx or .csv).")
    ext = os.path.splitext(up.filename)[1].lower()
    tmp = os.path.join(PROJECT_ROOT, f"Columns_info.upload{ext}")
    up.save(tmp)
    try:
        df = load_columns_info(tmp)
        if df.shape[1] < 3:
            raise ValueError("expected 3 columns: column, code, description")
    except Exception as e:
        os.remove(tmp)
        return _err(f"That file could not be read: {e}")
    old = columns_info_path()
    if old:
        backup_dir = os.path.join(PROJECT_ROOT, "config", "columns_info_backups")
        os.makedirs(backup_dir, exist_ok=True)
        shutil.move(old, os.path.join(backup_dir, time.strftime("%Y%m%d-%H%M%S_") + os.path.basename(old)))
    os.replace(tmp, os.path.join(PROJECT_ROOT, f"Columns_info{ext}"))
    return api_codes()


# ------------------------------------------------------------ PLC data
@app.get("/api/files")
def api_files():
    return jsonify(get_library().list_files())


@app.post("/api/files")
def api_upload_files():
    uploads = [f for f in request.files.getlist("files") if f and f.filename]
    if not uploads:
        return _err("Add at least one PLC data file (.csv, .xlsx or .xls).")
    bad = [f.filename for f in uploads if not f.filename.lower().endswith(ALLOWED_DATA_EXT)]
    if bad:
        return _err(f"These files aren't CSV or Excel: {', '.join(bad)}")
    added = [get_library().add_file(up.filename, up.save) for up in uploads]
    return jsonify({"ok": True, "added": [a["name"] for a in added], **get_library().list_files()})


@app.delete("/api/files/<fid>")
def api_delete_file(fid):
    try:
        if not get_library().delete_file(fid):
            abort(404)
    except RuntimeError as e:
        return _err(str(e))
    return jsonify({"ok": True, **get_library().list_files()})


# ------------------------------------------------------- NAS (InfluxDB) sync
def _nas_errors(e):
    return e.args[0] if isinstance(e, ValueError) and e.args and isinstance(e.args[0], list) else [str(e)]


@app.get("/api/nas")
def api_nas():
    return jsonify({"ok": True, **get_nas().public()})


@app.put("/api/nas")
def api_nas_save():
    try:
        return jsonify({"ok": True, **get_nas().save(request.get_json(silent=True) or {})})
    except ValueError as e:
        return _err(_nas_errors(e))


@app.post("/api/nas/test")
def api_nas_test():
    try:
        return jsonify({"ok": True, "message": get_nas().test(request.get_json(silent=True) or {})})
    except (InfluxError, ValueError) as e:
        return _err(_nas_errors(e))


@app.post("/api/nas/find")
def api_nas_find():
    try:
        msg = get_nas().find_machines(request.get_json(silent=True) or {})
        return jsonify({"ok": True, "message": msg, **get_nas().public()})
    except (InfluxError, ValueError) as e:
        return _err(_nas_errors(e))


@app.put("/api/nas/machines")
def api_nas_machines():
    try:
        rows = (request.get_json(silent=True) or {}).get("machines") or []
        return jsonify({"ok": True, **get_nas().save_machines(rows)})
    except ValueError as e:
        return _err(_nas_errors(e))


@app.post("/api/nas/machines/reset")
def api_nas_machine_reset():
    try:
        tag = (request.get_json(silent=True) or {}).get("tag")
        return jsonify({"ok": True, **get_nas().reset_machine(str(tag))})
    except ValueError as e:
        return _err(_nas_errors(e))


@app.post("/api/nas/sync")
def api_nas_sync():
    try:
        started = get_nas().start("manual")
        return jsonify({"ok": True, "started": started, **get_nas().public()})
    except (InfluxError, ValueError) as e:
        return _err(_nas_errors(e))


@app.post("/api/nas/stop")
def api_nas_stop():
    get_nas().stop()
    return jsonify({"ok": True, **get_nas().public()})


# --------------------------------------------------------------- reports
def _job_public(job, log_from=0):
    j = {k: v for k, v in job.items() if k != "log"}
    j["log"] = job["log"][log_from:]
    j["log_total"] = len(job["log"])
    return j


@app.post("/api/reports")
def api_start_report():
    body = request.get_json(silent=True) or {}
    d_from, d_to = str(body.get("date_from") or ""), str(body.get("date_to") or "")
    errors = []
    if len(d_from) != 10 or len(d_to) != 10:
        errors.append("Choose both a start and an end date.")
    elif d_from > d_to:
        errors.append("The start date is after the end date.")
    mode = body.get("mode")
    if mode not in ("daily", "period"):
        errors.append("Choose daily reports or one report for the period.")
    if errors:
        return _err(errors)
    filters = {
        "mode": mode, "date_from": d_from, "date_to": d_to,
        "machines": sorted({str(m) for m in body.get("machines") or []}),
        "lanes": sorted({str(x).upper() for x in body.get("lanes") or []}),
        "include_machine_reports": bool(body.get("include_machine_reports", True)),
        "json": bool(body.get("json", False)),
    }
    job = get_library().start_report(filters)
    return jsonify({"ok": True, "job": _job_public(job)})


@app.get("/api/reports")
def api_list_reports():
    lib = get_library()
    jobs = sorted(lib.jobs.values(), key=lambda j: j["created"], reverse=True)
    return jsonify({"reports": [_job_public(j, log_from=len(j["log"])) for j in jobs], "busy": lib.busy})


@app.get("/api/reports/<jid>")
def api_report(jid):
    job = get_library().jobs.get(jid)
    if job is None:
        abort(404)
    return jsonify(_job_public(job, log_from=int(request.args.get("log_from", 0))))


@app.delete("/api/reports/<jid>")
def api_delete_report(jid):
    try:
        if not get_library().delete_job(jid):
            abort(404)
    except RuntimeError as e:
        return _err(str(e))
    return jsonify({"ok": True})


@app.get("/api/reports/<jid>/files/<path:relpath>")
def api_report_file(jid, relpath):
    full = get_library().job_file(jid, relpath)
    if not full or not os.path.isfile(full):
        abort(404)
    return send_file(full, as_attachment=request.args.get("view") != "1",
                     download_name=os.path.basename(full))


@app.get("/api/reports/<jid>/zip")
def api_report_zip(jid):
    lib = get_library()
    job = lib.jobs.get(jid)
    if job is None:
        abort(404)
    group = request.args.get("group")
    outputs = [o for o in job["outputs"] if not group or o["group"] == group]
    if not outputs:
        abort(404)
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for o in outputs:
            z.write(lib.job_file(jid, o["relpath"]), o["relpath"])
    buf.seek(0)
    groups = sorted({o["group"] for o in outputs})
    label = groups[0] if len(groups) == 1 else f"{groups[0]}_to_{groups[-1]}"
    return send_file(buf, mimetype="application/zip", as_attachment=True,
                     download_name=f"PLC_reports_{label}.zip")


@app.errorhandler(413)
def too_large(_e):
    return _err("The upload is larger than 2 GB. Upload the files in smaller batches.", 413)


# ------------------------------------------------------------------- start
def _port_free(port):
    """True unless something is already listening on the port. A connection
    test (not a bind test), so a socket left in TIME_WAIT by a just-closed
    analyzer doesn't block an immediate restart."""
    for family, addr in ((socket.AF_INET, "127.0.0.1"), (socket.AF_INET6, "::1")):
        try:
            with socket.socket(family, socket.SOCK_STREAM) as s:
                s.settimeout(0.5)
                if s.connect_ex((addr, port)) == 0:
                    return False
        except OSError:
            pass
    return True


def main():
    parser = argparse.ArgumentParser(description="PLC Analyzer web UI")
    parser.add_argument("--port", type=int, help="Use this port for this start only")
    parser.add_argument("--no-browser", action="store_true", help="Don't open a browser window")
    args = parser.parse_args()

    settings = store.load_app_settings()
    port = args.port or int(settings["port"])
    if port in FORBIDDEN_PORTS:
        print(f"Port {port} is reserved (5000, 5002, 5030 and 5050 are not used). Using {DEFAULT_PORT}.")
        port = DEFAULT_PORT
    network = bool(settings.get("allow_network"))
    url = f"http://localhost:{port}"

    if not _port_free(port):
        print(f"\nERROR: port {port} is already in use - the analyzer is probably already running.\n"
              f"Open {url} to check, or start on another port:  python app.py --port 8800\n")
        sys.exit(1)

    get_library()  # loads the saved files/reports and starts the worker
    app.config["RUNNING_PORT"] = port

    # Our own start message (with "localhost"); silence the servers' banners,
    # which print the raw 127.0.0.1 address.
    logging.getLogger("waitress").setLevel(logging.ERROR)
    logging.getLogger("werkzeug").setLevel(logging.ERROR)
    try:
        import flask.cli
        flask.cli.show_server_banner = lambda *a, **k: None
    except Exception:
        pass

    print("=" * 56)
    print("  PLC Analyzer is running")
    print(f"  Open {url} in your browser")
    if network:
        try:
            print(f"  Other computers: http://{socket.gethostbyname(socket.gethostname())}:{port}")
        except OSError:
            pass
    print("  Close this window (or press Ctrl+C) to stop it")
    print("=" * 56)

    if settings.get("open_browser", True) and not args.no_browser:
        threading.Timer(1.2, lambda: webbrowser.open(url)).start()

    # "localhost" binds to the loopback address(es) only; with network access
    # on, listen on every interface.
    host = "0.0.0.0" if network else "localhost"
    try:
        from waitress import serve
        listen = f"*:{port}" if network else f"localhost:{port}"
        serve(app, listen=listen, threads=8, max_request_body_size=app.config["MAX_CONTENT_LENGTH"])
    except ImportError:
        app.run(host=host, port=port, threaded=True, debug=False, use_reloader=False)


if __name__ == "__main__":
    main()
