#!/usr/bin/env bash
# Double-click (or run ./run.sh) to start the PLC Analyzer.
cd "$(dirname "$0")"
if command -v python3 >/dev/null 2>&1; then PY=python3
elif command -v python >/dev/null 2>&1; then PY=python
else
  echo "ERROR: Python 3.10+ was not found. Install it from https://www.python.org/downloads/"
  read -r -p "Press Enter to close..."; exit 1
fi
echo "Checking required packages (the first run may take a minute) ..."
$PY -m pip install -r requirements.txt --quiet --disable-pip-version-check \
  || echo "WARNING: could not check/install packages (no internet?). Trying to start anyway ..."
$PY app.py
read -r -p "The analyzer has stopped. Press Enter to close..."
