"""
sequence_agent.py
==================
Evaluation 1 - Step Sequence (see reference doc Section 3).

Row-by-row evaluation of the Step transitions within a single MoveType=3
phase. Runs completely independently of the performance and necessity
agents - it only needs the phase's own rows plus config thresholds.
"""
from dataclasses import dataclass, field
from typing import List, Optional
from columns import step_name, resolve_all_axis_columns


@dataclass
class StepEvent:
    step: int
    kind: str          # 'normal' | 'minor_waste' | 'abnormal'
    note: str
    time: str
    duration_s: float

    @property
    def symbol(self):
        return {"normal": "\u2713", "minor_waste": "\u26a0",
                "abnormal": "\u2717", "manual_intervention": "\u26a0"}[self.kind]

    def to_dict(self):
        return {
            "step": self.step,
            "step_name": step_name(self.step),
            "kind": self.kind,
            "note": self.note,
            "time": self.time,
            "duration_s": self.duration_s,
        }


@dataclass
class SequenceResult:
    dominant_axis: str
    hoist_start: float
    events: List[StepEvent] = field(default_factory=list)
    step_sequence: str = ""

    @property
    def has_abnormal(self):
        return any(e.kind == "abnormal" for e in self.events)

    @property
    def has_minor_waste(self):
        return any(e.kind == "minor_waste" for e in self.events)

    @property
    def has_manual_intervention(self):
        return any(e.kind == "manual_intervention" for e in self.events)

    def to_dict(self):
        return {
            "dominant_axis": self.dominant_axis,
            "hoist_start": self.hoist_start,
            "step_sequence": self.step_sequence,
            "events": [e.to_dict() for e in self.events],
            "has_abnormal": self.has_abnormal,
            "has_minor_waste": self.has_minor_waste,
            "has_manual_intervention": self.has_manual_intervention,
        }


def _detect_dominant_axis(phase_df, axis_cols):
    """
    Whichever axis's ACTUAL position changes the most during the movement
    steps (5/6) is the dominant (moving) axis - i.e. whichever axis really
    travels, not whichever axis merely has a big reference-vs-actual gap at
    one snapshot row. A gap-at-one-row check is fragile: an axis that never
    moves during this phase (e.g. Trolley sitting at a stale/parked
    reference while only Gantry actually travels) can still show a large
    static gap and get wrongly picked. Measuring actual movement range
    directly answers "which axis moved."
    """
    move_rows = phase_df[phase_df["Step"].isin([5, 6])]
    probe_rows = move_rows if not move_rows.empty else phase_df

    best_axis, best_range = "gantry", -1.0
    for axis, cols in axis_cols.items():
        try:
            vals = probe_rows[cols["actual"]].astype(float)
            axis_range = float(vals.max() - vals.min())
        except (KeyError, ValueError, TypeError):
            axis_range = -1.0
        if axis_range > best_range:
            best_range = axis_range
            best_axis = axis
    return best_axis


def _row_transitions(phase_df):
    """Collapses consecutive identical Step values into transition events
    (start row index, step value)."""
    transitions = []
    last_step = None
    for idx, row in phase_df.iterrows():
        step = int(row["Step"])
        if step != last_step:
            transitions.append(idx)
            last_step = step
    return transitions


def evaluate_sequence(phase_df, config, hoist_col=None) -> SequenceResult:
    axis_cols = resolve_all_axis_columns(phase_df, config.columns)
    if hoist_col is None:
        # Use the hoist actual-position column resolved from the settings
        # profile instead of a hardcoded "In_HOIST".
        hoist_col = axis_cols["hoist"]["actual"]
    dominant_axis = _detect_dominant_axis(phase_df, axis_cols)
    hoist_start = float(phase_df.iloc[0][hoist_col])
    safe_height = config.thresholds.hoist_safe_height_m
    tol = config.thresholds.step_match_tolerance_m

    expected_sequence = [3, 4, 5, 6]
    ptr = 0  # index into expected_sequence of the next step we expect
    consumed = set()
    last_good_step = None
    grace_available = False

    events: List[StepEvent] = []
    transition_idxs = _row_transitions(phase_df)
    n = len(phase_df)

    def duration_for(pos):
        start_idx = transition_idxs[pos]
        end_idx = transition_idxs[pos + 1] if pos + 1 < len(transition_idxs) else n
        start_time = phase_df.iloc[start_idx]["_ts"]
        end_time = phase_df.iloc[end_idx - 1]["_ts"] if end_idx - 1 < n else phase_df.iloc[-1]["_ts"]
        # end time = first row of NEXT event, or last row of phase if final event
        if pos + 1 < len(transition_idxs):
            end_time = phase_df.iloc[transition_idxs[pos + 1]]["_ts"]
        else:
            end_time = phase_df.iloc[-1]["_ts"]
        return start_time, end_time

    # accumulate MI blocks: consecutive step-9 (+ trailing single step-3) as one event
    i = 0
    while i < len(transition_idxs):
        idx = transition_idxs[i]
        step = int(phase_df.iloc[idx]["Step"])
        start_time, end_time = duration_for(i)
        dur = (end_time - start_time).total_seconds()
        ts_str = str(phase_df.iloc[idx]["_ts"])

        if step == 9:
            # gather this MI block: this 9, any more consecutive 9-transitions,
            # plus one immediately trailing single step-3
            mi_steps = [9]
            j = i + 1
            # (transitions already collapse consecutive identical steps, so
            # a second 9-transition means it went 9 -> something else -> 9;
            # only merge truly adjacent 9 blocks separated by nothing else)
            block_end_time = end_time
            if j < len(transition_idxs) and int(phase_df.iloc[transition_idxs[j]]["Step"]) == 3:
                # tentatively check if this 3 is immediately followed by end of block
                _, three_end = duration_for(j)
                mi_steps.append(3)
                block_end_time = three_end
                j += 1
            total_dur = (block_end_time - start_time).total_seconds()
            seq_desc = " \u2192 ".join(f"{s}({step_name(s)})" for s in mi_steps)
            events.append(StepEvent(
                step=9, kind="manual_intervention",
                note=f"MI sequence: {seq_desc}", time=ts_str, duration_s=total_dur,
            ))
            grace_available = True
            i = j
            continue

        # Try to match against expected sequence from ptr onward (skipping skippables)
        matched_pos = None
        for p in range(ptr, len(expected_sequence)):
            if expected_sequence[p] == step:
                matched_pos = p
                break

        if grace_available and last_good_step is not None and step == last_good_step:
            events.append(StepEvent(
                step=step, kind="normal",
                note=f"resume after interruption \u2014 next expected: "
                     f"{expected_sequence[ptr]}({step_name(expected_sequence[ptr])})"
                     if ptr < len(expected_sequence) else "resume after interruption",
                time=ts_str, duration_s=dur,
            ))
            grace_available = False
            i += 1
            continue

        grace_available = False

        if matched_pos is not None:
            if step == 4:
                if matched_pos == ptr and hoist_start >= safe_height:
                    events.append(StepEvent(
                        step=4, kind="minor_waste",
                        note=f"Hoist is above {safe_height:.1f} so Step 4 is minor waste of time",
                        time=ts_str, duration_s=dur,
                    ))
                elif matched_pos != ptr and hoist_start >= safe_height:
                    events.append(StepEvent(
                        step=4, kind="abnormal",
                        note=f"Step 4 out of sequence and hoist already \u2265 {safe_height:.1f}m",
                        time=ts_str, duration_s=dur,
                    ))
                else:
                    events.append(StepEvent(
                        step=4, kind="normal",
                        note="step is normal (lifting hoist to safe travel height)",
                        time=ts_str, duration_s=dur,
                    ))
            elif step == 3:
                events.append(StepEvent(
                    step=3, kind="normal",
                    note="step is normal (waiting for start order)",
                    time=ts_str, duration_s=dur,
                ))
            else:
                # 5 or 6: converging check using dominant axis
                cols = axis_cols[dominant_axis]
                row = phase_df.iloc[idx]
                gap = abs(float(row[cols["ref"]]) - float(row[cols["actual"]]))
                is_last_row_of_phase = (i == len(transition_idxs) - 1)
                if is_last_row_of_phase:
                    last_row = phase_df.iloc[-1]
                    end_gap = abs(float(last_row[cols["ref"]]) - float(last_row[cols["actual"]]))
                    if end_gap <= tol:
                        note = f"step is normal ({dominant_axis} reference matching {dominant_axis} actual position)"
                        kind = "normal"
                    else:
                        note = (f"{dominant_axis} reference/actual gap ({end_gap:.2f}m) exceeds "
                                 f"tolerance ({tol:.1f}m) at end of phase")
                        kind = "abnormal"
                else:
                    note = f"step is normal ({dominant_axis} reference moving towards {dominant_axis} actual position)"
                    kind = "normal"
                events.append(StepEvent(step=step, kind=kind, note=note, time=ts_str, duration_s=dur))

            ptr = matched_pos + 1
            last_good_step = step
            consumed.add(step)
        else:
            events.append(StepEvent(
                step=step, kind="abnormal",
                note=f"Step {step}({step_name(step)}) out of sequence \u2014 "
                     f"next expected: {expected_sequence[ptr] if ptr < len(expected_sequence) else 'none'}"
                     + (f"({step_name(expected_sequence[ptr])})" if ptr < len(expected_sequence) else ""),
                time=ts_str, duration_s=dur,
            ))
            grace_available = True

        i += 1

    step_sequence_str = " \u2192 ".join(f"{e.step}({step_name(e.step)})" for e in events)
    return SequenceResult(
        dominant_axis=dominant_axis,
        hoist_start=hoist_start,
        events=events,
        step_sequence=step_sequence_str,
    )
