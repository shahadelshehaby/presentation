"""
report_machine.py
==================
Generates one PDF per machine, per day: "{machine}_{date}.pdf".

This is where the three agents' independent outputs get combined into a
single report - an executive summary table, a Move Category Breakdown for
this machine, then full detail (sequence / performance / necessity, incl.
the expected-vs-actual speed chart) per workorder.
"""
from utils import display_time
from reportlab.platypus import (SimpleDocTemplate, Table, TableStyle, Paragraph,
                                 Spacer, PageBreak)
from reportlab.lib import colors
from reportlab.lib.units import inch

from pdf_style import get_styles, PAGE_SIZE, MARGIN, FLAG_OK_COLOR, FLAG_REVIEW_COLOR, \
    WASTE_ROW_COLOR, ABNORMAL_ROW_COLOR, MI_ROW_COLOR, HEADER_BG
from category_breakdown import build_category_breakdown_table
from performance_chart import build_speed_chart
from pickup_setdown_report import build_pickup_setdown_table, rollup_counts
from columns import step_name
from utils import format_energy_kwh, format_cost


def _header_row(labels, styles):
    return [Paragraph(l, styles["TableHeader"]) for l in labels]


def _exec_summary_table(results, styles, config=None):
    show_cost = config is not None and getattr(config.power, "cost_per_kwh", None) is not None
    labels = ["Workorder", "Time", "Duration (s)", "Axis", "Sequence", "Performance", "Necessity",
               "Energy (kWh)", "Flag"]
    if show_cost:
        labels.insert(-1, f"Wasted cost ({config.power.currency})")
    header = _header_row(labels, styles)
    data = [header]
    for r in results:
        flag = r.flag
        flag_color = FLAG_OK_COLOR if flag == "OK" else FLAG_REVIEW_COLOR
        seq_txt = "abnormal" if r.sequence.has_abnormal else (
            "MI" if r.sequence.has_manual_intervention else (
                "waste" if r.sequence.has_minor_waste else "normal"))
        perf_txt = r.performance.verdict
        nec_txt = "unknown" if r.necessity.unknown else ("necessary" if r.necessity.necessary else "unnecessary")
        energy_txt = format_energy_kwh(r.power) + (" \u26a0 wasted" if r.is_unnecessary and r.power.has_any_data else "")
        row = [
            Paragraph(str(r.workorder), styles["Body9"]),
            Paragraph(display_time(r.time_start), styles["Body9"]),
            Paragraph(f"{r.duration_s:.1f}", styles["Body9"]),
            Paragraph(r.sequence.dominant_axis, styles["Body9"]),
            Paragraph(seq_txt, styles["Body9"]),
            Paragraph(perf_txt, styles["Body9"]),
            Paragraph(nec_txt, styles["Body9"]),
            Paragraph(energy_txt, styles["Body9"]),
            Paragraph(f'<font color="{flag_color.hexval()}"><b>{flag}</b></font>', styles["Body9"]),
        ]
        if show_cost:
            wasted_val = r.wasted_energy_kwh if (r.is_unnecessary and r.power.has_any_data) else None
            row.insert(-1, Paragraph(format_cost(wasted_val, config) if wasted_val is not None else "-",
                                      styles["Body9"]))
        data.append(row)

    col_widths = [0.8*inch, 0.8*inch, 0.8*inch, 0.6*inch,
                  0.9*inch, 1.0*inch, 1.0*inch, 1.05*inch, 0.6*inch]
    if show_cost:
        col_widths.insert(-1, 0.9*inch)
    table = Table(data, repeatRows=1, colWidths=col_widths)
    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), HEADER_BG),
        ("FONTSIZE", (0, 1), (-1, -1), 9),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f7f7f7")]),
    ]))
    return table


def _sequence_detail_table(seq_result, styles):
    header = _header_row(["Symbol", "Step", "Duration (s)", "Note"], styles)
    data = [header]
    row_styles = []
    for i, ev in enumerate(seq_result.events, start=1):
        data.append([
            Paragraph(ev.symbol, styles["Body9"]),
            Paragraph(f"{ev.step} - {step_name(ev.step)}", styles["Body9"]),
            Paragraph(f"{ev.duration_s:.1f}", styles["Body9"]),
            Paragraph(ev.note or "", styles["Body8"]),
        ])
        if ev.kind == "minor_waste":
            row_styles.append(("BACKGROUND", (0, i), (-1, i), WASTE_ROW_COLOR))
        elif ev.kind == "abnormal":
            row_styles.append(("BACKGROUND", (0, i), (-1, i), ABNORMAL_ROW_COLOR))
        elif ev.kind == "manual_intervention":
            row_styles.append(("BACKGROUND", (0, i), (-1, i), MI_ROW_COLOR))

    table = Table(data, repeatRows=1, colWidths=[0.75*inch, 1.75*inch, 0.8*inch, 4.1*inch])
    style = [
        ("BACKGROUND", (0, 0), (-1, 0), HEADER_BG),
        ("FONTNAME", (0, 1), (-1, -1), "DejaVuSans"),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
    ] + row_styles
    table.setStyle(TableStyle(style))
    return table


def _workorder_detail(result, styles, config=None):
    flow = []
    flag_color = FLAG_OK_COLOR if result.flag == "OK" else FLAG_REVIEW_COLOR
    flow.append(Paragraph(
        f'Workorder {result.workorder} &nbsp;&nbsp; '
        f'<font color="{flag_color.hexval()}"><b>[{result.flag}]</b></font>',
        styles["H2"]))
    flow.append(Paragraph(
        f"Time: {result.time_start} &rarr; {result.time_end} &nbsp; "
        f"Duration: {result.duration_s:.1f}s &nbsp; Dominant axis: {result.sequence.dominant_axis} "
        f"&nbsp; Hoist@start: {result.sequence.hoist_start:.2f}m", styles["Body9"]))
    if result.workorder_warnings:
        for w in result.workorder_warnings:
            flow.append(Paragraph(f'\u26a0 {w}', styles["Body9"]))

    flow.append(Paragraph("Step Sequence", styles["H3"]))
    flow.append(Paragraph(
        "Steps: " + " &rarr; ".join(f"{e.step}({step_name(e.step)})" for e in result.sequence.events),
        styles["Body8"]))
    flow.append(Spacer(1, 4))
    flow.append(_sequence_detail_table(result.sequence, styles))
    flow.append(Spacer(1, 8))

    flow.append(Paragraph("Performance", styles["H3"]))
    flow.append(Paragraph(result.performance.message, styles["Body9"]))
    chart = build_speed_chart(result.performance, result.sequence.dominant_axis)
    if chart is not None:
        flow.append(Spacer(1, 4))
        flow.append(chart)
    flow.append(Spacer(1, 8))

    flow.append(Paragraph("Necessity", styles["H3"]))
    verdict_text = "unknown (no following workorder to check against)" if result.necessity.unknown else \
        ("necessary move:" if result.necessity.necessary else "unnecessary move:")
    flow.append(Paragraph(f"<b>{verdict_text}</b>", styles["Body9"]))
    for symbol, text in result.necessity.lines:
        flow.append(Paragraph(f"{symbol} {text}", styles["Body9"]))
    flow.append(Spacer(1, 8))

    flow.append(Paragraph("Power / Energy", styles["H3"]))
    pw = result.power
    axis_txt = ", ".join(f"{axis}: {kwh:.3f} kWh" for axis, kwh in pw.axis_energy_kwh.items())
    flow.append(Paragraph(
        f"Total energy: <b>{format_energy_kwh(pw)}{' kWh' if pw.has_any_data else ''}</b> &nbsp; "
        f"(avg power {pw.avg_power_kw:.2f} kW) &nbsp; [{axis_txt}]", styles["Body9"]))
    if pw.axes_using_legacy_estimate:
        flow.append(Paragraph(
            f"\u26a0 Real Current/Voltage columns not found for: "
            f"{', '.join(pw.axes_using_legacy_estimate)} \u2014 estimated using legacy drive "
            f"current columns with an assumed voltage instead.", styles["Body9"]))
    if pw.missing_columns:
        flow.append(Paragraph(
            f"\u26a0 Drive current/voltage columns not found for: {', '.join(pw.missing_columns)} "
            f"\u2014 that axis' contribution to energy is shown as 0.", styles["Body9"]))
    if pw.no_data_axes:
        flow.append(Paragraph(
            f"\u2139 Column(s) exist but contain no consumption data for this move on: "
            f"{', '.join(pw.no_data_axes)} \u2014 that axis is excluded from the total rather "
            f"than shown as a misleading 0.", styles["Body9"]))
    if result.is_unnecessary and pw.has_any_data:
        wasted_line = f"\u26a0 This move was judged UNNECESSARY \u2014 all {format_energy_kwh(pw)} kWh counts as wasted energy."
        if config is not None and getattr(config.power, "cost_per_kwh", None) is not None:
            wasted_line += f" ({format_cost(pw.total_energy_kwh, config)})"
        flow.append(Paragraph(wasted_line, styles["Body9"]))
    elif result.is_unnecessary and not pw.has_any_data:
        flow.append(Paragraph(
            "\u26a0 This move was judged UNNECESSARY, but no consumption data is available to "
            "estimate its wasted energy/cost.", styles["Body9"]))
    flow.append(Spacer(1, 14))
    return flow


def generate_machine_report(machine, date_str, results, out_path, pickup_setdown_results=None, config=None):
    pickup_setdown_results = pickup_setdown_results or []
    styles = get_styles()
    doc = SimpleDocTemplate(out_path, pagesize=PAGE_SIZE,
                             leftMargin=MARGIN, rightMargin=MARGIN,
                             topMargin=MARGIN, bottomMargin=MARGIN)
    flow = []
    flow.append(Paragraph(f"MoveType=3 Report &mdash; Machine {machine} &mdash; {date_str}", styles["H1"]))
    flow.append(Paragraph(f"Total MoveType=3 moves analyzed: {len(results)}", styles["Body9"]))
    n_review = sum(1 for r in results if r.flag == "REVIEW")
    flow.append(Paragraph(f"Flagged for review: {n_review}", styles["Body9"]))
    total_energy = sum(r.power.total_energy_kwh for r in results if r.power.has_any_data)
    wasted_energy = sum(r.wasted_energy_kwh for r in results if r.power.has_any_data)
    cost_txt = ""
    if config is not None and getattr(config.power, "cost_per_kwh", None) is not None:
        cost_txt = f" &nbsp; Wasted cost: <b>{format_cost(wasted_energy, config)}</b>"
    flow.append(Paragraph(
        f"Total energy: {total_energy:.3f} kWh &nbsp;&nbsp; "
        f"Wasted energy (unnecessary moves): <b>{wasted_energy:.3f} kWh</b>"
        + (f" ({100*wasted_energy/total_energy:.1f}% of total)" if total_energy > 0 else "")
        + cost_txt,
        styles["Body9"]))
    flow.append(Spacer(1, 10))

    if results:
        flow.append(_exec_summary_table(results, styles, config))
        flow.append(Spacer(1, 16))
        flow.append(Paragraph("Move Category Breakdown (Necessity x Performance)", styles["H2"]))
        flow.append(build_category_breakdown_table(results, styles))
    else:
        flow.append(Paragraph("No MoveType=3 moves found in this file.", styles["Body9"]))

    # ---- Pickup / Setdown (MoveType 1 & 2) necessity ----
    flow.append(Spacer(1, 16))
    flow.append(Paragraph("Pickup / Setdown Necessity (MoveType 1 & 2)", styles["H2"]))
    flow.append(Paragraph(
        "Necessary: the workorder contains both a pickup (1) and a setdown (2) phase. "
        "Unnecessary: the workorder has only a pickup (1) phase, with no setdown (2) phase "
        "following it in the same workorder.", styles["Body9"]))
    if pickup_setdown_results:
        c = rollup_counts(pickup_setdown_results)
        flow.append(Paragraph(
            f"Pickup workorders: {c['n']} &nbsp; Necessary: {c['n_necessary']} &nbsp; "
            f"Unnecessary: <b>{c['n_unnecessary']}</b> &nbsp; Unknown: {c['n_unknown']}",
            styles["Body9"]))
        flow.append(Spacer(1, 4))
        flow.append(build_pickup_setdown_table(pickup_setdown_results, styles))
    else:
        flow.append(Paragraph("No MoveType=1/2 (pickup/setdown) workorders found in this file.",
                               styles["Body9"]))

    flow.append(PageBreak())

    for result in results:
        flow.extend(_workorder_detail(result, styles, config))

    doc.build(flow)
    return out_path
