"""
influx_clean.py
================
Turns an InfluxDB export into the plain PLC table the analysis expects -
the same cleanup that was previously done by hand in Excel:

  - the 3 annotation rows at the top (#group, #datatype, #default) are removed;
  - the first 2-3 columns (an empty one, "result", "table") are removed, as are
    InfluxDB's own bookkeeping columns (_start, _stop, _measurement);
  - an export holding several tables (one header row per table) is joined
    back into one table.

It also makes sure every row has a PLCTime in the format the analysis reads
("2026-10-13-14:26:01", local time). The PLC's own PLCTime field is kept when
it is there; rows without one get it from InfluxDB's _time, converted from
UTC to the local time zone (Asia/Dubai by default), so data pulled from the
NAS lines up with manually exported files.

Used by data_loader.load_plc_csv (uploads) and nas_sync.py (NAS pulls).
"""
import csv
import io
import re
from datetime import timedelta, timezone

import pandas as pd

TIME_FORMAT = "%Y-%m-%d-%H:%M:%S"
DEFAULT_TIMEZONE = "Asia/Dubai"
META_COLUMNS = {"", "result", "table", "_start", "_stop", "_measurement"}
_local_tz_name = DEFAULT_TIMEZONE


# ------------------------------------------------------------------ time zone
def resolve_timezone(name):
    """'Asia/Dubai' or a fixed offset such as 'UTC+04:00' / '+4'. Raises
    ValueError if it can't be understood."""
    name = (name or "").strip() or DEFAULT_TIMEZONE
    m = re.fullmatch(r"(?:UTC|GMT)?\s*([+-])\s*(\d{1,2})(?::?(\d{2}))?", name, re.IGNORECASE)
    if m:
        sign = 1 if m.group(1) == "+" else -1
        return timezone(sign * timedelta(hours=int(m.group(2)), minutes=int(m.group(3) or 0)))
    if name.upper() in ("UTC", "GMT", "Z"):
        return timezone.utc
    try:
        from zoneinfo import ZoneInfo
        return ZoneInfo(name)
    except Exception:
        # Windows without the tzdata package can't look names up; Dubai has a
        # fixed offset, so it never depends on that.
        if name.lower() in ("asia/dubai", "asia/muscat", "gulf standard time"):
            return timezone(timedelta(hours=4))
        raise ValueError(f"Unknown time zone '{name}'. Use a name like Asia/Dubai or an offset like UTC+04:00.")


def set_local_timezone(name):
    global _local_tz_name
    resolve_timezone(name)  # validate
    _local_tz_name = name or DEFAULT_TIMEZONE


def local_timezone():
    return resolve_timezone(_local_tz_name)


# ------------------------------------------------------------------ detection
def _cell(v):
    if v is None:
        return ""
    if isinstance(v, float) and v != v:  # NaN
        return ""
    return str(v).strip()


def looks_like_influx(columns, first_rows=()):
    """True for a raw InfluxDB export: annotation rows ('#group'...) or the
    'result'/'table' columns at the start."""
    cols = [_cell(c) for c in columns]
    if cols and cols[0].startswith("#"):
        return True
    if "result" in cols[:4] and "table" in cols[:4]:
        return True
    for row in first_rows:
        cells = [_cell(c) for c in row]
        if cells and cells[0].startswith("#"):
            return True
        if "result" in cells[:4] and "table" in cells[:4]:
            return True
    return False


def _is_header(cells):
    head = cells[:4]
    return ("result" in head and "table" in head) or "PLCTime" in cells or "_time" in cells


# ------------------------------------------------------------------ cleaning
def clean_rows(rows):
    """rows: list of lists of cells (strings or values) from a raw export.
    Returns a DataFrame of the data rows with clean column names (values as
    they were; strings for CSV input)."""
    tables = []
    header, data = None, []

    def flush():
        if header is not None and data:
            tables.append(pd.DataFrame(data, columns=header))

    for row in rows:
        cells = [_cell(c) for c in row]
        if not any(cells):
            continue  # blank line between tables
        if cells[0].startswith("#"):
            continue  # #group / #datatype / #default annotation rows
        if _is_header(cells):
            flush()
            header = _unique([c for c in cells])
            data = []
            continue
        if header is None:
            continue  # junk before the first header
        row = list(row) + [None] * (len(header) - len(row))
        data.append(row[:len(header)])
    flush()

    if not tables:
        return pd.DataFrame()
    df = pd.concat(tables, ignore_index=True, sort=False) if len(tables) > 1 else tables[0]
    drop = [c for c in df.columns if c in META_COLUMNS or c.startswith("Unnamed:") or c.startswith("_blank")]
    return df.drop(columns=drop)


def _unique(names):
    seen, out = {}, []
    for i, n in enumerate(names):
        n = n or f"_blank{i}"
        if n in seen:
            seen[n] += 1
            n = f"{n}.{seen[n]}"
        else:
            seen[n] = 0
        out.append(n)
    return out


def parse_influx_csv(text):
    """InfluxDB query/export CSV text -> cleaned DataFrame (all values str)."""
    return clean_rows(csv.reader(io.StringIO(text)))


def read_raw_file(path):
    """Reads a raw InfluxDB export saved as .csv or .xlsx and returns it
    cleaned, with numbers typed (as if it had been cleaned in Excel)."""
    if path.lower().endswith((".xlsx", ".xls")):
        raw = pd.read_excel(path, header=None, dtype=object)
        rows = raw.itertuples(index=False, name=None)
    else:
        with open(path, newline="", encoding="utf-8-sig") as f:
            rows = list(csv.reader(f))
    df = clean_rows(rows)
    # Round-trip through CSV so numbers/booleans get their normal types.
    buf = io.StringIO()
    df.to_csv(buf, index=False)
    buf.seek(0)
    return pd.read_csv(buf, low_memory=False)


# ------------------------------------------------------------------ time
def parse_utc(values):
    """Parses InfluxDB _time values to UTC timestamps without ever raising.

    InfluxDB writes RFC3339 with as much precision as each value needs, so
    one column mixes "2026-10-09T04:28:05Z" with "2026-10-09T04:28:05.5Z".
    pandas guesses one format from the first value and then fails on the
    others ("doesn't match format '%Y-%m-%dT%H:%M:%S.%f%z'"). This tries the
    ways that accept every precision, keeps the one that reads the most
    values, and falls back to value-by-value parsing. Unreadable values
    become NaT."""
    s = pd.Series(values).astype("string").str.strip()
    wanted = int((s.notna() & (s != "")).sum())
    best = None
    for kwargs in ({"format": "ISO8601"}, {"format": "mixed"}, {}):
        try:
            parsed = pd.to_datetime(s, utc=True, errors="coerce", **kwargs)
        except (ValueError, TypeError):
            continue
        if best is None or parsed.notna().sum() > best.notna().sum():
            best = parsed
        if best.notna().sum() >= wanted:
            return best

    def one(v):
        try:
            return pd.Timestamp(v).tz_convert("UTC") if pd.Timestamp(v).tzinfo else pd.Timestamp(v).tz_localize("UTC")
        except (ValueError, TypeError):
            return pd.NaT
    slow = pd.to_datetime(s.map(one), utc=True, errors="coerce")
    return slow if best is None or slow.notna().sum() > best.notna().sum() else best


def normalize_plctime(df, tz=None):
    """Makes df['PLCTime'] a local-time string in TIME_FORMAT for every row.
    Keeps the PLC's own PLCTime where it parses; otherwise uses _time
    (UTC from InfluxDB) converted to the local time zone. Rows with neither
    are dropped. Returns a new DataFrame."""
    tz = tz or local_timezone()
    df = df.copy()
    parsed = pd.Series(pd.NaT, index=df.index, dtype="datetime64[ns]")
    if "PLCTime" in df.columns:
        s = df["PLCTime"].astype("string").str.strip()
        parsed = pd.to_datetime(s, format=TIME_FORMAT, errors="coerce")
        missing = parsed.isna() & s.notna() & (s != "")
        if missing.any():
            try:
                parsed[missing] = pd.to_datetime(s[missing], format="mixed", errors="coerce")
            except (ValueError, TypeError):
                pass
    if "_time" in df.columns and parsed.isna().any():
        utc = parse_utc(df["_time"])
        utc.index = df.index
        local = utc.dt.tz_convert(tz).dt.tz_localize(None)
        parsed = parsed.fillna(local)
    if parsed.isna().all() and "PLCTime" not in df.columns and "_time" not in df.columns:
        raise KeyError("PLCTime")
    df = df[parsed.notna()].copy()
    df["PLCTime"] = parsed[parsed.notna()].dt.strftime(TIME_FORMAT)
    return df
