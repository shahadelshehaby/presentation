"""
report_summary.py
==================
Generates "Summary_{date}.pdf" - one per day.

Page 1: title + Per-Machine Rollup table (moves analyzed / OK / review / time).
Page 2: Move Category Breakdown (Necessity x Performance) - "Overall (all
        machines)" first, then one table per machine that reported that
        day - nothing else on this page.
"""
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, PageBreak
from reportlab.lib import colors
from reportlab.lib.units import inch

from pdf_style import get_styles, PAGE_SIZE, MARGIN, HEADER_BG
from category_breakdown import build_category_breakdown_table
from pickup_setdown_report import build_pickup_setdown_rollup_table, build_pickup_setdown_table, rollup_counts
from utils import format_hms, format_cost


def _per_machine_table(machine_results: dict, styles, config=None):
    show_cost = config is not None and getattr(config.power, "cost_per_kwh", None) is not None
    headers = ["Machine", "Moves analyzed", "Fully OK", "Flagged for review", "Total time",
               "Total energy (kWh)", "Wasted energy (kWh)"]
    if show_cost:
        headers.append(f"Wasted cost ({config.power.currency})")
    header = [Paragraph(h, styles["TableHeader"]) for h in headers]
    data = [header]
    tot_moves = tot_ok = tot_review = 0
    tot_time = 0.0
    tot_energy = tot_wasted = 0.0
    for machine in sorted(machine_results.keys()):
        results = machine_results[machine]
        n = len(results)
        n_review = sum(1 for r in results if r.flag == "REVIEW")
        n_ok = n - n_review
        total_time = sum(r.duration_s for r in results)
        energy = sum(r.power.total_energy_kwh for r in results if r.power.has_any_data)
        wasted = sum(r.wasted_energy_kwh for r in results if r.power.has_any_data)
        tot_moves += n
        tot_ok += n_ok
        tot_review += n_review
        tot_time += total_time
        tot_energy += energy
        tot_wasted += wasted
        row = [
            Paragraph(machine, styles["Body9"]),
            Paragraph(str(n), styles["Body9"]),
            Paragraph(str(n_ok), styles["Body9"]),
            Paragraph(str(n_review), styles["Body9"]),
            Paragraph(format_hms(total_time), styles["Body9"]),
            Paragraph(f"{energy:.3f}", styles["Body9"]),
            Paragraph(f"{wasted:.3f}", styles["Body9"]),
        ]
        if show_cost:
            row.append(Paragraph(format_cost(wasted, config), styles["Body9"]))
        data.append(row)
    tot_row = [
        Paragraph("<b>TOTAL</b>", styles["Body9"]),
        Paragraph(f"<b>{tot_moves}</b>", styles["Body9"]),
        Paragraph(f"<b>{tot_ok}</b>", styles["Body9"]),
        Paragraph(f"<b>{tot_review}</b>", styles["Body9"]),
        Paragraph(f"<b>{format_hms(tot_time)}</b>", styles["Body9"]),
        Paragraph(f"<b>{tot_energy:.3f}</b>", styles["Body9"]),
        Paragraph(f"<b>{tot_wasted:.3f}</b>", styles["Body9"]),
    ]
    if show_cost:
        tot_row.append(Paragraph(f"<b>{format_cost(tot_wasted, config)}</b>", styles["Body9"]))
    data.append(tot_row)

    col_widths = [1.1*inch, 1.1*inch, 0.9*inch, 1.2*inch, 1.1*inch, 1.15*inch, 1.15*inch]
    if show_cost:
        col_widths.append(1.15*inch)
    table = Table(data, repeatRows=1, colWidths=col_widths)
    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), HEADER_BG),
        ("FONTNAME", (0, 1), (-1, -1), "DejaVuSans"),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("BACKGROUND", (0, -1), (-1, -1), colors.HexColor("#eeeeee")),
    ]))
    return table


def generate_summary_report(date_str, machine_results: dict, out_path, pickup_setdown_results: dict = None,
                             config=None, period=False):
    """machine_results: {machine_name: [MoveType3Result, ...]}
    pickup_setdown_results: {machine_name: [PickupSetdownWorkorderResult, ...]}
    config: Config (optional) - enables the wasted-cost column."""
    pickup_setdown_results = pickup_setdown_results or {}
    styles = get_styles()
    doc = SimpleDocTemplate(out_path, pagesize=PAGE_SIZE,
                             leftMargin=MARGIN, rightMargin=MARGIN,
                             topMargin=MARGIN, bottomMargin=MARGIN)

    flow = []
    # ---- Page 1 ----
    flow.append(Paragraph(f"{'Period Summary' if period else 'Daily Summary'} &mdash; {date_str}", styles["H1"]))
    flow.append(Paragraph(f"Machines reporting: {len(machine_results)}", styles["Body9"]))
    flow.append(Spacer(1, 10))

    flow.append(Paragraph("Per-Machine Rollup", styles["H2"]))
    if machine_results:
        flow.append(_per_machine_table(machine_results, styles, config))
    else:
        flow.append(Paragraph("No MoveType=3 moves found across any machine " + ("in this period." if period else "today."), styles["Body9"]))

    # ---- Page 2 ----
    flow.append(PageBreak())
    flow.append(Paragraph("Move Category Breakdown (Necessity x Performance)", styles["H1"]))

    all_results = [r for rs in machine_results.values() for r in rs]
    flow.append(Paragraph("Overall (all machines)", styles["H2"]))
    flow.append(build_category_breakdown_table(all_results, styles))
    flow.append(Spacer(1, 16))

    for machine in sorted(machine_results.keys()):
        results = machine_results[machine]
        flow.append(Paragraph(machine, styles["H2"]))
        flow.append(build_category_breakdown_table(results, styles))
        flow.append(Spacer(1, 14))

    # ---- Page 3: Pickup / Setdown (MoveType 1 & 2) necessity ----
    flow.append(PageBreak())
    flow.append(Paragraph("Pickup / Setdown Necessity (MoveType 1 & 2)", styles["H1"]))
    flow.append(Paragraph(
        "Necessary: the workorder contains both a pickup (1) and a setdown (2) phase. "
        "Unnecessary: the workorder has only a pickup (1) phase, with no setdown (2) phase "
        "following it in the same workorder.", styles["Body9"]))
    flow.append(Spacer(1, 8))

    if pickup_setdown_results and any(pickup_setdown_results.values()):
        flow.append(Paragraph("Per-Machine Rollup", styles["H2"]))
        flow.append(build_pickup_setdown_rollup_table(pickup_setdown_results, styles))
        flow.append(Spacer(1, 16))

        all_ps = [r for rs in pickup_setdown_results.values() for r in rs]
        flow.append(Paragraph("Overall (all machines)", styles["H2"]))
        flow.append(build_pickup_setdown_table(all_ps, styles))
    else:
        flow.append(Paragraph("No MoveType=1/2 (pickup/setdown) workorders found across any "
                               "machine " + ("in this period." if period else "today."), styles["Body9"]))

    doc.build(flow)
    return out_path
