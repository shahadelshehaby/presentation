"""
report_operation.py
======================
Generates "Operation_{date}.pdf".

UPDATES (this revision):
  1. Cases now merge MoveType=3 repositions AND MoveType=1/2 (pickup/
     setdown) workorders into ONE chronological sequence per machine (see
     operation_agent.merge_machine_events / group_all_machines) - e.g.
     "reposition (unnecessary) -> reposition (unnecessary) -> pickup with
     no setdown (unnecessary) -> pickup+setdown (necessary, closes case)"
     is now one case, one row in the illustration, instead of two
     disconnected tables.
  2. Each case's move table is now split into two sections: "Unnecessary
     attempts" first, then the "Necessary / closing move" highlighted in
     green - literally showing the story of a case at a glance.
  3. Energy figures now show "no consumption data" instead of a bare
     "nan" when a phase had no usable current/voltage readings at all
     (see power_agent.py / utils.format_energy_kwh), and a cost column
     (energy_kwh * cost_per_kwh from config) appears wherever
     config.power.cost_per_kwh is set - see utils.format_cost.
  4. Page 1 is now just the title + three at-a-glance tables (merged,
     MoveType=3 only, pickup/setdown only) - the explanatory paragraphs
     were removed. Page 2+ per-case detail now shows ONLY cases that
     contain at least one unnecessary move; fully-necessary cases are
     omitted entirely (still counted in the page-1 tables, just not
     given their own detail section/illustration).
"""
from utils import display_time
from reportlab.platypus import (SimpleDocTemplate, Table, TableStyle, Paragraph,
                                 Spacer, PageBreak)
from reportlab.lib import colors
from reportlab.lib.units import inch

from pdf_style import get_styles, PAGE_SIZE, MARGIN, HEADER_BG, WASTE_ROW_COLOR, NECESSARY_ROW_COLOR
from operation_agent import (group_all_machines, event_kind, event_label, event_distance_m,
                              event_energy_kwh, event_is_unknown, event_is_necessary_confirmed)
from operation_chart import build_case_illustration
from utils import format_hms, format_energy_kwh, format_cost
from columns import movetype_name


def _necessity_label(move) -> str:
    if event_is_unknown(move):
        return "unknown"
    return "necessary" if event_is_necessary_confirmed(move) else "unnecessary"


def _machine_rollup_table(cases_by_machine: dict, styles, config):
    show_cost = config is not None and getattr(config.power, "cost_per_kwh", None) is not None
    headers = ["Machine", "Moves", "Necessary", "Unnecessary", "Unknown",
               "Total distance (m)", "Total energy (kWh)", "Wasted energy (kWh)"]
    if show_cost:
        headers.append(f"Wasted cost ({config.power.currency})")
    header = [Paragraph(h, styles["TableHeader"]) for h in headers]
    data = [header]
    tot_moves = tot_nec = tot_unnec = tot_unk = 0
    tot_dist = tot_energy = tot_wasted = 0.0

    for machine in sorted(cases_by_machine.keys()):
        cases = cases_by_machine[machine]
        n_moves = sum(c.n_moves for c in cases)
        n_nec = sum(c.n_necessary for c in cases)
        n_unnec = sum(c.n_unnecessary for c in cases)
        n_unk = sum(c.n_unknown for c in cases)
        dist = sum(c.total_distance_m for c in cases)
        energy = sum(c.total_energy_kwh for c in cases)
        wasted = sum(c.wasted_energy_kwh for c in cases)

        tot_moves += n_moves
        tot_nec += n_nec
        tot_unnec += n_unnec
        tot_unk += n_unk
        tot_dist += dist
        tot_energy += energy
        tot_wasted += wasted

        row = [
            Paragraph(machine, styles["Body9"]),
            Paragraph(str(n_moves), styles["Body9"]),
            Paragraph(str(n_nec), styles["Body9"]),
            Paragraph(str(n_unnec), styles["Body9"]),
            Paragraph(str(n_unk), styles["Body9"]),
            Paragraph(f"{dist:.1f}", styles["Body9"]),
            Paragraph(f"{energy:.3f}", styles["Body9"]),
            Paragraph(f"{wasted:.3f}", styles["Body9"]),
        ]
        if show_cost:
            row.append(Paragraph(format_cost(wasted, config), styles["Body9"]))
        data.append(row)

    tot_row = [
        Paragraph("<b>TOTAL</b>", styles["Body9"]),
        Paragraph(f"<b>{tot_moves}</b>", styles["Body9"]),
        Paragraph(f"<b>{tot_nec}</b>", styles["Body9"]),
        Paragraph(f"<b>{tot_unnec}</b>", styles["Body9"]),
        Paragraph(f"<b>{tot_unk}</b>", styles["Body9"]),
        Paragraph(f"<b>{tot_dist:.1f}</b>", styles["Body9"]),
        Paragraph(f"<b>{tot_energy:.3f}</b>", styles["Body9"]),
        Paragraph(f"<b>{tot_wasted:.3f}</b>", styles["Body9"]),
    ]
    if show_cost:
        tot_row.append(Paragraph(f"<b>{format_cost(tot_wasted, config)}</b>", styles["Body9"]))
    data.append(tot_row)

    col_widths = [0.9*inch, 0.65*inch, 0.85*inch, 0.95*inch, 0.8*inch,
                  1.05*inch, 1.05*inch, 1.05*inch]
    if show_cost:
        col_widths.append(1.05*inch)

    table = Table(data, repeatRows=1, colWidths=col_widths)
    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), HEADER_BG),
        ("FONTNAME", (0, 1), (-1, -1), "DejaVuSans"),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("BACKGROUND", (0, -1), (-1, -1), colors.HexColor("#eeeeee")),
    ]))
    return table


def _movetype3_only_table(machine_results: dict, styles, config):
    """MoveType=3 moves ONLY (not merged with pickup/setdown) - same column
    shape as _machine_rollup_table, computed straight from machine_results
    (raw MoveType3Result lists) rather than from the merged cases."""
    show_cost = config is not None and getattr(config.power, "cost_per_kwh", None) is not None
    headers = ["Machine", "Moves", "Necessary", "Unnecessary", "Unknown",
               "Total distance (m)", "Total energy (kWh)", "Wasted energy (kWh)"]
    if show_cost:
        headers.append(f"Wasted cost ({config.power.currency})")
    header = [Paragraph(h, styles["TableHeader"]) for h in headers]
    data = [header]
    tot_moves = tot_nec = tot_unnec = tot_unk = 0
    tot_dist = tot_energy = tot_wasted = 0.0

    for machine in sorted(machine_results.keys()):
        results = machine_results[machine]
        n_moves = len(results)
        n_nec = sum(1 for r in results if r.necessity.necessary and not r.necessity.unknown)
        n_unnec = sum(1 for r in results if r.is_unnecessary)
        n_unk = sum(1 for r in results if r.necessity.unknown)
        dist = sum(r.performance.distance_m for r in results)
        energy = sum(r.power.total_energy_kwh for r in results if r.power.has_any_data)
        wasted = sum(r.wasted_energy_kwh for r in results if r.power.has_any_data)

        tot_moves += n_moves
        tot_nec += n_nec
        tot_unnec += n_unnec
        tot_unk += n_unk
        tot_dist += dist
        tot_energy += energy
        tot_wasted += wasted

        row = [
            Paragraph(machine, styles["Body9"]),
            Paragraph(str(n_moves), styles["Body9"]),
            Paragraph(str(n_nec), styles["Body9"]),
            Paragraph(str(n_unnec), styles["Body9"]),
            Paragraph(str(n_unk), styles["Body9"]),
            Paragraph(f"{dist:.1f}", styles["Body9"]),
            Paragraph(f"{energy:.3f}", styles["Body9"]),
            Paragraph(f"{wasted:.3f}", styles["Body9"]),
        ]
        if show_cost:
            row.append(Paragraph(format_cost(wasted, config), styles["Body9"]))
        data.append(row)

    tot_row = [
        Paragraph("<b>TOTAL</b>", styles["Body9"]),
        Paragraph(f"<b>{tot_moves}</b>", styles["Body9"]),
        Paragraph(f"<b>{tot_nec}</b>", styles["Body9"]),
        Paragraph(f"<b>{tot_unnec}</b>", styles["Body9"]),
        Paragraph(f"<b>{tot_unk}</b>", styles["Body9"]),
        Paragraph(f"<b>{tot_dist:.1f}</b>", styles["Body9"]),
        Paragraph(f"<b>{tot_energy:.3f}</b>", styles["Body9"]),
        Paragraph(f"<b>{tot_wasted:.3f}</b>", styles["Body9"]),
    ]
    if show_cost:
        tot_row.append(Paragraph(f"<b>{format_cost(tot_wasted, config)}</b>", styles["Body9"]))
    data.append(tot_row)

    col_widths = [0.9*inch, 0.65*inch, 0.85*inch, 0.95*inch, 0.8*inch,
                  1.05*inch, 1.05*inch, 1.05*inch]
    if show_cost:
        col_widths.append(1.05*inch)

    table = Table(data, repeatRows=1, colWidths=col_widths)
    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), HEADER_BG),
        ("FONTNAME", (0, 1), (-1, -1), "DejaVuSans"),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("BACKGROUND", (0, -1), (-1, -1), colors.HexColor("#eeeeee")),
    ]))
    return table


def _pickup_setdown_only_table(pickup_setdown_results: dict, styles, config):
    """Pickup/setdown (MoveType 1 & 2) workorders ONLY - same column shape
    as _machine_rollup_table/_movetype3_only_table (Machine, Moves,
    Necessary, Unnecessary, Unknown, Total distance (m), Total energy
    (kWh), Wasted energy (kWh)[, Wasted cost]). Distance is the net
    displacement of whichever axis moved the most during each workorder
    (pickup_setdown_agent._dominant_axis_and_distance) - shows "-" for a
    workorder only if it genuinely couldn't be computed (e.g. required
    position columns missing from that file)."""
    show_cost = config is not None and getattr(config.power, "cost_per_kwh", None) is not None
    headers = ["Machine", "Moves", "Necessary", "Unnecessary", "Unknown",
               "Total distance (m)", "Total energy (kWh)", "Wasted energy (kWh)"]
    if show_cost:
        headers.append(f"Wasted cost ({config.power.currency})")
    header = [Paragraph(h, styles["TableHeader"]) for h in headers]
    data = [header]
    tot_moves = tot_nec = tot_unnec = tot_unk = 0
    tot_dist = tot_energy = tot_wasted = 0.0

    for machine in sorted(pickup_setdown_results.keys()):
        results = pickup_setdown_results[machine]
        n_moves = len(results)
        n_nec = sum(1 for r in results if r.pickup_setdown.necessary and not r.pickup_setdown.unknown)
        n_unnec = sum(1 for r in results if r.is_unnecessary)
        n_unk = sum(1 for r in results if r.pickup_setdown.unknown)
        dist = sum(r.pickup_setdown.distance_m for r in results if r.pickup_setdown.distance_m is not None)
        energy = sum(r.power.total_energy_kwh for r in results if r.power and r.power.has_any_data)
        wasted = sum(r.wasted_energy_kwh for r in results if r.power and r.power.has_any_data)

        tot_moves += n_moves
        tot_nec += n_nec
        tot_unnec += n_unnec
        tot_unk += n_unk
        tot_dist += dist
        tot_energy += energy
        tot_wasted += wasted

        row = [
            Paragraph(machine, styles["Body9"]),
            Paragraph(str(n_moves), styles["Body9"]),
            Paragraph(str(n_nec), styles["Body9"]),
            Paragraph(str(n_unnec), styles["Body9"]),
            Paragraph(str(n_unk), styles["Body9"]),
            Paragraph(f"{dist:.1f}", styles["Body9"]),
            Paragraph(f"{energy:.3f}", styles["Body9"]),
            Paragraph(f"{wasted:.3f}", styles["Body9"]),
        ]
        if show_cost:
            row.append(Paragraph(format_cost(wasted, config), styles["Body9"]))
        data.append(row)

    tot_row = [
        Paragraph("<b>TOTAL</b>", styles["Body9"]),
        Paragraph(f"<b>{tot_moves}</b>", styles["Body9"]),
        Paragraph(f"<b>{tot_nec}</b>", styles["Body9"]),
        Paragraph(f"<b>{tot_unnec}</b>", styles["Body9"]),
        Paragraph(f"<b>{tot_unk}</b>", styles["Body9"]),
        Paragraph(f"<b>{tot_dist:.1f}</b>", styles["Body9"]),
        Paragraph(f"<b>{tot_energy:.3f}</b>", styles["Body9"]),
        Paragraph(f"<b>{tot_wasted:.3f}</b>", styles["Body9"]),
    ]
    if show_cost:
        tot_row.append(Paragraph(f"<b>{format_cost(tot_wasted, config)}</b>", styles["Body9"]))
    data.append(tot_row)

    col_widths = [0.9*inch, 0.65*inch, 0.85*inch, 0.95*inch, 0.8*inch,
                  1.05*inch, 1.05*inch, 1.05*inch]
    if show_cost:
        col_widths.append(1.05*inch)

    table = Table(data, repeatRows=1, colWidths=col_widths)
    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), HEADER_BG),
        ("FONTNAME", (0, 1), (-1, -1), "DejaVuSans"),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("BACKGROUND", (0, -1), (-1, -1), colors.HexColor("#eeeeee")),
    ]))
    return table
    """One row of a case's move table - works for both a MoveType=3 move
    and a pickup/setdown workorder."""
    kind = event_kind(m)
    if kind == "movetype3":
        move_type_txt = movetype_name(3)
        next_type = m.necessity.next_move_type
        next_type_txt = movetype_name(next_type) if next_type is not None else "-"
        gantry_pos_txt = (f"{m.performance.position_end:.2f}"
                           if m.performance.position_end is not None else "-")
    else:
        move_type_txt = event_label(m)
        next_type_txt = (movetype_name(m.pickup_setdown.next_move_type)
                          if m.pickup_setdown.next_move_type is not None else "-")
        gantry_pos_txt = "-"

    dist = event_distance_m(m)
    dist_txt = f"{dist:.1f}" if dist is not None else "-"

    energy_val, has_energy = event_energy_kwh(m)
    pw = getattr(m, "power", None)
    energy_txt = format_energy_kwh(pw) + (" \u26a0" if m.is_unnecessary and has_energy else "")

    row = [
        Paragraph(str(m.workorder), styles["Body9"]),
        Paragraph(move_type_txt, styles["Body9"]),
        Paragraph(display_time(m.time_start), styles["Body9"]),
        Paragraph(f"{m.duration_s:.1f}", styles["Body9"]),
        Paragraph(gantry_pos_txt, styles["Body9"]),
        Paragraph(next_type_txt, styles["Body9"]),
        Paragraph(_necessity_label(m), styles["Body9"]),
        Paragraph(dist_txt, styles["Body9"]),
        Paragraph(energy_txt, styles["Body9"]),
    ]
    if show_cost:
        cost_val = energy_val if (m.is_unnecessary and has_energy) else None
        row.append(Paragraph(format_cost(cost_val, config) if cost_val is not None else "-",
                              styles["Body9"]))
    return row


def _move_row(m, styles, config, show_cost):
    """One row of a case's move table - works for both a MoveType=3 move
    and a pickup/setdown workorder."""
    kind = event_kind(m)
    if kind == "movetype3":
        move_type_txt = movetype_name(3)
        next_type = m.necessity.next_move_type
        next_type_txt = movetype_name(next_type) if next_type is not None else "-"
        gantry_pos_txt = (f"{m.performance.position_end:.2f}"
                           if m.performance.position_end is not None else "-")
    else:
        move_type_txt = event_label(m)
        next_type_txt = (movetype_name(m.pickup_setdown.next_move_type)
                          if m.pickup_setdown.next_move_type is not None else "-")
        gantry_pos_txt = "-"

    dist = event_distance_m(m)
    dist_txt = f"{dist:.1f}" if dist is not None else "-"

    energy_val, has_energy = event_energy_kwh(m)
    pw = getattr(m, "power", None)
    energy_txt = format_energy_kwh(pw) + (" \u26a0" if m.is_unnecessary and has_energy else "")

    row = [
        Paragraph(str(m.workorder), styles["Body9"]),
        Paragraph(move_type_txt, styles["Body9"]),
        Paragraph(display_time(m.time_start), styles["Body9"]),
        Paragraph(f"{m.duration_s:.1f}", styles["Body9"]),
        Paragraph(gantry_pos_txt, styles["Body9"]),
        Paragraph(next_type_txt, styles["Body9"]),
        Paragraph(_necessity_label(m), styles["Body9"]),
        Paragraph(dist_txt, styles["Body9"]),
        Paragraph(energy_txt, styles["Body9"]),
    ]
    if show_cost:
        cost_val = energy_val if (m.is_unnecessary and has_energy) else None
        row.append(Paragraph(format_cost(cost_val, config) if cost_val is not None else "-",
                              styles["Body9"]))
    return row


def _moves_table(moves, styles, config, highlight_color=None):
    show_cost = config is not None and getattr(config.power, "cost_per_kwh", None) is not None
    headers = ["Workorder", "Type", "Time", "Duration (s)", "Gantry actual position (m)",
               "Next move type", "Necessity", "Distance (m)", "Energy (kWh)"]
    if show_cost:
        headers.append(f"Cost ({config.power.currency})")
    header = [Paragraph(h, styles["TableHeader"]) for h in headers]
    data = [header]
    for m in moves:
        data.append(_move_row(m, styles, config, show_cost))

    col_widths = [0.65*inch, 0.95*inch, 0.75*inch, 0.75*inch, 1.2*inch,
                  0.95*inch, 0.95*inch, 0.8*inch, 0.85*inch]
    if show_cost:
        col_widths.append(0.75*inch)

    style = [
        ("BACKGROUND", (0, 0), (-1, 0), HEADER_BG),
        ("FONTNAME", (0, 1), (-1, -1), "DejaVuSans"),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
    ]
    if highlight_color is not None:
        style.append(("BACKGROUND", (0, 1), (-1, -1), highlight_color))
    table = Table(data, repeatRows=1, colWidths=col_widths)
    table.setStyle(TableStyle(style))
    return table


def _case_detail_flow(case, styles, config):
    flow = []
    closing_move = case.moves[-1]
    if case.closed_by_pickup:
        kind = event_kind(closing_move)
        if kind == "movetype3":
            cn = closing_move.necessity
            closed_txt = (f"closed by workorder {closing_move.workorder}'s next move "
                          f"(MoveType {cn.next_move_type}, a real pickup)")
        else:
            closed_txt = (f"closed by workorder {closing_move.workorder} "
                          f"(completed pickup+setdown cycle)")
    else:
        closed_txt = "OPEN \u2014 file ended before a genuine pickup/completed cycle occurred next"

    flow.append(Paragraph(f"Case {case.case_num} &nbsp; ({case.machine})", styles["H2"]))
    flow.append(Paragraph(
        f"Time: {case.time_start} &rarr; {case.time_end} &nbsp; Duration: {format_hms(case.total_duration_s)} "
        f"&nbsp; Moves: {case.n_moves} ({case.n_unnecessary} unnecessary, {case.n_necessary} necessary, "
        f"{case.n_unknown} unknown)", styles["Body9"]))
    flow.append(Paragraph(closed_txt, styles["Body9"]))

    total_energy_txt = f"{case.total_energy_kwh:.3f} kWh" if case.total_energy_kwh else "0.000 kWh"
    wasted_txt = f"{case.wasted_energy_kwh:.3f} kWh"
    cost_line = ""
    if config is not None and getattr(config.power, "cost_per_kwh", None) is not None:
        cost_line = f" &nbsp; <b>Wasted energy cost: {format_cost(case.wasted_energy_kwh, config)}</b>"
    flow.append(Paragraph(
        f"Total distance: {case.total_distance_m:.1f} m &nbsp; Total energy: {total_energy_txt} "
        f"&nbsp; <b>Wasted energy: {wasted_txt}</b>"
        + (f" ({100*case.wasted_energy_kwh/case.total_energy_kwh:.1f}% of this case's energy)"
           if case.total_energy_kwh > 0 else "")
        + cost_line,
        styles["Body9"]))
    flow.append(Spacer(1, 6))

    # ---- Section 1: unnecessary attempts (if any) ----
    unnecessary = case.unnecessary_moves
    if unnecessary:
        flow.append(Paragraph("Unnecessary attempts", styles["H3"]))
        flow.append(_moves_table(unnecessary, styles, config, highlight_color=WASTE_ROW_COLOR))
        flow.append(Spacer(1, 8))

    # ---- Section 2: the necessary / closing move ----
    remaining = [m for m in case.moves if id(m) not in {id(u) for u in unnecessary}]
    if remaining:
        label = "Necessary move (closes this case)" if case.closed_by_pickup else \
                "Final move in this (still open) case"
        flow.append(Paragraph(label, styles["H3"]))
        highlight = NECESSARY_ROW_COLOR if case.closed_by_pickup else None
        flow.append(_moves_table(remaining, styles, config, highlight_color=highlight))

    flow.append(Spacer(1, 10))
    illustration = build_case_illustration(case)
    if illustration is not None:
        flow.append(illustration)
    flow.append(Spacer(1, 30))
    return flow


def generate_operation_report(date_str, machine_results: dict, out_path, pickup_setdown_results: dict = None,
                               config=None, period=False):
    """machine_results: {machine_name: [MoveType3Result, ...]} - same input
    shape as report_summary.generate_summary_report().
    pickup_setdown_results: {machine_name: [PickupSetdownWorkorderResult, ...]}
    config: Config (from config_loader.load_config) - needed for the
    optional cost column (config.power.cost_per_kwh). Reports still work
    without it; the cost column/lines are simply omitted."""
    pickup_setdown_results = pickup_setdown_results or {}
    styles = get_styles()
    doc = SimpleDocTemplate(out_path, pagesize=PAGE_SIZE,
                             leftMargin=MARGIN, rightMargin=MARGIN,
                             topMargin=MARGIN, bottomMargin=MARGIN)

    # Cases now merge MoveType=3 moves AND pickup/setdown workorders into
    # one chronological sequence per machine - see operation_agent.py.
    cases_by_machine = group_all_machines(machine_results, pickup_setdown_results)
    flow = []

    # ---- Page 1: overview ----
    flow.append(Paragraph(f"Operation Report &mdash; {date_str}", styles["H1"]))
    flow.append(Spacer(1, 6))

    if any(cases_by_machine.values()):
        flow.append(_machine_rollup_table(cases_by_machine, styles, config))
    else:
        flow.append(Paragraph("No moves found across any machine " + ("in this period." if period else "today."), styles["Body9"]))

    # ---- Page 1 (cont'd): MoveType=3 only ----
    flow.append(Spacer(1, 18))
    flow.append(Paragraph("MoveType=3 Only", styles["H2"]))
    if machine_results and any(machine_results.values()):
        flow.append(_movetype3_only_table(machine_results, styles, config))
    else:
        flow.append(Paragraph("No MoveType=3 moves found across any machine " + ("in this period." if period else "today."), styles["Body9"]))

    # ---- Page 1 (cont'd): Pickup / Setdown (MoveType 1 & 2) ----
    flow.append(Spacer(1, 18))
    flow.append(Paragraph("Pickup / Setdown Necessity (MoveType 1 & 2)", styles["H2"]))
    if pickup_setdown_results and any(pickup_setdown_results.values()):
        flow.append(_pickup_setdown_only_table(pickup_setdown_results, styles, config))
    else:
        flow.append(Paragraph("No MoveType=1/2 (pickup/setdown) workorders found across any "
                               "machine " + ("in this period." if period else "today."), styles["Body9"]))

    flow.append(PageBreak())

    # ---- Page 2+: per-machine, per-case detail - ONLY cases that contain
    # at least one unnecessary move (fully-necessary cases are omitted). ----
    for machine in sorted(cases_by_machine.keys()):
        cases = [c for c in cases_by_machine[machine] if c.n_unnecessary > 0]
        if not cases:
            continue
        flow.append(Paragraph(f"Machine {machine}", styles["H1"]))
        for case in cases:
            flow.extend(_case_detail_flow(case, styles, config))

    doc.build(flow)
    return out_path
