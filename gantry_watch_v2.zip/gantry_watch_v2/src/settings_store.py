"""
settings_store.py
==================
Everything the web UI needs to read, validate and save settings.

- A *profile* is one complete set of analysis parameters, stored as a
  golden_standard-format XML file in profiles/<name>.xml. Because the file
  format is unchanged, config_loader.load_config() reads a profile exactly
  like it reads config/golden_standard.xml.
- config/golden_standard.xml is the read-only "factory defaults". The
  "Default" profile is created from it on first start.
- app_settings.json holds UI/server settings (port, network access, which
  profile is active). Port changes take effect after a restart.
"""
import json
import os
import re
import shutil
import xml.etree.ElementTree as ET
from xml.dom import minidom

from config_loader import load_config

AXES = ("gantry", "trolley", "hoist")
AXIS_FIELDS = ("acceleration_mps2", "deceleration_mps2", "top_speed_mps", "offset_s")
THRESHOLD_FIELDS = (
    "hoist_safe_height_m",
    "step_match_tolerance_m",
    "necessity_tolerance_m",
    "aborted_min_target_distance_m",
    "aborted_completion_pct",
    "performance_slow_threshold_pct",
)
FORBIDDEN_PORTS = {5000, 5002, 5030, 5050}
DEFAULT_PORT = 8765
PROFILE_NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9 _\-]{0,39}$")


class SettingsError(ValueError):
    """Raised with a list of human-readable problems."""

    def __init__(self, errors):
        super().__init__("; ".join(errors))
        self.errors = errors


class SettingsStore:
    def __init__(self, project_root: str):
        self.root = project_root
        self.factory_xml = os.path.join(project_root, "config", "golden_standard.xml")
        self.profiles_dir = os.path.join(project_root, "profiles")
        self.app_settings_path = os.path.join(project_root, "app_settings.json")
        os.makedirs(self.profiles_dir, exist_ok=True)
        if not self.list_profiles():
            shutil.copyfile(self.factory_xml, self.profile_path("Default"))

    # ------------------------------------------------------------ profiles
    def profile_path(self, name: str) -> str:
        return os.path.join(self.profiles_dir, f"{name}.xml")

    def list_profiles(self):
        names = [os.path.splitext(f)[0] for f in os.listdir(self.profiles_dir)
                 if f.lower().endswith(".xml")]
        return sorted(names, key=lambda n: (n != "Default", n.lower()))

    def check_name(self, name: str) -> str:
        name = (name or "").strip()
        if not PROFILE_NAME_RE.match(name):
            raise SettingsError(["Profile names can use letters, numbers, spaces, - and _ "
                                 "(up to 40 characters)."])
        return name

    def load_profile(self, name: str) -> dict:
        path = self.profile_path(self.check_name(name))
        if not os.path.isfile(path):
            raise SettingsError([f"Profile '{name}' does not exist."])
        return config_to_dict(load_config(path))

    def load_profile_config(self, name: str):
        return load_config(self.profile_path(self.check_name(name)))

    def factory_defaults(self) -> dict:
        return config_to_dict(load_config(self.factory_xml))

    def save_profile(self, name: str, data: dict) -> dict:
        name = self.check_name(name)
        clean = validate(data)
        with open(self.profile_path(name), "w", encoding="utf-8") as f:
            f.write(dict_to_xml(clean, name))
        # Round-trip through the real loader so we never save a file the
        # analysis can't read.
        return self.load_profile(name)

    def delete_profile(self, name: str):
        name = self.check_name(name)
        if len(self.list_profiles()) <= 1:
            raise SettingsError(["You can't delete the only profile."])
        path = self.profile_path(name)
        if os.path.isfile(path):
            os.remove(path)
        app = self.load_app_settings()
        if app["active_profile"] == name:
            app["active_profile"] = self.list_profiles()[0]
            self.save_app_settings(app)

    def import_profile_xml(self, name: str, xml_bytes: bytes) -> dict:
        name = self.check_name(name)
        tmp = self.profile_path(name) + ".tmp"
        with open(tmp, "wb") as f:
            f.write(xml_bytes)
        try:
            data = config_to_dict(load_config(tmp))
        except Exception as e:
            raise SettingsError([f"That XML file could not be read as settings: {e}"])
        finally:
            if os.path.exists(tmp):
                os.remove(tmp)
        return self.save_profile(name, data)

    def profile_xml_text(self, name: str) -> str:
        with open(self.profile_path(self.check_name(name)), encoding="utf-8") as f:
            return f.read()

    # -------------------------------------------------------- app settings
    def load_app_settings(self) -> dict:
        data = {"port": DEFAULT_PORT, "allow_network": False, "open_browser": True,
                "active_profile": "Default"}
        if os.path.isfile(self.app_settings_path):
            try:
                with open(self.app_settings_path, encoding="utf-8") as f:
                    data.update(json.load(f))
            except (OSError, ValueError):
                pass
        if data["active_profile"] not in self.list_profiles():
            data["active_profile"] = self.list_profiles()[0]
        return data

    def save_app_settings(self, data: dict) -> dict:
        current = self.load_app_settings()
        errors = []
        if "port" in data:
            try:
                port = int(data["port"])
            except (TypeError, ValueError):
                port = -1
            if not 1024 <= port <= 65535:
                errors.append("Port must be a whole number between 1024 and 65535.")
            elif port in FORBIDDEN_PORTS:
                errors.append(f"Port {port} is reserved. Avoid 5000, 5002, 5030 and 5050.")
            current["port"] = port
        if "allow_network" in data:
            current["allow_network"] = bool(data["allow_network"])
        if "open_browser" in data:
            current["open_browser"] = bool(data["open_browser"])
        if "active_profile" in data:
            if data["active_profile"] not in self.list_profiles():
                errors.append(f"Profile '{data['active_profile']}' does not exist.")
            current["active_profile"] = data["active_profile"]
        if errors:
            raise SettingsError(errors)
        with open(self.app_settings_path, "w", encoding="utf-8") as f:
            json.dump(current, f, indent=2)
        return current


# ---------------------------------------------------------------- converters
def config_to_dict(cfg) -> dict:
    pc = cfg.columns.power_columns
    return {
        "axes": {a: {k: getattr(cfg.axes[a], k) for k in AXIS_FIELDS} for a in AXES if a in cfg.axes},
        "thresholds": {k: getattr(cfg.thresholds, k) for k in THRESHOLD_FIELDS},
        "expected_next_move_type": cfg.expected_next_move_type,
        "power": {
            "voltage_v": cfg.power.voltage_v,
            "power_factor": cfg.power.power_factor,
            "cost_per_kwh": cfg.power.cost_per_kwh,
            "currency": cfg.power.currency,
        },
        "columns": {
            "reference": dict(cfg.columns.reference),
            "actual_candidates": {a: list(v) for a, v in cfg.columns.actual_candidates.items()},
            "speed_candidates": {a: list(v) for a, v in cfg.columns.speed_candidates.items()},
            "power_columns": {a: {k: list(v) for k, v in d.items()} for a, d in pc.items()},
        },
    }


def _num(value, label, errors, minimum=None, maximum=None, allow_zero=True, allow_none=False):
    if value is None or (isinstance(value, str) and value.strip() == ""):
        if allow_none:
            return None
        errors.append(f"{label} is required.")
        return None
    try:
        v = float(value)
    except (TypeError, ValueError):
        errors.append(f"{label} must be a number.")
        return None
    if v != v:  # NaN
        errors.append(f"{label} must be a number.")
        return None
    if not allow_zero and v == 0:
        errors.append(f"{label} must be greater than 0.")
    if minimum is not None and v < minimum:
        errors.append(f"{label} must be at least {minimum}.")
    if maximum is not None and v > maximum:
        errors.append(f"{label} must be at most {maximum}.")
    return v


def _names(value):
    if isinstance(value, str):
        value = value.split(",")
    return [str(v).strip() for v in (value or []) if str(v).strip()]


def validate(data: dict) -> dict:
    """Checks every field and returns a cleaned copy. Raises SettingsError
    listing every problem at once, so the UI can show them together."""
    errors = []
    out = {"axes": {}, "thresholds": {}, "power": {},
           "columns": {"reference": {}, "actual_candidates": {}, "speed_candidates": {},
                       "power_columns": {}}}

    labels = {"acceleration_mps2": "acceleration", "deceleration_mps2": "deceleration",
              "top_speed_mps": "top speed", "offset_s": "time offset"}
    for axis in AXES:
        src = (data.get("axes") or {}).get(axis) or {}
        out["axes"][axis] = {}
        for k in AXIS_FIELDS:
            out["axes"][axis][k] = _num(src.get(k), f"{axis.title()} {labels[k]}", errors,
                                        minimum=0, allow_zero=(k == "offset_s"))

    th = data.get("thresholds") or {}
    th_labels = {
        "hoist_safe_height_m": "Hoist safe height",
        "step_match_tolerance_m": "Position match tolerance",
        "necessity_tolerance_m": "Necessity tolerance",
        "aborted_min_target_distance_m": "Minimum distance for abort check",
        "aborted_completion_pct": "Abort completion %",
        "performance_slow_threshold_pct": "Slow threshold %",
    }
    for k in THRESHOLD_FIELDS:
        mx = 100 if k == "aborted_completion_pct" else None
        out["thresholds"][k] = _num(th.get(k), th_labels[k], errors, minimum=0, maximum=mx)

    try:
        nm = int(data.get("expected_next_move_type", 1))
    except (TypeError, ValueError):
        nm = -1
    if nm not in (1, 2):
        errors.append("Expected next move must be pickup (1) or setdown (2).")
    out["expected_next_move_type"] = nm

    pw = data.get("power") or {}
    out["power"]["voltage_v"] = _num(pw.get("voltage_v"), "Supply voltage", errors, minimum=0, allow_zero=False)
    out["power"]["power_factor"] = _num(pw.get("power_factor"), "Power factor", errors,
                                        minimum=0, maximum=1, allow_zero=False)
    out["power"]["cost_per_kwh"] = _num(pw.get("cost_per_kwh"), "Cost per kWh", errors,
                                        minimum=0, allow_none=True)
    cur = str(pw.get("currency") or "").strip()
    if not cur or len(cur) > 8:
        errors.append("Currency must be 1-8 characters, e.g. AED or USD.")
    out["power"]["currency"] = cur

    cols = data.get("columns") or {}
    for axis in AXES:
        ref = str((cols.get("reference") or {}).get(axis) or "").strip()
        if not ref:
            errors.append(f"{axis.title()} reference column is required.")
        out["columns"]["reference"][axis] = ref

        actual = _names((cols.get("actual_candidates") or {}).get(axis))
        if not actual:
            errors.append(f"{axis.title()} position needs at least one column name.")
        out["columns"]["actual_candidates"][axis] = actual

        out["columns"]["speed_candidates"][axis] = _names((cols.get("speed_candidates") or {}).get(axis))

        pc = ((cols.get("power_columns") or {}).get(axis)) or {}
        current, voltage, legacy = _names(pc.get("current")), _names(pc.get("voltage")), _names(pc.get("legacy"))
        if len(current) != len(voltage):
            errors.append(f"{axis.title()}: give one voltage column for each current column.")
        if legacy and len(legacy) != 2:
            errors.append(f"{axis.title()}: legacy drive columns need exactly two names, or none.")
        out["columns"]["power_columns"][axis] = {"current": current, "voltage": voltage, "legacy": legacy}

    if errors:
        raise SettingsError(errors)
    return out


def _fmt(v):
    if v is None:
        return ""
    if float(v).is_integer():
        return str(int(v)) if abs(v) >= 1 else f"{v:.1f}"
    return repr(float(v))


def dict_to_xml(d: dict, profile_name: str = "") -> str:
    root = ET.Element("golden_standard")
    root.append(ET.Comment(f" Settings profile '{profile_name}' - saved from the PLC Analyzer UI. "
                           "Units: m, m/s, m/s^2, s. "))
    for axis in AXES:
        ax = ET.SubElement(root, "axis", name=axis)
        for k in AXIS_FIELDS:
            ET.SubElement(ax, k).text = _fmt(d["axes"][axis][k])

    th = ET.SubElement(root, "thresholds")
    for k in THRESHOLD_FIELDS:
        ET.SubElement(th, k).text = _fmt(d["thresholds"][k])

    cols = ET.SubElement(root, "columns")
    ref = ET.SubElement(cols, "reference")
    for axis in AXES:
        ET.SubElement(ref, axis).text = d["columns"]["reference"][axis]
    for section in ("actual_candidates", "speed_candidates"):
        sec = ET.SubElement(cols, section)
        for axis in AXES:
            ax = ET.SubElement(sec, axis)
            for name in d["columns"][section][axis]:
                ET.SubElement(ax, "candidate").text = name
    pcs = ET.SubElement(cols, "power_columns")
    for axis in AXES:
        ax = ET.SubElement(pcs, axis)
        for kind in ("current", "voltage", "legacy"):
            for name in d["columns"]["power_columns"][axis][kind]:
                ET.SubElement(ax, kind).text = name

    nec = ET.SubElement(root, "necessity")
    ET.SubElement(nec, "expected_next_move_type").text = str(d["expected_next_move_type"])

    pw = ET.SubElement(root, "power")
    ET.SubElement(pw, "voltage_v").text = _fmt(d["power"]["voltage_v"])
    ET.SubElement(pw, "power_factor").text = _fmt(d["power"]["power_factor"])
    ET.SubElement(pw, "cost_per_kwh").text = _fmt(d["power"]["cost_per_kwh"])
    ET.SubElement(pw, "currency").text = d["power"]["currency"]

    raw = ET.tostring(root, encoding="unicode")
    pretty = minidom.parseString(raw).toprettyxml(indent="  ", encoding="UTF-8").decode("utf-8")
    return "\n".join(line for line in pretty.splitlines() if line.strip()) + "\n"
