"""
pipeline.py
============
Two steps, shared by the web UI (library.py) and the command line:

  analyze_file()   one PLC file -> MoveType=3 results, pickup/setdown results,
                   and the calendar dates present in the file.
  build_reports()  already-analyzed results (filtered by the caller) ->
                   PDFs, either one set per day ("daily") or one set for the
                   whole date range ("period").

Daily mode writes into <out_dir>/<date>/:
    <crane>_<date>.pdf, Summary_<date>.pdf, Operation_<date>.pdf
Period mode writes into <out_dir>/<from>_to_<to>/:
    Overview_<from>_to_<to>.pdf   (per-day / per-lane / per-crane trend - report_period.py)
    Summary_..., Operation_...    (the same reports, built over the whole period)
    <crane>_... (optional - one detail page per move, so these get long)
"""
import json
import os
from collections import defaultdict

from orchestrator import analyze_machine_day_file
from report_machine import generate_machine_report
from report_summary import generate_summary_report
from report_operation import generate_operation_report
from report_period import generate_period_report
from columns import load_enum_overrides_from_columns_info, set_enum_overrides
from utils import ensure_dir, display_date, set_show_date_in_times


def apply_columns_info(path, log=print):
    """Loads code->description names from a Columns_info file (or falls back
    to the built-in names if there is none)."""
    if path and os.path.isfile(path):
        try:
            set_enum_overrides(load_enum_overrides_from_columns_info(path))
            return
        except Exception as e:
            log(f"WARNING: could not read '{os.path.basename(path)}': {e}. Using built-in names.")
    set_enum_overrides({})


def analyze_file(path, machine, config):
    return analyze_machine_day_file(path, machine, config)


def period_label(date_from, date_to):
    return display_date(date_from) if date_from == date_to else \
        f"{display_date(date_from)} to {display_date(date_to)}"


def build_reports(by_date, ps_by_date, config, out_dir, mode="daily", date_from=None, date_to=None,
                  include_machine_reports=True, write_json=False, filters_text="", log=print):
    """
    by_date:    {date: {machine: [MoveType3Result]}}   (already filtered)
    ps_by_date: {date: {machine: [PickupSetdownWorkorderResult]}}
    Returns (outputs, failed) where outputs is a list of
    {"group", "group_label", "kind", "machine", "name", "relpath"}.
    """
    outputs, failed = [], []
    dates = sorted(set(by_date) | set(ps_by_date))

    def add(group, group_label, kind, machine, path):
        outputs.append({"group": group, "group_label": group_label, "kind": kind, "machine": machine,
                        "name": os.path.basename(path),
                        "relpath": os.path.relpath(path, out_dir).replace(os.sep, "/")})

    def write_set(group, label, machine_results, ps_results, suffix, period):
        folder = ensure_dir(os.path.join(out_dir, group))
        machines = sorted(set(machine_results) | set(ps_results))
        if include_machine_reports:
            for machine in machines:
                out_pdf = os.path.join(folder, f"{machine}_{suffix}.pdf")
                generate_machine_report(machine, label, machine_results.get(machine, []), out_pdf,
                                        pickup_setdown_results=ps_results.get(machine, []), config=config)
                add(group, label, "machine", machine, out_pdf)
                log(f"  Wrote {os.path.basename(out_pdf)}")
        if write_json:
            for machine in machines:
                out_json = os.path.join(folder, f"{machine}_{suffix}.json")
                with open(out_json, "w") as f:
                    json.dump({
                        "movetype3": [r.to_dict() for r in machine_results.get(machine, [])],
                        "pickup_setdown": [r.to_dict() for r in ps_results.get(machine, [])],
                    }, f, indent=2, default=str)
                add(group, label, "json", machine, out_json)
        summary_pdf = os.path.join(folder, f"Summary_{suffix}.pdf")
        generate_summary_report(label, machine_results, summary_pdf,
                                pickup_setdown_results=ps_results, config=config, period=period)
        add(group, label, "summary", None, summary_pdf)
        log(f"  Wrote {os.path.basename(summary_pdf)}")
        operation_pdf = os.path.join(folder, f"Operation_{suffix}.pdf")
        generate_operation_report(label, machine_results, operation_pdf,
                                  pickup_setdown_results=ps_results, config=config, period=period)
        add(group, label, "operation", None, operation_pdf)
        log(f"  Wrote {os.path.basename(operation_pdf)}")

    if mode == "period":
        date_from = date_from or (dates[0] if dates else "")
        date_to = date_to or (dates[-1] if dates else "")
        group = date_from if date_from == date_to else f"{date_from}_to_{date_to}"
        label = period_label(date_from, date_to)
        set_show_date_in_times(date_from != date_to)
        try:
            overview = os.path.join(ensure_dir(os.path.join(out_dir, group)), f"Overview_{group}.pdf")
            generate_period_report(label, by_date, ps_by_date, overview, filters_text, config)
            add(group, label, "overview", None, overview)
            log(f"  Wrote {os.path.basename(overview)}")

            merged, merged_ps = defaultdict(list), defaultdict(list)
            for d in dates:
                for m, rs in by_date.get(d, {}).items():
                    merged[m].extend(rs)
                for m, rs in ps_by_date.get(d, {}).items():
                    merged_ps[m].extend(rs)
            for lst in list(merged.values()) + list(merged_ps.values()):
                lst.sort(key=lambda r: r.time_start)
            write_set(group, label, dict(merged), dict(merged_ps), group, period=True)
        except Exception as e:
            log(f"  ERROR generating the period reports: {e}")
            failed.append({"date": label, "error": str(e)})
        finally:
            set_show_date_in_times(False)
    else:
        set_show_date_in_times(False)
        for d in dates:
            try:
                write_set(d, display_date(d), by_date.get(d, {}), ps_by_date.get(d, {}), d, period=False)
            except Exception as e:
                # One bad day must not stop the remaining days.
                log(f"  ERROR generating report(s) for {display_date(d)}: {e}")
                failed.append({"date": display_date(d), "error": str(e)})
    return outputs, failed


def run_pipeline(files, config, out_dir, write_json=False, mode="daily", log=print):
    """Command-line helper: analyze files [(path, machine, name)] and write
    daily (or one period) report set(s) for everything found."""
    by_date = defaultdict(lambda: defaultdict(list))
    ps_by_date = defaultdict(lambda: defaultdict(list))
    for path, machine, fname in files:
        log(f"Analyzing {fname}  (crane {machine}) ...")
        try:
            results, ps_results, _ = analyze_file(path, machine, config)
        except Exception as e:
            log(f"  ERROR analyzing {fname}: {e}")
            continue
        for r in results:
            by_date[r.date][machine].append(r)
        for r in ps_results:
            ps_by_date[r.date][machine].append(r)
        log(f"  -> {len(results)} reposition move(s), {len(ps_results)} pickup workorder(s)")
    outputs, failed = build_reports(by_date, ps_by_date, config, out_dir, mode=mode,
                                    write_json=write_json, log=log)
    log("Done.")
    return outputs, failed
