"""
columns.py
==========
- Loads Columns_info.csv (column, code, descrition) for reference/lookups.
- Resolves the ACTUAL and REFERENCE position column for each axis dynamically
  against whatever candidate names are present in a given file's header, using
  the priority list from golden_standard.xml. Never hardcode a single name -
  the gantry actual-position column has been seen as In_GANTRY1, GantryPos and
  In_GANTRY across different exports.
"""
import pandas as pd

STEP_NAMES = {
    0: "not defined",
    1: "auto not selected",
    2: "waiting for work order",
    3: "waiting for start order",
    4: "lift active",
    5: "move active",
    6: "lower active",
    7: "land active",
    8: "repeat land active",
    9: "MI active",
    10: "lower manually",
}

MOVETYPE_NAMES = {
    0: "not active",
    1: "pickup",
    2: "setdown",
    3: "move-only",
    4: "park",
    5: "calibration",
}

LANDINGTYPE_NAMES = {
    0: "not active",
    1: "automatic",
    2: "safe height",
    3: "auto assist",
    4: "truck driver",
}

UNEXPECTED_MOVETYPES = {0, 4, 5}
UNEXPECTED_LANDINGTYPES = {2, 4}

# Populated by load_enum_overrides_from_columns_info() if a Columns_info
# file is supplied. Falls back to the hardcoded *_NAMES dicts above for any
# column/code not present in the override.
_ENUM_OVERRIDES = {}

# Columns_info.csv/.xlsx uses its own short/loose names for these columns
# (seen as "step", "Landing " (trailing space), "order" for MoveType,
# "target" for TargetType) rather than the exact PLC header names - map
# every alias we've seen to the canonical name used by the rest of this
# program. Add more aliases here if a new export uses yet another name.
_COLUMN_NAME_ALIASES = {
    "step": "Step",
    "stepinfo": "StepInfo",
    "landing": "LandingType",
    "landingtype": "LandingType",
    "order": "MoveType",
    "movetype": "MoveType",
    "target": "TargetType",
    "targettype": "TargetType",
    "remoterequestinfo": "RemoteRequestInfo",
}


def load_enum_overrides_from_columns_info(path: str):
    """
    Reads a Columns_info file (column, code, descrition) and builds
    {canonical_column_name: {code: description}}. Call set_enum_overrides()
    with the result to make step_name()/movetype_name()/landingtype_name()
    prefer these descriptions over the built-in defaults.
    """
    df = load_columns_info(path)
    # normalize expected column headers defensively (case/whitespace)
    df.columns = [str(c).strip().lower() for c in df.columns]
    col_field = "column" if "column" in df.columns else df.columns[0]
    code_field = "code" if "code" in df.columns else df.columns[1]
    desc_field = "descrition" if "descrition" in df.columns else (
        "description" if "description" in df.columns else df.columns[2])

    overrides = {}
    for _, row in df.iterrows():
        raw_name = str(row[col_field]).strip().lower()
        # "step info" / "remote request info" -> "stepinfo" / "remoterequestinfo"
        key = raw_name.replace(" ", "").replace("_", "")
        canonical = _COLUMN_NAME_ALIASES.get(key, _COLUMN_NAME_ALIASES.get(raw_name, raw_name))
        try:
            code = int(row[code_field])
        except (ValueError, TypeError):
            continue
        desc = str(row[desc_field]).strip()
        overrides.setdefault(canonical, {})[code] = desc
    return overrides


def set_enum_overrides(overrides: dict):
    global _ENUM_OVERRIDES
    _ENUM_OVERRIDES = overrides or {}


def step_name(step):
    step = int(step)
    override = _ENUM_OVERRIDES.get("Step", {})
    if step in override:
        return override[step]
    return STEP_NAMES.get(step, f"unknown({step})")


def movetype_name(mt):
    mt = int(mt)
    override = _ENUM_OVERRIDES.get("MoveType", {})
    if mt in override:
        return override[mt]
    return MOVETYPE_NAMES.get(mt, f"unknown({mt})")


def landingtype_name(lt):
    lt = int(lt)
    override = _ENUM_OVERRIDES.get("LandingType", {})
    if lt in override:
        return override[lt]
    return LANDINGTYPE_NAMES.get(lt, f"unknown({lt})")


def stepinfo_name(code):
    code = int(code)
    return _ENUM_OVERRIDES.get("StepInfo", {}).get(code, f"code {code}")


def load_columns_info(path: str) -> pd.DataFrame:
    """Loads Columns_info (.csv or .xlsx). Keeps the 'descrition' typo in the
    header as-is."""
    if path.lower().endswith((".xlsx", ".xls")):
        return pd.read_excel(path)
    return pd.read_csv(path)


def resolve_axis_column(df: pd.DataFrame, axis: str, candidates: list) -> str:
    """
    Returns the first candidate column name from `candidates` that actually
    exists in df's columns. Raises a clear error if none match, rather than
    silently guessing.
    """
    for name in candidates:
        if name in df.columns:
            return name
    raise KeyError(
        f"None of the configured actual-position candidates for axis "
        f"'{axis}' were found in this file's columns: {candidates}. "
        f"Add the file's column name under Settings > Column mapping > "
        f"Actual position ({axis})."
    )


def resolve_all_axis_columns(df: pd.DataFrame, column_config) -> dict:
    """
    Returns {axis: {"ref": col_name, "actual": col_name}} for gantry/trolley/hoist,
    resolved dynamically against this file's actual header.
    """
    resolved = {}
    for axis in ("gantry", "trolley", "hoist"):
        ref_col = column_config.reference[axis]
        if ref_col not in df.columns:
            raise KeyError(
                f"Reference column '{ref_col}' for axis '{axis}' not found in file. "
                f"Set the right name under Settings > Column mapping > Reference position."
            )
        actual_col = resolve_axis_column(
            df, axis, column_config.actual_candidates[axis]
        )
        resolved[axis] = {"ref": ref_col, "actual": actual_col}
    return resolved
