"""
performance_chart.py
=====================
Builds the expected-vs-actual speed-vs-time chart for a PerformanceResult
(reference doc Section 8.3). Real elapsed seconds on the x-axis, never
normalized progress % (different distances produce different curve SHAPES -
triangular vs trapezoidal - so normalizing to 0-100% would compare apples
to oranges).

Speed is displayed in metres/minute (m/min), not metres/second. All the
underlying kinematics (accel/decel/top-speed in golden_standard.xml, the
expected-time calculation, etc.) still work in m/s internally - the m/s
-> m/min conversion (x60) happens ONLY here, at chart-drawing time, so no
other agent's numbers are affected.
"""
import io
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from reportlab.platypus import Image
from reportlab.lib.units import inch


def build_speed_chart(perf_result, axis_name: str, width_in=6.3, height_in=2.3):
    """
    Returns a reportlab Image flowable of the expected-vs-actual speed chart,
    or None if there isn't enough data to draw one (e.g. no_movement).
    """
    actual = perf_result.actual_curve or []
    expected = perf_result.expected_curve or []
    if not actual and not expected:
        return None

    fig, ax = plt.subplots(figsize=(width_in, height_in), dpi=150)

    MPS_TO_MPM = 60.0  # display conversion only - see module docstring

    if expected:
        ex_t = [p[0] for p in expected]
        ex_v = [p[1] * MPS_TO_MPM for p in expected]
        ax.plot(ex_t, ex_v, linestyle="--", color="#2c3e50", linewidth=1.5, label="Expected")

    if actual:
        ac_t = [p[0] for p in actual]
        ac_v = [p[1] * MPS_TO_MPM for p in actual]
        ax.plot(ac_t, ac_v, linestyle="-", color="#c0392b", linewidth=1.5, label="Actual")

    ax.set_xlabel("Elapsed time (s)", fontsize=8)
    ax.set_ylabel(f"{axis_name} speed (m/min)", fontsize=8)
    ax.tick_params(labelsize=7)
    ax.legend(fontsize=7, loc="upper right", frameon=False)
    ax.grid(True, linewidth=0.4, alpha=0.5)
    fig.tight_layout()

    buf = io.BytesIO()
    fig.savefig(buf, format="png")
    plt.close(fig)
    buf.seek(0)

    return Image(buf, width=width_in * inch, height=height_in * inch)
