"""
pickup_setdown_agent.py
========================
Necessity evaluation for MoveType=1 (pickup) / MoveType=2 (setdown)
workorders - the counterpart to necessity_agent.py, which only covers
MoveType=3 ("move-only") phases.

Rule, exactly as specified:

  - NECESSARY: the workorder contains BOTH a MoveType=1 (pickup) phase and
    a MoveType=2 (setdown) phase, with the pickup occurring before the
    setdown - i.e. a completed pickup+setdown cycle within the same
    workorder.

  - UNNECESSARY: the workorder has ONLY a MoveType=1 phase (no MoveType=2
    phase anywhere after it in the SAME workorder), and the very next
    workorder in the file is ALSO a pickup (MoveType=1) at a different
    gantry location - i.e. whatever was picked up was never set down in
    this workorder before the crane went and picked up again elsewhere.
    This workorder's pickup achieved nothing on its own.

  - Pickup-only workorder, next workorder is something OTHER than another
    pickup (not the missing setdown, since MoveType=2 by definition shares
    the SAME WorkorderIdent as its pickup - see the doc's "Workorder
    structure" rule): still flagged unnecessary, since the required
    same-workorder setdown never happened - but worded differently so it's
    clear this isn't the specific "picked up again elsewhere" pattern.

  - UNKNOWN: the workorder has only a MoveType=1 phase and there is no
    following workorder in the file to check against at all (typically the
    very last workorder of the day) - nothing to confirm either way.

The gantry position gap between this workorder's end and the next
workorder's start is reported as descriptive context only. It does NOT
drive the necessary/unnecessary verdict here - that is driven entirely by
which MoveType phases are present, per the rule above.
"""
from dataclasses import dataclass
from typing import Optional

from columns import resolve_all_axis_columns, movetype_name


@dataclass
class PickupSetdownResult:
    has_pickup: bool
    has_setdown: bool
    necessary: bool
    unknown: bool
    next_workorder: Optional[int]
    next_move_type: Optional[int]
    gantry_gap_m: Optional[float]
    lines: list = None  # list of (symbol, text) tuples for the report
    # Distance actually covered during this workorder (pickup phase alone,
    # or pickup+setdown together when both are present) - same convention
    # as MoveType=3's performance.distance_m: the NET displacement (last
    # row minus first row) of whichever axis moved the most, not a
    # point-to-point path length. dominant_axis records which axis that
    # was (gantry/trolley/hoist) since, unlike MoveType=3, a pickup/
    # setdown can genuinely move more than one axis and there's no
    # step-based way to isolate "the" move - see _dominant_axis_and_distance().
    distance_m: Optional[float] = None
    dominant_axis: Optional[str] = None
    # Raw start/end actual positions of the dominant axis - kept alongside
    # the unsigned distance_m so callers that want a SIGNED figure (e.g.
    # the case illustration's arrow labels, matching the convention
    # MoveType=3 moves already use) can compute position_end - position_start
    # themselves. See operation_chart._signed_distance_label().
    position_start: Optional[float] = None
    position_end: Optional[float] = None

    def to_dict(self):
        return {
            "has_pickup": self.has_pickup,
            "has_setdown": self.has_setdown,
            "necessary": self.necessary,
            "unknown": self.unknown,
            "next_workorder": self.next_workorder,
            "next_move_type": self.next_move_type,
            "gantry_gap_m": round(self.gantry_gap_m, 2) if self.gantry_gap_m is not None else None,
            "distance_m": round(self.distance_m, 2) if self.distance_m is not None else None,
            "dominant_axis": self.dominant_axis,
            "position_start": round(self.position_start, 2) if self.position_start is not None else None,
            "position_end": round(self.position_end, 2) if self.position_end is not None else None,
            "lines": self.lines,
        }


def _dominant_axis_and_distance(rows, config):
    """Whichever axis' ACTUAL position RANGE (max-min) is largest across
    this workorder's rows is treated as the axis that actually moved
    during this pickup/setdown - could be trolley/hoist alignment, not
    necessarily gantry (unlike MoveType=3, more than one axis can
    legitimately move here, and there's no step-based way to isolate
    "the" move). Once that axis is picked, the reported distance is its
    NET displacement (last row - first row) - the same convention as
    MoveType=3's performance.distance_m (see performance_agent.py /
    MoveType3 project reference doc, Section 4.3), so the two numbers mean
    the same thing and are directly comparable in the reports.
    Returns (axis_name, distance_m, position_start, position_end) or
    (None, None, None, None) if it can't be determined (columns missing,
    empty rows, etc.)."""
    try:
        axis_cols = resolve_all_axis_columns(rows, config.columns)
    except Exception:
        return None, None, None, None

    best_axis, best_range = None, -1.0
    best_start, best_end = None, None
    for axis, cols in axis_cols.items():
        actual_col = cols.get("actual")
        if not actual_col or actual_col not in rows.columns:
            continue
        try:
            series = rows[actual_col].astype(float)
        except Exception:
            continue
        if series.empty:
            continue
        rng = float(series.max() - series.min())
        if rng > best_range:
            best_range = rng
            best_axis = axis
            best_start = float(series.iloc[0])
            best_end = float(series.iloc[-1])

    if best_axis is None:
        return None, None, None, None
    return best_axis, abs(best_end - best_start), best_start, best_end


def _gantry_gap(workorder, next_workorder, config) -> Optional[float]:
    try:
        axis_cols = resolve_all_axis_columns(workorder.rows, config.columns)
        gantry_actual = axis_cols["gantry"]["actual"]
        this_pos = float(workorder.rows.iloc[-1][gantry_actual])
        next_pos = float(next_workorder.rows.iloc[0][gantry_actual])
        return abs(this_pos - next_pos)
    except Exception:
        return None


def evaluate_pickup_setdown(workorder, next_workorder, config) -> Optional[PickupSetdownResult]:
    """
    workorder: a data_loader.Workorder whose first phase is MoveType=1
    (pickup) - see data_loader.find_pickup_workorders_with_context().
    next_workorder: the very next Workorder in the file (by first-seen
    order), or None if this is the last one in the file.

    Returns None if `workorder` doesn't actually contain a pickup phase
    (shouldn't happen given the intended caller, but guards misuse).
    """
    move_types = [p.move_type for p in workorder.phases]
    if 1 not in move_types:
        return None

    idx1 = move_types.index(1)
    has_setdown = 2 in move_types[idx1 + 1:]

    # --- Completed pickup+setdown cycle: necessary ---
    if has_setdown:
        axis, dist, pos_start, pos_end = _dominant_axis_and_distance(workorder.rows, config)
        return PickupSetdownResult(
            has_pickup=True, has_setdown=True, necessary=True, unknown=False,
            next_workorder=next_workorder.workorder if next_workorder else None,
            next_move_type=None, gantry_gap_m=None,
            distance_m=dist, dominant_axis=axis,
            position_start=pos_start, position_end=pos_end,
            lines=[("\u2713", "workorder contains both pickup (1) and setdown (2) phases "
                              "\u2014 completed pickup+setdown cycle")],
        )

    # --- Pickup only, no setdown in this workorder ---
    if next_workorder is None or next_workorder.rows.empty or not next_workorder.phases:
        axis, dist, pos_start, pos_end = _dominant_axis_and_distance(workorder.rows, config)
        return PickupSetdownResult(
            has_pickup=True, has_setdown=False, necessary=False, unknown=True,
            next_workorder=None, next_move_type=None, gantry_gap_m=None,
            distance_m=dist, dominant_axis=axis,
            position_start=pos_start, position_end=pos_end,
            lines=[("\u2013", "pickup (1) with no setdown (2) in this workorder, and no "
                              "following workorder in this file to check against")],
        )

    next_move_type = int(next_workorder.phases[0].move_type)
    gap = _gantry_gap(workorder, next_workorder, config)
    gap_txt = f", gantry gap: {gap:.2f}m" if gap is not None else ""
    axis, dist, pos_start, pos_end = _dominant_axis_and_distance(workorder.rows, config)

    if next_move_type == 1:
        lines = [("\u2717", f"pickup (1) with no setdown (2) in this workorder, and the "
                             f"next workorder ({next_workorder.workorder}) is ALSO a pickup "
                             f"(1) at a different location{gap_txt} \u2014 this pickup "
                             f"achieved nothing")]
    else:
        lines = [("\u2717", f"pickup (1) with no setdown (2) in this workorder \u2014 next "
                             f"workorder ({next_workorder.workorder}) is MoveType "
                             f"{next_move_type} ({movetype_name(next_move_type)}), not the "
                             f"expected same-workorder setdown{gap_txt}")]

    return PickupSetdownResult(
        has_pickup=True, has_setdown=False, necessary=False, unknown=False,
        next_workorder=next_workorder.workorder, next_move_type=next_move_type,
        gantry_gap_m=gap, distance_m=dist, dominant_axis=axis,
        position_start=pos_start, position_end=pos_end, lines=lines,
    )
