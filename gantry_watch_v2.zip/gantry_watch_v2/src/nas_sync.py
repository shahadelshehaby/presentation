"""
nas_sync.py
============
Pulls PLC rows from InfluxDB on the NAS (Synology) instead of uploading
Excel/CSV files by hand.

- Read-only: it only runs Flux queries (POST /api/v2/query). Use a read-only
  API token. Nothing is ever written to InfluxDB.
- Incremental: for each machine it remembers how far it has checked and only
  asks for rows after that (minus a few minutes of overlap, so rows the
  collector writes late are not missed; rows already stored are skipped).
- Rows are cleaned exactly like a manual download (influx_clean.py), get a
  local-time PLCTime (UTC _time converted to Asia/Dubai when the PLC's own
  PLCTime is missing), and are written into one file per crane per day in
  the analyzer's library, which analyzes them like an uploaded file.
- Runs every N minutes while the analyzer is open ("Sync automatically"),
  or on demand ("Sync now").

Settings live in analyzer_data/nas_settings.json. The API token is kept
there only and is never sent back to the browser.
"""
import gzip
import json
import os
import re
import ssl
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timedelta, timezone

import pandas as pd

from influx_clean import parse_influx_csv, normalize_plctime, resolve_timezone, set_local_timezone, parse_utc

CHECK_EVERY_S = 15
LATE_ROWS_HOURS = 48  # how far back an idle machine is re-checked for rows written late
MIN_CHUNK = timedelta(milliseconds=5)  # shorter time ranges are skipped (InfluxDB: "cannot query an empty range")
FALLBACK_CHUNK = timedelta(hours=1)    # request size for the simpler (unpivoted) query
DEFAULTS = {
    "address": "", "org": "", "bucket": "", "token": "",
    "tag": "crane_id", "measurement": "",
    "interval_min": 30, "auto": False, "analyze_after": True,
    # more options
    "first_sync_from": "", "timezone": "Asia/Dubai", "chunk_hours": 6, "overlap_min": 5,
    "timeout_s": 120, "verify_tls": True, "find_days": 30,
}
CONFIG_KEYS = [k for k in DEFAULTS if k != "token"]


class InfluxError(Exception):
    pass


# =================================================================== client
class InfluxClient:
    def __init__(self, s):
        self.address = s["address"].rstrip("/")
        self.org, self.token = s["org"], s["token"]
        self.timeout = float(s.get("timeout_s") or 120)
        ctx = ssl.create_default_context()
        if not s.get("verify_tls", True):
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
        # Talk to the NAS directly: never through a proxy configured on the PC.
        self.opener = urllib.request.build_opener(urllib.request.ProxyHandler({}),
                                                  urllib.request.HTTPSHandler(context=ctx))

    def _send(self, req):
        try:
            with self.opener.open(req, timeout=self.timeout) as resp:
                body = resp.read()
                if resp.headers.get("Content-Encoding") == "gzip":
                    body = gzip.decompress(body)
                return body.decode("utf-8", "replace")
        except urllib.error.HTTPError as e:
            raw = e.read()
            if e.headers.get("Content-Encoding") == "gzip":
                try:
                    raw = gzip.decompress(raw)
                except OSError:
                    pass
            raise InfluxError(self._http_message(e.code, raw.decode("utf-8", "replace")))
        except urllib.error.URLError as e:
            reason = getattr(e, "reason", e)
            raise InfluxError(f"Can't reach {self.address} ({reason}). Check the address and port, "
                              f"and that the NAS and InfluxDB are running.")
        except (TimeoutError, OSError) as e:
            raise InfluxError(f"No answer from {self.address} within {self.timeout:.0f} s ({e}). "
                              f"The NAS may be busy; try fewer hours per request under More options.")

    @staticmethod
    def _http_message(code, text):
        detail = text.strip()
        try:
            detail = json.loads(text).get("message") or detail
        except ValueError:
            pass
        detail = detail[:300]
        if code == 401:
            return "InfluxDB rejected the API token (401 unauthorized). Check the token."
        if code == 403:
            return f"The API token isn't allowed to read this (403 forbidden). {detail}"
        if code == 404:
            return f"Not found (404): {detail or 'check the organisation and bucket names'}."
        return f"InfluxDB answered {code}: {detail}"

    def health(self):
        req = urllib.request.Request(f"{self.address}/health", headers={"Accept": "application/json"})
        try:
            return json.loads(self._send(req))
        except ValueError:
            return {}
        except InfluxError as e:
            if "404" in str(e):
                return {}
            raise

    def query(self, flux):
        if not self.org:
            raise InfluxError("Enter the organisation.")
        body = json.dumps({"query": flux, "type": "flux",
                           "dialect": {"header": True, "annotations": [], "delimiter": ","}}).encode()
        url = f"{self.address}/api/v2/query?{urllib.parse.urlencode({'org': self.org})}"
        req = urllib.request.Request(url, data=body, method="POST", headers={
            "Authorization": f"Token {self.token}", "Content-Type": "application/json",
            "Accept": "application/csv", "Accept-Encoding": "gzip"})
        return self._send(req)


# =================================================================== flux
def _q(v):
    """Flux string literal."""
    return '"' + str(v).replace("\\", "\\\\").replace('"', '\\"') + '"'


def _t(dt):
    """RFC3339 with microseconds. Rounding to whole seconds could turn a
    short range into start == stop, which InfluxDB rejects."""
    return dt.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")


def _measurement_filter(s):
    return f"\n  |> filter(fn: (r) => r._measurement == {_q(s['measurement'])})" if s.get("measurement") else ""


def flux_latest(s, hours=24):
    return (f"from(bucket: {_q(s['bucket'])})\n  |> range(start: -{int(hours)}h)" + _measurement_filter(s) +
            '\n  |> last()\n  |> keep(columns: ["_time"])\n  |> group()\n  |> max(column: "_time")')


def flux_tag_values(s):
    pred = f"(r) => r._measurement == {_q(s['measurement'])}" if s.get("measurement") else "(r) => true"
    return ('import "influxdata/influxdb/schema"\n'
            f"schema.tagValues(bucket: {_q(s['bucket'])}, tag: {_q(s['tag'])}, predicate: {pred}, "
            f"start: -{int(s.get('find_days') or 30)}d)")


def flux_tag_keys(s):
    return ('import "influxdata/influxdb/schema"\n'
            f"schema.tagKeys(bucket: {_q(s['bucket'])}, start: -2d)")


def _pull_base(s, tag_value, start, stop):
    return (f"from(bucket: {_q(s['bucket'])})\n  |> range(start: {_t(start)}, stop: {_t(stop)})" +
            _measurement_filter(s) +
            f"\n  |> filter(fn: (r) => r[{_q(s['tag'])}] == {_q(tag_value)})"
            '\n  |> drop(columns: ["_start", "_stop"])'
            # Some fields are stored as a whole number in some places and a
            # decimal in others (0 and 0.5). pivot refuses to put both types in
            # one column ("schema collision: cannot group float and integer
            # types"), so every value is turned into text first. The analyzer
            # reads the numbers back from the text.
            '\n  |> map(fn: (r) => ({r with _value: string(v: r._value)}))')


def flux_pull(s, tag_value, start, stop):
    return (_pull_base(s, tag_value, start, stop) +
            '\n  |> pivot(rowKey: ["_time"], columnKey: ["_field"], valueColumn: "_value")'
            '\n  |> group()\n  |> sort(columns: ["_time"])')


def flux_pull_long(s, tag_value, start, stop):
    """The simpler query, used when InfluxDB still refuses the pivot: one
    row per field value; the analyzer builds the table itself."""
    return _pull_base(s, tag_value, start, stop) + '\n  |> keep(columns: ["_time", "_field", "_value"])'


def long_to_wide(df):
    """_time, _field, _value rows -> one row per _time, one column per field."""
    if df.empty or not {"_time", "_field", "_value"} <= set(df.columns):
        return pd.DataFrame()
    wide = df.pivot_table(index="_time", columns="_field", values="_value", aggfunc="last")
    wide.columns.name = None
    return wide.reset_index()


def _is_pivot_error(e):
    text = str(e).lower()
    return "schema collision" in text or "pivot" in text


# =================================================================== helpers
def _short(text, limit=220):
    text = " ".join(str(text).split())
    return text if len(text) <= limit else text[:limit - 1] + "…"


CRANE_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_-]{0,29}$")


def default_crane(tag_value):
    """Best guess at the crane name from the machine tag: 'B203' -> 'B203',
    'rmg_b203' -> 'B203'. Editable in the machine list."""
    v = str(tag_value).strip()
    if re.fullmatch(r"[A-Za-z]+\d+", v):
        return v.upper()
    found = re.findall(r"[A-Za-z]+\d+", v)
    if found:
        return found[-1].upper()
    cleaned = re.sub(r"[^A-Za-z0-9_-]+", "_", v).strip("_")[:30]
    return cleaned or "CRANE"


def _fmt_local(dt, tz):
    return dt.astimezone(tz).strftime("%d.%m.%Y %H:%M:%S") if dt else None


def _parse_utc(s):
    return datetime.fromisoformat(s).astimezone(timezone.utc) if s else None


# =================================================================== sync
class NasSync:
    def __init__(self, data_dir, library):
        self.path = os.path.join(data_dir, "nas_settings.json")
        self.library = library
        self.lock = threading.RLock()
        self.settings = self._load()
        self.state = {"running": False, "step": None, "done": 0, "total": 0, "started": None}
        self._stop = threading.Event()
        self._thread = None
        self._started_at = time.time()
        self._apply_timezone()
        threading.Thread(target=self._loop, daemon=True, name="nas-sync-scheduler").start()

    # ------------------------------------------------------------ settings
    def _load(self):
        s = dict(DEFAULTS, machines={}, last_sync=None)
        if os.path.isfile(self.path):
            try:
                with open(self.path, encoding="utf-8") as f:
                    s.update(json.load(f))
            except (OSError, ValueError):
                pass
        return s

    def _save(self):
        with self.lock:
            tmp = self.path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(self.settings, f, indent=1)
            os.replace(tmp, self.path)

    def _apply_timezone(self):
        try:
            set_local_timezone(self.settings.get("timezone") or "Asia/Dubai")
        except ValueError:
            set_local_timezone("Asia/Dubai")

    def configured(self, s=None):
        s = s or self.settings
        return all(s.get(k) for k in ("address", "org", "bucket", "token", "tag"))

    def public(self):
        """Everything the page shows - never the token."""
        with self.lock:
            s = {k: self.settings.get(k) for k in CONFIG_KEYS}
            s["token_set"] = bool(self.settings.get("token"))
            tz = self._tz()
            machines = []
            for tag, m in sorted(self.settings["machines"].items()):
                machines.append({"tag": tag, "crane": m.get("crane", ""), "enabled": m.get("enabled", True),
                                 "last_row": m.get("last_row"), "rows_total": m.get("rows_total", 0),
                                 "error": m.get("error")})
            s["machines"] = machines
            s["last_sync"] = self.settings.get("last_sync")
            s["state"] = dict(self.state)
            s["next_sync_at"] = self.next_due() if s["auto"] and self.configured() else None
            s["configured"] = self.configured()
            return s

    def _tz(self):
        try:
            return resolve_timezone(self.settings.get("timezone"))
        except ValueError:
            return resolve_timezone("Asia/Dubai")

    def merged(self, form):
        """Saved settings with the form's values on top (a blank token keeps
        the saved one). Used for Test and Find before saving."""
        s = dict(self.settings)
        for k in CONFIG_KEYS:
            if form and k in form:
                s[k] = form[k]
        if form and str(form.get("token") or "").strip():
            s["token"] = str(form["token"]).strip()
        return self._validate(s, require=False)

    def _validate(self, s, require):
        errors = []
        s = dict(s)
        for k in ("address", "org", "bucket", "tag", "measurement", "timezone", "first_sync_from"):
            s[k] = str(s.get(k) or "").strip()
        s["token"] = str(s.get("token") or "").strip()
        s["address"] = s["address"].rstrip("/")
        if s["address"] and not re.match(r"^https?://[^\s/]+", s["address"]):
            errors.append("The InfluxDB address must start with http:// or https://, e.g. http://192.168.1.50:8086")
        for k, lo, hi, label in (("interval_min", 5, 1440, "Sync every (minutes)"),
                                 ("chunk_hours", 1, 24, "Hours per request"),
                                 ("overlap_min", 0, 120, "Overlap (minutes)"),
                                 ("timeout_s", 10, 900, "Request timeout (seconds)"),
                                 ("find_days", 1, 365, "Look for machines in the last (days)")):
            try:
                v = int(float(s.get(k)))
                if not lo <= v <= hi:
                    raise ValueError
                s[k] = v
            except (TypeError, ValueError):
                errors.append(f"{label} must be a whole number from {lo} to {hi}.")
        for k in ("auto", "analyze_after", "verify_tls"):
            s[k] = bool(s.get(k))
        if not s["tag"]:
            errors.append("Enter the machine tag name (for example crane_id).")
        try:
            resolve_timezone(s["timezone"] or "Asia/Dubai")
            s["timezone"] = s["timezone"] or "Asia/Dubai"
        except ValueError as e:
            errors.append(str(e))
        if s["first_sync_from"]:
            try:
                datetime.strptime(s["first_sync_from"], "%Y-%m-%d")
            except ValueError:
                errors.append("First sync starts from must be a date.")
        if require and s["auto"] and not all(s.get(k) for k in ("address", "org", "bucket", "token")):
            errors.append("To sync automatically, fill in the address, organisation, bucket and API token.")
        if errors:
            raise ValueError(errors)
        return s

    def save(self, form):
        with self.lock:
            s = dict(self.settings)
            for k in CONFIG_KEYS:
                if k in form:
                    s[k] = form[k]
            if str(form.get("token") or "").strip():
                s["token"] = str(form["token"]).strip()
            if form.get("clear_token"):
                s["token"] = ""
            s = self._validate(s, require=True)
            s["machines"], s["last_sync"] = self.settings["machines"], self.settings.get("last_sync")
            self.settings = s
            self._save()
            self._apply_timezone()
        return self.public()

    def save_machines(self, rows):
        errors, renames = [], []
        with self.lock:
            for row in rows:
                tag = str(row.get("tag"))
                m = self.settings["machines"].get(tag)
                if m is None:
                    continue
                crane = str(row.get("crane") or "").strip()
                if not CRANE_RE.match(crane):
                    errors.append(f"Crane name for '{tag}': use letters and numbers, e.g. B203.")
                    continue
                if crane != m.get("crane"):
                    renames.append((tag, crane))
                m["crane"] = crane
                m["enabled"] = bool(row.get("enabled", True))
            if errors:
                raise ValueError(errors)
            self._save()
        changed = []
        for tag, crane in renames:
            changed += self.library.rename_synced_machine(tag, crane)
        if changed and self.settings.get("analyze_after", True):
            self.library.queue_analysis(changed)
        return self.public()

    def reset_machine(self, tag):
        with self.lock:
            m = self.settings["machines"].get(tag)
            if m is None:
                raise ValueError([f"Unknown machine '{tag}'."])
            for k in ("last_time", "last_row", "checked_until"):
                m.pop(k, None)
            m["error"] = None
            self._save()
        return self.public()

    # ------------------------------------------------------- test / find
    def test(self, form=None):
        s = self.merged(form)
        if not s["address"]:
            raise InfluxError("Enter the InfluxDB address first.")
        client = InfluxClient(s)
        health = client.health()
        version = health.get("version")
        lines = [f"Reached InfluxDB{(' ' + version) if version else ''} at {s['address']}."]
        if not s["token"]:
            raise InfluxError(lines[0] + " Now enter the API token.")
        if not s["bucket"]:
            raise InfluxError(lines[0] + " Now enter the bucket.")
        df = parse_influx_csv(client.query(flux_latest(s)))
        if df.empty or "_time" not in df.columns:
            lines.append(f"The token can read bucket '{s['bucket']}', but it has no rows from the last 24 hours"
                         + (f" in measurement '{s['measurement']}'" if s["measurement"] else "") + ".")
        else:
            newest = parse_utc(df["_time"]).max().to_pydatetime()
            lines.append(f"Bucket '{s['bucket']}' is readable. Newest row: {_fmt_local(newest, self._tz())} "
                         f"(local time).")
        return " ".join(lines)

    def find_machines(self, form=None):
        s = self.merged(form)
        if not self.configured(s):
            raise InfluxError("Fill in the address, organisation, bucket, API token and machine tag first.")
        client = InfluxClient(s)
        df = parse_influx_csv(client.query(flux_tag_values(s)))
        values = sorted({v for v in df.get("_value", pd.Series(dtype=str)).astype(str) if v.strip()})
        if not values:
            keys = parse_influx_csv(client.query(flux_tag_keys(s)))
            found = sorted({k for k in keys.get("_value", pd.Series(dtype=str)).astype(str) if not k.startswith("_")})
            hint = f" Tags in this bucket: {', '.join(found)}." if found else ""
            raise InfluxError(f"No machines found for tag '{s['tag']}' in the last {s['find_days']} days.{hint}")
        added = 0
        with self.lock:
            for v in values:
                if v not in self.settings["machines"]:
                    self.settings["machines"][v] = {"crane": default_crane(v), "enabled": True, "rows_total": 0}
                    added += 1
            self._save()
        msg = f"Found {len(values)} machine{'s' if len(values) != 1 else ''}"
        return msg + (f", {added} new." if added else ", none new.")

    # --------------------------------------------------------------- sync
    def next_due(self):
        last = (self.settings.get("last_sync") or {}).get("finished") or self._started_at - 1e9
        return max(last + self.settings["interval_min"] * 60, self._started_at + 20)

    def _loop(self):
        while True:
            time.sleep(CHECK_EVERY_S)
            try:
                if (self.settings.get("auto") and self.configured() and not self.state["running"]
                        and time.time() >= self.next_due()):
                    self.start("automatic")
            except Exception as e:  # noqa: BLE001 - the scheduler must keep running
                print(f"NAS sync scheduler: {e}")

    def start(self, reason="manual"):
        with self.lock:
            if self.state["running"]:
                return False
            if not self.configured():
                raise InfluxError("Save the address, organisation, bucket, API token and machine tag first.")
            if not any(m.get("enabled", True) and m.get("crane") for m in self.settings["machines"].values()):
                raise InfluxError("No machines to sync. Press Find machines, and tick the ones to sync.")
            self._stop.clear()
            self.state = {"running": True, "step": "Starting", "done": 0, "total": 0,
                          "started": time.time(), "reason": reason}
            self._thread = threading.Thread(target=self._run, daemon=True, name="nas-sync")
            self._thread.start()
        return True

    def stop(self):
        self._stop.set()

    def _progress(self, step, done, total):
        self.state.update(step=step, done=done, total=total)
        self.library.sync_progress = {"step": step, "done": done, "total": max(total, done)}

    def _run(self):
        started = time.time()
        rows_total, files, problems = 0, set(), []
        status = "ok"
        try:
            s = dict(self.settings)
            tz = self._tz()
            client = InfluxClient(s)
            now = datetime.now(timezone.utc)
            machines = [(t, dict(m)) for t, m in sorted(self.settings["machines"].items())
                        if m.get("enabled", True) and m.get("crane")]
            for i, (tag, m) in enumerate(machines):
                if self._stop.is_set():
                    status = "stopped"
                    break
                self._progress(f"Syncing {m['crane']} from the NAS", i, len(machines))
                try:
                    n, touched = self._pull_machine(client, s, tz, tag, m, now)
                    rows_total += n
                    files |= touched
                    with self.lock:
                        self.settings["machines"][tag]["error"] = None
                except Exception as e:  # noqa: BLE001 - the other machines still sync
                    if not isinstance(e, InfluxError):
                        e = InfluxError(_short(f"Could not read this machine's rows: {e}"))
                    problems.append(f"{m['crane']}: {_short(e)}")
                    with self.lock:
                        self.settings["machines"][tag]["error"] = _short(e, 400)
                    if "Can't reach" in str(e) or "rejected the API token" in str(e):
                        break  # the same for every machine: stop here
                if self._stop.is_set() and status == "ok":
                    status = "stopped"
            if problems:
                status = "error"
        except Exception as e:  # noqa: BLE001
            status = "error"
            problems.append(_short(e))
        finally:
            # Whatever happens here, the sync must end as "not running", or no
            # later sync could ever start.
            try:
                if files and self.settings.get("analyze_after", True):
                    self.library.queue_analysis(sorted(files))
            except Exception as e:  # noqa: BLE001
                problems.append(f"Could not queue the analysis: {e}")
                status = "error"
            msg = {"ok": f"{rows_total:,} new row{'s' if rows_total != 1 else ''} in {len(files)} file"
                         f"{'s' if len(files) != 1 else ''}.",
                   "stopped": f"Stopped. {rows_total:,} new rows saved before stopping.",
                   "error": "; ".join(problems[:3])}[status]
            with self.lock:
                self.settings["last_sync"] = {"started": started, "finished": time.time(), "status": status,
                                              "message": msg, "rows": rows_total, "files": len(files)}
                try:
                    self._save()
                except OSError as e:
                    msg = f"{msg} (Could not save the sync settings: {e})"
                    status = "error"
            if status == "error":
                self.library.sync_issue = (time.time(), f"NAS sync: {msg}")
            self.library.sync_progress = None
            self.state = {"running": False, "step": None, "done": 0, "total": 0, "started": None}

    def _pull_machine(self, client, s, tz, tag, m, now):
        """Pulls one machine's new rows. Resumes from the newest row actually
        received (minus the overlap), not from when it last asked: rows the
        collector writes late - minutes, or hours after an outage - are still
        picked up. A machine that has been idle (no rows for days, or never
        any) is re-checked at most LATE_ROWS_HOURS back from the last check,
        so it doesn't make every sync re-read the whole first-load period."""
        overlap = timedelta(minutes=s["overlap_min"])
        last = _parse_utc(m.get("last_time"))
        checked = _parse_utc(m.get("checked_until"))
        late = timedelta(hours=LATE_ROWS_HOURS)
        if last:
            start = max(last - overlap, now - late)
        else:
            first = s.get("first_sync_from") or (datetime.now(tz) - timedelta(days=1)).strftime("%Y-%m-%d")
            start = datetime.strptime(first, "%Y-%m-%d").replace(tzinfo=tz).astimezone(timezone.utc)
            if checked:
                start = max(start, checked - late)
        step = timedelta(hours=s["chunk_hours"])
        rows_new, touched = 0, set()
        windows = max(1, -(-int((now - start).total_seconds()) // int(step.total_seconds())))
        w = 0
        while now - start >= MIN_CHUNK:
            if self._stop.is_set():
                break
            stop = min(start + step, now)
            if now - stop < MIN_CHUNK:
                stop = now  # don't leave a sliver of a few milliseconds for a last request
            w += 1
            self.state["step"] = (f"Syncing {m['crane']}: {_fmt_local(start, tz)[:16]} to "
                                  f"{_fmt_local(stop, tz)[11:16]}" + (f" ({w} of {windows})" if windows > 1 else ""))
            if self.library.sync_progress:
                self.library.sync_progress["step"] = self.state["step"]
            for df in self._fetch(client, s, tag, start, stop):
                if df.empty:
                    continue
                n, t, newest = self._store(df, s, tz, tag, m["crane"])
                rows_new += n
                touched |= t
                if newest is not None:
                    with self.lock:
                        mm = self.settings["machines"][tag]
                        if not mm.get("last_time") or newest > _parse_utc(mm["last_time"]):
                            mm["last_time"] = newest.isoformat()
                            mm["last_row"] = _fmt_local(newest, tz)
                        mm["rows_total"] = mm.get("rows_total", 0) + n
            with self.lock:
                self.settings["machines"][tag]["checked_until"] = stop.isoformat()
                self._save()  # progress is kept even if the sync stops here
            start = stop
        with self.lock:
            self.settings["machines"][tag]["last_pull_at"] = time.time()
            self._save()
        return rows_new, touched

    def _fetch(self, client, s, tag, start, stop):
        """Yields cleaned tables for one time range. Normally one pivoted
        query; if InfluxDB still refuses the pivot, retries with the simpler
        unpivoted query in 1-hour parts and builds the table here."""
        try:
            yield parse_influx_csv(client.query(flux_pull(s, tag, start, stop)))
            return
        except InfluxError as e:
            if not _is_pivot_error(e):
                raise
        part = start
        while stop - part >= MIN_CHUNK:
            part_end = min(part + FALLBACK_CHUNK, stop)
            yield long_to_wide(parse_influx_csv(client.query(flux_pull_long(s, tag, part, part_end))))
            part = part_end

    def _store(self, df, s, tz, tag, crane):
        """Cleans one pulled chunk and adds it to the day files. Returns
        (new rows, touched file ids, newest row time in UTC)."""
        df = df.replace("", pd.NA)
        newest = None
        if "_time" in df.columns:
            t = parse_utc(df["_time"]).max()
            newest = None if pd.isna(t) else t.to_pydatetime()
        df = normalize_plctime(df, tz)
        if df.empty:
            return 0, set(), newest
        drop = [c for c in ("_time", "_measurement", "_start", "_stop", s["tag"]) if c in df.columns]
        df = df.drop(columns=drop)
        if df["PLCTime"].duplicated().any():
            # Same second split over several tables (e.g. two measurements): merge them.
            df = df.groupby("PLCTime", sort=True, as_index=False).first()
        df = df.astype("string").fillna("")
        cols = ["PLCTime"] + [c for c in df.columns if c != "PLCTime"]
        df = df[cols].sort_values("PLCTime")
        if newest is None:
            local = datetime.strptime(df["PLCTime"].iloc[-1], "%Y-%m-%d-%H:%M:%S").replace(tzinfo=tz)
            newest = local.astimezone(timezone.utc)
        new, touched = 0, set()
        for day, part in df.groupby(df["PLCTime"].str[:10]):
            fid, n = self.library.append_synced_rows(tag, crane, day, part)
            new += n
            if n:
                touched.add(fid)
        return new, touched, newest
