"""
category_breakdown.py
======================
Shared "Move Category Breakdown (Necessity x Performance)" table, used by:
- report_machine.py   (one breakdown per machine, in that machine's own PDF)
- report_summary.py   (one breakdown per machine, on the summary's page 2)
"""
from collections import defaultdict
from reportlab.platypus import Table, TableStyle, Paragraph
from reportlab.lib import colors
from reportlab.lib.units import inch

from pdf_style import HEADER_BG
from utils import format_hms

CORE_CATEGORIES = ["necessary / good", "necessary / bad", "unnecessary / good", "unnecessary / bad"]


def build_category_breakdown_table(results, styles):
    """results: flat list of MoveType3Result. Returns a reportlab Table."""
    categories = defaultdict(lambda: {"count": 0, "time": 0.0})
    for r in results:
        nec = "unknown" if r.necessity.unknown else ("necessary" if r.necessity.necessary else "unnecessary")
        perf = "aborted" if r.performance.verdict in ("aborted", "no_movement") else \
               ("good" if r.performance.verdict == "perfect" else "bad")
        key = f"{nec} / {perf}"
        categories[key]["count"] += 1
        categories[key]["time"] += r.duration_s

    total_moves = len(results) or 1
    header = [Paragraph("Category", styles["TableHeader"]),
              Paragraph("Count", styles["TableHeader"]),
              Paragraph("Total time", styles["TableHeader"]),
              Paragraph("% of moves analyzed", styles["TableHeader"])]
    data = [header]

    shown = set()
    for key in CORE_CATEGORIES:
        c = categories.get(key, {"count": 0, "time": 0.0})
        data.append([
            Paragraph(key, styles["Body9"]),
            Paragraph(str(c["count"]), styles["Body9"]),
            Paragraph(format_hms(c["time"]), styles["Body9"]),
            Paragraph(f"{100*c['count']/total_moves:.1f}%", styles["Body9"]),
        ])
        shown.add(key)
    for key, c in categories.items():
        if key in shown or c["count"] == 0:
            continue
        data.append([
            Paragraph(key, styles["Body9"]),
            Paragraph(str(c["count"]), styles["Body9"]),
            Paragraph(format_hms(c["time"]), styles["Body9"]),
            Paragraph(f"{100*c['count']/total_moves:.1f}%", styles["Body9"]),
        ])

    table = Table(data, repeatRows=1, colWidths=[2.2*inch, 1.0*inch, 1.3*inch, 1.8*inch])
    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), HEADER_BG),
        ("FONTNAME", (0, 1), (-1, -1), "DejaVuSans"),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
    ]))
    return table
