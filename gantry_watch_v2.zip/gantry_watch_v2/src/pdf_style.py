"""
pdf_style.py
============
Shared reportlab setup used by both report builders.

- Registers DejaVuSans (bundled with matplotlib) so the plain Unicode
  checkmark (U+2713) and cross (U+2717) render correctly. Reportlab's
  default Helvetica does not reliably render these; DejaVuSans does.
  NEVER use the emoji versions (U+2705 / U+274C) - those render as blank
  boxes even with DejaVuSans.
- Sets 0.5in left/right margins on every document (the reportlab default
  of 1in each side is too narrow for these wide tables and clips the
  rightmost column).
"""
import os
import matplotlib
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.units import inch
from reportlab.lib import colors

_FONT_DIR = os.path.join(os.path.dirname(matplotlib.__file__), "mpl-data", "fonts", "ttf")
_REGISTERED = False


def register_fonts():
    global _REGISTERED
    if _REGISTERED:
        return
    pdfmetrics.registerFont(TTFont("DejaVuSans", os.path.join(_FONT_DIR, "DejaVuSans.ttf")))
    pdfmetrics.registerFont(TTFont("DejaVuSans-Bold", os.path.join(_FONT_DIR, "DejaVuSans-Bold.ttf")))
    _REGISTERED = True


def get_styles():
    register_fonts()
    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(name="Body9", fontName="DejaVuSans", fontSize=9, leading=12))
    styles.add(ParagraphStyle(name="Body8", fontName="DejaVuSans", fontSize=8, leading=10))
    styles.add(ParagraphStyle(name="TableHeader", fontName="DejaVuSans-Bold", fontSize=8,
                               leading=10, textColor=colors.white))
    styles.add(ParagraphStyle(name="H1", fontName="DejaVuSans-Bold", fontSize=16, leading=20, spaceAfter=10))
    styles.add(ParagraphStyle(name="H2", fontName="DejaVuSans-Bold", fontSize=13, leading=16, spaceBefore=14, spaceAfter=6))
    styles.add(ParagraphStyle(name="H3", fontName="DejaVuSans-Bold", fontSize=11, leading=14, spaceBefore=8, spaceAfter=4))
    return styles


PAGE_SIZE = landscape(A4)
MARGIN = 0.5 * inch

FLAG_OK_COLOR = colors.HexColor("#1e7e34")
FLAG_REVIEW_COLOR = colors.HexColor("#c0392b")
WASTE_ROW_COLOR = colors.HexColor("#fff3cd")
ABNORMAL_ROW_COLOR = colors.HexColor("#f8d7da")
MI_ROW_COLOR = colors.HexColor("#d1ecf1")
NECESSARY_ROW_COLOR = colors.HexColor("#d4edda")
HEADER_BG = colors.HexColor("#2c3e50")
