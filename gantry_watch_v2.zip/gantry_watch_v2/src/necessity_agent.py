"""
necessity_agent.py
===================
Evaluation 3 - Necessity (see reference doc Section 5).

FIX (this revision): a move is only NECESSARY if BOTH of these hold -
previously only the position check drove the `necessary` boolean at all
(the move-type check only ever affected the wording, never the verdict
itself), which let cases run past a move that had actually already
achieved its goal:

  1. This move's dominant-axis ACTUAL position matches the NEXT
     workorder's reference position (within tolerance).
  2. This move is MoveType=3, AND the next workorder is genuinely the
     expected type (MoveType=1, a real pickup) - not chained into
     another MoveType=3, and not some unexpected type.

If EITHER condition fails, the move is unnecessary. Each condition gets
its own tick/cross symbol in the report now (previously both lines always
shared one symbol driven only by the position check), so it's clear which
of the two conditions actually failed.

Wording (move-type line):
  - actual matches expected      -> "this is move type 3 and next is 1"
  - actual is ALSO MoveType=3    -> "this is move type 3 and next is 3 also"
    (the chained-repositioning case called out in Section 5.1/12)
  - actual differs, and isn't 3  -> "this is move type 3 and next is 2
    instead of the expected 1"
"""
from dataclasses import dataclass
from typing import Optional
from columns import resolve_all_axis_columns, movetype_name


@dataclass
class NecessityResult:
    necessary: bool
    axis: str
    actual_position: Optional[float]
    next_reference: Optional[float]
    gap_m: Optional[float]
    next_move_type: Optional[int]
    unknown: bool
    position_ok: Optional[bool] = None   # condition 1 alone
    type_ok: Optional[bool] = None        # condition 2 alone
    lines: list = None  # list of (symbol, text) tuples for the report

    def to_dict(self):
        return {
            "necessary": self.necessary,
            "unknown": self.unknown,
            "axis": self.axis,
            "actual_position": round(self.actual_position, 2) if self.actual_position is not None else None,
            "next_reference": round(self.next_reference, 2) if self.next_reference is not None else None,
            "gap_m": round(self.gap_m, 2) if self.gap_m is not None else None,
            "next_move_type": self.next_move_type,
            "position_ok": self.position_ok,
            "type_ok": self.type_ok,
            "lines": self.lines,
        }


def evaluate_necessity(phase_df, dominant_axis, next_workorder, config) -> NecessityResult:
    axis_cols = resolve_all_axis_columns(phase_df, config.columns)
    cols = axis_cols[dominant_axis]
    last_row = phase_df.iloc[-1]
    actual_position = float(last_row[cols["actual"]])

    if next_workorder is None or next_workorder.rows.empty:
        return NecessityResult(
            necessary=False, axis=dominant_axis, actual_position=actual_position,
            next_reference=None, gap_m=None, next_move_type=None, unknown=True,
            position_ok=None, type_ok=None,
            lines=[("\u2013", "no following workorder in this file to check against")],
        )

    next_first_row = next_workorder.rows.iloc[0]
    next_ref = float(next_first_row[cols["ref"]])
    next_move_type = int(next_first_row["MoveType"])

    gap = abs(actual_position - next_ref)
    tol = config.thresholds.necessity_tolerance_m
    expected_next = config.expected_next_move_type

    # Condition 1: does this move's ending position line up with the next
    # workorder's reference?
    position_ok = gap <= tol
    # Condition 2: is the next workorder genuinely the expected type
    # (a real pickup), not another MoveType=3, and not something else?
    type_ok = (next_move_type == expected_next)

    # BOTH conditions must hold for the move to count as necessary.
    necessary = position_ok and type_ok

    pos_symbol = "\u2713" if position_ok else "\u2717"
    pos_line = (pos_symbol, f"Actual position: {actual_position:.2f}m "
                            f"{'matches' if position_ok else 'but'} next move's "
                            f"{dominant_axis} reference: {next_ref:.2f}m, gap: {gap:.2f}m")

    type_symbol = "\u2713" if type_ok else "\u2717"
    if type_ok:
        type_text = f"this is move type 3 and next is {next_move_type}"
    elif next_move_type == 3:
        type_text = f"this is move type 3 and next is {next_move_type} also"
    else:
        type_text = (f"this is move type 3 and next is {next_move_type} "
                      f"instead of the expected {expected_next}")
    type_line = (type_symbol, type_text)

    return NecessityResult(
        necessary=necessary, axis=dominant_axis, actual_position=actual_position,
        next_reference=next_ref, gap_m=gap, next_move_type=next_move_type, unknown=False,
        position_ok=position_ok, type_ok=type_ok,
        lines=[pos_line, type_line],
    )
