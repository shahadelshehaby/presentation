"""
pickup_setdown_report.py
==========================
Shared "Pickup / Setdown Necessity (MoveType 1 & 2)" table and rollup
counts, used by:
- report_machine.py    (per-workorder detail table, one machine's own PDF)
- report_summary.py    (per-machine + overall rollup)
- report_operation.py  (per-machine + overall rollup, alongside the
                        existing MoveType=3 case rollup)

See pickup_setdown_agent.py for the necessity rule itself.
"""
from utils import display_time
from reportlab.platypus import Table, TableStyle, Paragraph
from reportlab.lib import colors
from reportlab.lib.units import inch

from pdf_style import HEADER_BG, WASTE_ROW_COLOR


def rollup_counts(results):
    """results: list of PickupSetdownWorkorderResult. Returns a dict of
    totals."""
    n = len(results)
    n_nec = sum(1 for r in results if r.pickup_setdown.necessary)
    n_unnec = sum(1 for r in results if r.is_unnecessary)
    n_unk = sum(1 for r in results if r.pickup_setdown.unknown)
    return {"n": n, "n_necessary": n_nec, "n_unnecessary": n_unnec, "n_unknown": n_unk}


def build_pickup_setdown_table(results, styles):
    """results: flat list of PickupSetdownWorkorderResult (one machine, or
    all machines combined). Returns a reportlab Table."""
    header = [Paragraph(h, styles["TableHeader"]) for h in
              ["Workorder", "Time", "Duration (s)", "Has setdown", "Next workorder",
               "Next MoveType", "Necessity", "Note"]]
    data = [header]
    row_styles = []

    for i, r in enumerate(results, start=1):
        ps = r.pickup_setdown
        nec_txt = "unknown" if ps.unknown else ("necessary" if ps.necessary else "unnecessary")
        next_wo_txt = str(ps.next_workorder) if ps.next_workorder is not None else "-"
        next_mt_txt = str(ps.next_move_type) if ps.next_move_type is not None else "-"
        note_txt = ps.lines[0][1] if ps.lines else ""
        data.append([
            Paragraph(str(r.workorder), styles["Body9"]),
            Paragraph(display_time(r.time_start), styles["Body9"]),
            Paragraph(f"{r.duration_s:.1f}", styles["Body9"]),
            Paragraph("yes" if ps.has_setdown else "no", styles["Body9"]),
            Paragraph(next_wo_txt, styles["Body9"]),
            Paragraph(next_mt_txt, styles["Body9"]),
            Paragraph(nec_txt, styles["Body9"]),
            Paragraph(note_txt, styles["Body8"]),
        ])
        if r.is_unnecessary:
            row_styles.append(("BACKGROUND", (0, i), (-1, i), WASTE_ROW_COLOR))

    table = Table(data, repeatRows=1,
                  colWidths=[0.7*inch, 0.7*inch, 0.75*inch, 0.75*inch, 0.85*inch,
                             0.8*inch, 0.8*inch, 2.15*inch])
    style = [
        ("BACKGROUND", (0, 0), (-1, 0), HEADER_BG),
        ("FONTNAME", (0, 1), (-1, -1), "DejaVuSans"),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
    ] + row_styles
    table.setStyle(TableStyle(style))
    return table


def build_pickup_setdown_rollup_table(results_by_machine: dict, styles):
    """results_by_machine: {machine: [PickupSetdownWorkorderResult, ...]}.
    Returns a per-machine rollup Table (counts only, no per-workorder
    detail) - used on overview pages."""
    header = [Paragraph(h, styles["TableHeader"]) for h in
              ["Machine", "Pickup workorders", "Necessary", "Unnecessary", "Unknown"]]
    data = [header]
    tot = {"n": 0, "n_necessary": 0, "n_unnecessary": 0, "n_unknown": 0}

    for machine in sorted(results_by_machine.keys()):
        c = rollup_counts(results_by_machine[machine])
        for k in tot:
            tot[k] += c[k]
        data.append([
            Paragraph(machine, styles["Body9"]),
            Paragraph(str(c["n"]), styles["Body9"]),
            Paragraph(str(c["n_necessary"]), styles["Body9"]),
            Paragraph(str(c["n_unnecessary"]), styles["Body9"]),
            Paragraph(str(c["n_unknown"]), styles["Body9"]),
        ])

    data.append([
        Paragraph("<b>TOTAL</b>", styles["Body9"]),
        Paragraph(f"<b>{tot['n']}</b>", styles["Body9"]),
        Paragraph(f"<b>{tot['n_necessary']}</b>", styles["Body9"]),
        Paragraph(f"<b>{tot['n_unnecessary']}</b>", styles["Body9"]),
        Paragraph(f"<b>{tot['n_unknown']}</b>", styles["Body9"]),
    ])

    table = Table(data, repeatRows=1,
                  colWidths=[1.3*inch, 1.3*inch, 1.1*inch, 1.2*inch, 1.0*inch])
    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), HEADER_BG),
        ("FONTNAME", (0, 1), (-1, -1), "DejaVuSans"),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("BACKGROUND", (0, -1), (-1, -1), colors.HexColor("#eeeeee")),
    ]))
    return table
