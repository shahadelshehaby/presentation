"""
performance_agent.py
=====================
Evaluation 2 - Performance (see reference doc Section 4).

Unlike the original project, this agent does NOT fit accel/decel/top-speed
from a golden example CSV. It reads those numbers directly from
golden_standard.xml (see config_loader.py) and applies distance-aware
trapezoidal/triangular kinematics to whatever move it's given.
"""
import math
from dataclasses import dataclass
from typing import Optional
from columns import resolve_all_axis_columns


def _raw_kinematic_profile(distance_m: float, accel: float, decel: float, vmax: float):
    """
    Returns (raw_total_time, v_peak, t_accel, t_cruise, t_decel) for the
    idealized (no offset) trapezoidal/triangular profile - used both for
    expected_time_for_distance() and for sampling the full speed curve.
    """
    if distance_m <= 0 or accel <= 0 or decel <= 0:
        return 0.0, 0.0, 0.0, 0.0, 0.0

    d_accel = vmax ** 2 / (2 * accel)
    d_decel = vmax ** 2 / (2 * decel)

    if distance_m >= d_accel + d_decel:
        t_accel = vmax / accel
        t_decel = vmax / decel
        d_cruise = distance_m - d_accel - d_decel
        t_cruise = d_cruise / vmax if vmax > 0 else 0
        return t_accel + t_cruise + t_decel, vmax, t_accel, t_cruise, t_decel
    else:
        v_peak = math.sqrt((2 * distance_m) / (1 / accel + 1 / decel))
        t_accel = v_peak / accel
        t_decel = v_peak / decel
        return t_accel + t_decel, v_peak, t_accel, 0.0, t_decel


def expected_time_for_distance(distance_m: float, accel: float, decel: float,
                                vmax: float, offset_s: float) -> float:
    """
    Idealized (instant-jerk) trapezoidal/triangular travel time for a given
    distance, plus a calibrated offset for real-world ramp/control delay.
    """
    if distance_m <= 0:
        return offset_s
    raw_total, *_ = _raw_kinematic_profile(distance_m, accel, decel, vmax)
    return raw_total + offset_s


def expected_speed_curve(distance_m: float, accel: float, decel: float, vmax: float,
                          expected_time_s: float, n_points: int = 60):
    """
    Samples the idealized trapezoidal/triangular speed-vs-time curve, then
    stretches its time axis linearly so it ends exactly at expected_time_s
    (which already includes the calibrated offset) - see reference doc
    Section 8.3: the chart's time axis must match the text's reported
    expected duration exactly.
    Returns a list of (t_seconds, speed_mps) tuples, or [] only when
    expected_time_s itself isn't known/positive.

    FIX (this revision): previously, whenever distance_m was 0 (or very
    small enough that _raw_kinematic_profile degenerates to zero), this
    returned [] - silently dropping the "Expected" line from the chart even
    though an expected_time_s (the offset alone) was known. Now it falls
    back to a flat 0 m/s reference line spanning [0, expected_time_s], so
    the chart always shows an Expected line whenever expected_time_s > 0.
    """
    if expected_time_s <= 0:
        return []

    raw_total, v_peak, t_accel, t_cruise, t_decel = _raw_kinematic_profile(
        distance_m, accel, decel, vmax)

    if raw_total <= 0:
        return [(0.0, 0.0), (expected_time_s, 0.0)]

    stretch = expected_time_s / raw_total
    points = []
    for i in range(n_points + 1):
        t_raw = raw_total * i / n_points
        if t_raw <= t_accel:
            v = accel * t_raw
        elif t_raw <= t_accel + t_cruise:
            v = v_peak
        else:
            t_into_decel = t_raw - t_accel - t_cruise
            v = max(v_peak - decel * t_into_decel, 0.0)
        points.append((t_raw * stretch, v))
    return points


def actual_position_curve(phase_df, actual_col: str):
    """
    Returns [(elapsed_seconds, position_m), ...] for the dominant axis'
    ACTUAL position across the FULL phase (not just the move-active steps),
    for use by the Operation report's position/necessity charts (see
    operation_chart.py). elapsed_seconds is relative to the first row of
    the phase.
    """
    if phase_df.empty:
        return []
    t0 = phase_df.iloc[0]["_ts"]
    points = []
    for _, row in phase_df.iterrows():
        t = row["_ts"]
        pos = float(row[actual_col])
        points.append(((t - t0).total_seconds(), pos))
    return points


def actual_speed_curve(move_rows, actual_col: str, smoothing_window: int = 3):
    """
    Derives the actual speed-vs-time curve from the actual position column's
    finite difference over time (never the raw *SPEED column - see Section
    2.3: speed columns aren't guaranteed to be calibrated m/s).
    Returns a list of (elapsed_seconds, speed_mps) tuples, one per row after
    the first.

    FIX (this revision): raw per-row differencing on a 1-second PLC log is
    sensitive to small position-reading noise/quantization - a single row
    with a slightly smaller reported delta shows up as a brief, artificial
    dip (e.g. a real, physically-steady ~180 m/min cruise reads as
    180 -> 100 -> 180 for one sample) even though nothing actually slowed
    down. To fix this without hiding genuine slowdowns (e.g. a real pause
    during an interruption, which spans several rows and survives
    smoothing), a small CENTERED moving average (default window=3) is
    applied to the raw per-row speed samples before returning them.
    """
    if len(move_rows) < 2:
        return []
    t0 = move_rows.iloc[0]["_ts"]
    raw_times = []
    raw_speeds = []
    prev_t = move_rows.iloc[0]["_ts"]
    prev_pos = float(move_rows.iloc[0][actual_col])
    for _, row in move_rows.iloc[1:].iterrows():
        t = row["_ts"]
        pos = float(row[actual_col])
        dt = (t - prev_t).total_seconds()
        if dt > 0:
            speed = abs(pos - prev_pos) / dt
            raw_times.append((t - t0).total_seconds())
            raw_speeds.append(speed)
        prev_t, prev_pos = t, pos

    if smoothing_window <= 1 or len(raw_speeds) < smoothing_window:
        return list(zip(raw_times, raw_speeds))

    half = smoothing_window // 2
    smoothed = []
    n = len(raw_speeds)
    for i in range(n):
        lo = max(0, i - half)
        hi = min(n, i + half + 1)
        window_vals = raw_speeds[lo:hi]
        smoothed.append(sum(window_vals) / len(window_vals))
    return list(zip(raw_times, smoothed))


@dataclass
class PerformanceResult:
    axis: str
    target_distance_m: float
    distance_m: float
    completion_pct: float
    aborted: bool
    expected_time_s: Optional[float]
    actual_time_s: Optional[float]
    verdict: str  # "perfect" | "issue" | "aborted" | "no_movement"
    message: str
    actual_curve: list = None    # [(t_seconds, speed_mps), ...] - always populated when movement rows exist
    expected_curve: list = None  # [(t_seconds, speed_mps), ...] - only when expected_time_s is known
    position_curve: list = None  # [(t_seconds, position_m), ...] - dominant axis actual position, full phase
    position_start: Optional[float] = None  # dominant axis actual position at first row of phase
    position_end: Optional[float] = None    # dominant axis actual position at last row of phase
    reference_position: Optional[float] = None  # this phase's own commanded reference (assumed constant)
    reached_reference: Optional[bool] = None    # did position_end actually reach reference_position?

    def to_dict(self):
        return {
            "axis": self.axis,
            "target_distance_m": round(self.target_distance_m, 2),
            "distance_m": round(self.distance_m, 2),
            "completion_pct": round(self.completion_pct, 1),
            "aborted": self.aborted,
            "expected_time_s": round(self.expected_time_s, 1) if self.expected_time_s is not None else None,
            "actual_time_s": round(self.actual_time_s, 1) if self.actual_time_s is not None else None,
            "verdict": self.verdict,
            "message": self.message,
            "position_start": round(self.position_start, 2) if self.position_start is not None else None,
            "position_end": round(self.position_end, 2) if self.position_end is not None else None,
            "reference_position": round(self.reference_position, 2) if self.reference_position is not None else None,
            "reached_reference": self.reached_reference,
        }


def evaluate_performance(phase_df, dominant_axis, config) -> PerformanceResult:
    axis_cols = resolve_all_axis_columns(phase_df, config.columns)
    cols = axis_cols[dominant_axis]
    kin = config.axes.get(dominant_axis)
    if kin is None:
        raise KeyError(f"No kinematics configured for axis '{dominant_axis}' in golden_standard.xml")

    pos_curve = actual_position_curve(phase_df, cols["actual"])
    pos_start = float(phase_df.iloc[0][cols["actual"]])
    pos_end = float(phase_df.iloc[-1][cols["actual"]])
    # The reference/commanded position stays constant for the duration of
    # one move (see project reference doc), so the phase's own first-row
    # reference value is this move's target for its ENTIRE duration - used
    # to check whether the move actually reached where it was told to go
    # (independent of the separate "necessity" check against the NEXT
    # move's reference).
    reference_position = float(phase_df.iloc[0][cols["ref"]])
    reached_reference = abs(pos_end - reference_position) <= config.thresholds.step_match_tolerance_m

    move_rows = phase_df[phase_df["Step"].isin([5, 6])]
    if move_rows.empty or len(move_rows) < 2:
        first = phase_df.iloc[0]
        target_distance_m = abs(float(first[cols["ref"]]) - float(first[cols["actual"]]))
        # Even though the move never got moving, we can still show what the
        # FULL intended (target_distance_m) move was expected to look like,
        # so the chart always has an Expected line to compare against - see
        # docstring fix note in expected_speed_curve().
        target_expected_time_s = expected_time_for_distance(
            target_distance_m, kin.acceleration_mps2, kin.deceleration_mps2,
            kin.top_speed_mps, kin.offset_s,
        ) if target_distance_m > 0 else None
        target_expected_curve = expected_speed_curve(
            target_distance_m, kin.acceleration_mps2, kin.deceleration_mps2,
            kin.top_speed_mps, target_expected_time_s,
        ) if target_expected_time_s else []
        return PerformanceResult(
            axis=dominant_axis, target_distance_m=target_distance_m, distance_m=0.0,
            completion_pct=0.0, aborted=True, expected_time_s=None, actual_time_s=None,
            verdict="no_movement",
            message=("move never reached the move-active step (5) or lower-active step (6) "
                     "-- likely aborted/canceled before it started moving, or the data slice "
                     "ends before movement begins."),
            actual_curve=[], expected_curve=target_expected_curve,
            position_curve=pos_curve, position_start=pos_start, position_end=pos_end,
            reference_position=reference_position, reached_reference=reached_reference,
        )

    start_row = move_rows.iloc[0]
    end_row = move_rows.iloc[-1]

    start_actual = float(start_row[cols["actual"]])
    end_actual = float(end_row[cols["actual"]])
    start_ref = float(start_row[cols["ref"]])

    target_distance_m = abs(start_ref - start_actual)
    distance_m = abs(end_actual - start_actual)
    completion_pct = (distance_m / target_distance_m * 100) if target_distance_m > 0 else 100.0

    actual_time_s = (end_row["_ts"] - start_row["_ts"]).total_seconds()

    th = config.thresholds
    if target_distance_m >= th.aborted_min_target_distance_m and completion_pct < th.aborted_completion_pct:
        # Aborted moves never reached their target_distance_m, so there's no
        # "actual vs expected" comparison at the traveled distance - but we
        # can still show what the FULL intended move should have looked
        # like (against target_distance_m), so the chart isn't left with
        # only an Actual line and no reference to compare it to.
        target_expected_time_s = expected_time_for_distance(
            target_distance_m, kin.acceleration_mps2, kin.deceleration_mps2,
            kin.top_speed_mps, kin.offset_s,
        )
        target_expected_curve = expected_speed_curve(
            target_distance_m, kin.acceleration_mps2, kin.deceleration_mps2,
            kin.top_speed_mps, target_expected_time_s,
        )
        return PerformanceResult(
            axis=dominant_axis, target_distance_m=target_distance_m, distance_m=distance_m,
            completion_pct=completion_pct, aborted=True, expected_time_s=None,
            actual_time_s=actual_time_s, verdict="aborted",
            message=(f"move appears aborted/incomplete: traveled {distance_m:.1f}m of an "
                     f"intended {target_distance_m:.1f}m ({completion_pct:.0f}%) before "
                     f"stopping -- likely canceled mid-move rather than a genuine "
                     f"speed/timing issue."),
            actual_curve=actual_speed_curve(move_rows, cols["actual"]), expected_curve=target_expected_curve,
            position_curve=pos_curve, position_start=pos_start, position_end=pos_end,
            reference_position=reference_position, reached_reference=reached_reference,
        )

    expected_time_s = expected_time_for_distance(
        distance_m, kin.acceleration_mps2, kin.deceleration_mps2,
        kin.top_speed_mps, kin.offset_s,
    )

    if expected_time_s <= 0:
        pct_slower = 0.0
    else:
        pct_slower = (actual_time_s - expected_time_s) / expected_time_s * 100

    if pct_slower <= th.performance_slow_threshold_pct:
        verdict = "perfect"
        message = (f"perfect speed and time -- for a {distance_m:.1f}m move, expected "
                    f"~{expected_time_s:.1f}s, actual was {actual_time_s:.1f}s, matches "
                    f"the expected profile")
    else:
        verdict = "issue"
        message = (f"issue: for a {distance_m:.1f}m move, expected ~{expected_time_s:.1f}s "
                    f"(based on configured accel/decel/top-speed), actual was "
                    f"{actual_time_s:.1f}s ({pct_slower:.0f}% slower)")

    return PerformanceResult(
        axis=dominant_axis, target_distance_m=target_distance_m, distance_m=distance_m,
        completion_pct=completion_pct, aborted=False, expected_time_s=expected_time_s,
        actual_time_s=actual_time_s, verdict=verdict, message=message,
        actual_curve=actual_speed_curve(move_rows, cols["actual"]),
        expected_curve=expected_speed_curve(distance_m, kin.acceleration_mps2,
                                             kin.deceleration_mps2, kin.top_speed_mps,
                                             expected_time_s),
        position_curve=pos_curve, position_start=pos_start, position_end=pos_end,
            reference_position=reference_position, reached_reference=reached_reference,
    )
