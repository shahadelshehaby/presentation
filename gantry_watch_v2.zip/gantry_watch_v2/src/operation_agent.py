"""
operation_agent.py
====================
Builds the "Operation" report's case grouping.

UPDATE (this revision): a case is no longer built from MoveType=3 moves
only. Unnecessary MoveType=1/2 (pickup/setdown) workorders now take part
in the SAME chronological case as the MoveType=3 repositions around them,
per this exact real-world pattern:

    move 3        (unnecessary)
    move 3        (unnecessary)
    pickup/setdown (unnecessary - pickup with no setdown)
    pickup+setdown (necessary  - this is what finally closes the case)

Previously, MoveType=3 cases and MoveType=1/2 pickup/setdown workorders
were reported in two entirely separate tables/sections with no shared
timeline, so a user could not see "the crane repositioned twice, then
picked up unsuccessfully, before finally succeeding" as ONE story. Both
kinds of event are now merged into a single time-ordered sequence per
machine (see merge_machine_events()) before case-grouping runs, and the
case illustration (operation_chart.py) draws both kinds of event in the
same chain.

A case closes at the first event that represents a genuinely COMPLETED
outcome:
  - a MoveType=3 move whose NEXT workorder is genuinely a pickup
    (MoveType=1) - unchanged from the previous revision: necessity.
    necessary also requires a position match, which is a stricter/
    different question (see necessity_agent.py) and is NOT what should
    end a repositioning cycle.
  - a pickup/setdown workorder that actually completed (contains BOTH a
    pickup AND a setdown phase) - pickup_setdown.necessary.

A move/workorder with an UNKNOWN verdict (no following workorder in the
file to check against - typically the very last event of the day) does
NOT terminate a case, since there's nothing to confirm. If a file ends
mid-case, the remaining events still form a final, "open" case.

Cases are built per-machine: one machine's event sequence must not bleed
into another machine's (same independence rule as necessity's own
"next workorder" comparison in necessity_agent.py / pickup_setdown_agent.py).
"""
from dataclasses import dataclass, field
from typing import List, Optional


# ---------------------------------------------------------------------
# Small duck-typed adapters so callers (report_operation.py,
# operation_chart.py) don't need to know whether a given event is a
# MoveType3Result or a PickupSetdownWorkorderResult.
# ---------------------------------------------------------------------

def is_pickup_setdown_event(e) -> bool:
    return hasattr(e, "pickup_setdown")


def is_movetype3_event(e) -> bool:
    return hasattr(e, "necessity") and hasattr(e, "performance")


def event_kind(e) -> str:
    return "pickup_setdown" if is_pickup_setdown_event(e) else "movetype3"


def event_is_unknown(e) -> bool:
    if is_pickup_setdown_event(e):
        return bool(e.pickup_setdown.unknown)
    return bool(e.necessity.unknown)


def event_is_necessary_confirmed(e) -> bool:
    """Confirmed necessary - i.e. necessary AND not unknown."""
    if is_pickup_setdown_event(e):
        return bool(e.pickup_setdown.necessary) and not e.pickup_setdown.unknown
    return bool(e.necessity.necessary) and not e.necessity.unknown


def event_closes_case(e) -> bool:
    """True if this event represents a genuinely completed outcome that
    should end the current case - see module docstring."""
    if is_pickup_setdown_event(e):
        # A completed pickup+setdown cycle - by construction this can only
        # be True when has_setdown is True, which is never `unknown`.
        return bool(e.pickup_setdown.necessary)
    return bool(e.necessity.type_ok) and not e.necessity.unknown


def event_distance_m(e) -> Optional[float]:
    """MoveType=3 moves have a distance-traveled figure from
    performance_agent.py. Pickup/setdown workorders now get their own
    figure too (pickup_setdown_agent._dominant_axis_and_distance) - the net
    displacement of whichever axis moved the most during the workorder.
    Still returns None (not 0.0) if it genuinely couldn't be computed
    (e.g. required columns missing), so callers can tell "no distance
    available" apart from "measured and it was zero"."""
    if is_pickup_setdown_event(e):
        return e.pickup_setdown.distance_m
    return e.performance.distance_m


def event_energy_kwh(e):
    """Returns (value_or_None, has_data). value is None when there's no
    usable reading at all - see power_agent.PowerResult.has_any_data."""
    pw = getattr(e, "power", None)
    if pw is None or not pw.has_any_data:
        return None, False
    return pw.total_energy_kwh, True


def event_wasted_energy_kwh(e) -> float:
    return getattr(e, "wasted_energy_kwh", 0.0) or 0.0


def event_label(e) -> str:
    """Short human label for tables/chart annotations."""
    if is_pickup_setdown_event(e):
        return "pickup/setdown" if e.pickup_setdown.has_setdown else "pickup only"
    return "move-only (3)"


def merge_machine_events(movetype3_results: List, pickup_setdown_results: List) -> List:
    """Merges one machine's MoveType3Result list and PickupSetdownWorkorderResult
    list into a single chronological sequence, sorted by time_start. Both
    input lists are already per-machine (see orchestrator.py)."""
    events = list(movetype3_results) + list(pickup_setdown_results)
    events.sort(key=lambda e: e.time_start)
    return events


@dataclass
class OperationCase:
    case_num: int          # 1-based, per machine
    machine: str
    moves: list = field(default_factory=list)   # mixed: MoveType3Result / PickupSetdownWorkorderResult

    @property
    def closed_by_pickup(self) -> bool:
        """True if this case ends because its last event was a genuinely
        completed outcome (a real pickup coming next for a MoveType=3 move,
        or a completed pickup+setdown cycle) - the normal/expected way a
        case ends. False means the file ran out of events before that
        happened."""
        if not self.moves:
            return False
        return event_closes_case(self.moves[-1])

    @property
    def time_start(self) -> str:
        return self.moves[0].time_start

    @property
    def time_end(self) -> str:
        return self.moves[-1].time_end

    @property
    def total_duration_s(self) -> float:
        return sum(m.duration_s for m in self.moves)

    @property
    def total_distance_m(self) -> float:
        """Sums only events that HAVE a distance model (MoveType=3 moves).
        Pickup/setdown events contribute 0 here (see event_distance_m) -
        they're still counted in n_moves/energy, just not in distance."""
        return sum(event_distance_m(m) or 0.0 for m in self.moves)

    @property
    def n_moves(self) -> int:
        return len(self.moves)

    @property
    def n_unnecessary(self) -> int:
        return sum(1 for m in self.moves if m.is_unnecessary)

    @property
    def n_necessary(self) -> int:
        return sum(1 for m in self.moves if event_is_necessary_confirmed(m))

    @property
    def n_unknown(self) -> int:
        return sum(1 for m in self.moves if event_is_unknown(m))

    @property
    def total_energy_kwh(self) -> float:
        total = 0.0
        for m in self.moves:
            value, has_data = event_energy_kwh(m)
            if has_data:
                total += value
        return total

    @property
    def wasted_energy_kwh(self) -> float:
        return sum(event_wasted_energy_kwh(m) for m in self.moves)

    @property
    def unnecessary_moves(self) -> list:
        """The run of unnecessary events at the front of the case - used to
        split the case's move table into "unnecessary attempts" then the
        "necessary (closing) move" - see report_operation.py."""
        return [m for m in self.moves if m.is_unnecessary]

    @property
    def closing_move(self):
        """The event that closed the case (last one), or None if empty."""
        return self.moves[-1] if self.moves else None

    def to_dict(self):
        return {
            "case_num": self.case_num,
            "machine": self.machine,
            "time_start": self.time_start,
            "time_end": self.time_end,
            "total_duration_s": round(self.total_duration_s, 1),
            "total_distance_m": round(self.total_distance_m, 2),
            "n_moves": self.n_moves,
            "n_unnecessary": self.n_unnecessary,
            "n_necessary": self.n_necessary,
            "n_unknown": self.n_unknown,
            "closed_by_pickup": self.closed_by_pickup,
            "total_energy_kwh": round(self.total_energy_kwh, 4),
            "wasted_energy_kwh": round(self.wasted_energy_kwh, 4),
            "workorders": [m.workorder for m in self.moves],
            "event_kinds": [event_kind(m) for m in self.moves],
        }


def group_into_cases(events: List) -> List[OperationCase]:
    """
    events: a flat, time-ordered list of mixed MoveType3Result /
    PickupSetdownWorkorderResult for ONE machine (see merge_machine_events).
    Returns a list of OperationCase, in time order.
    """
    cases = []
    current: list = []
    case_num = 0

    for e in events:
        current.append(e)
        if event_closes_case(e):
            case_num += 1
            cases.append(OperationCase(case_num=case_num, machine=e.machine, moves=current))
            current = []

    if current:
        case_num += 1
        cases.append(OperationCase(case_num=case_num, machine=current[0].machine, moves=current))

    return cases


def group_all_machines(machine_results: dict, pickup_setdown_results: dict = None) -> "dict[str, List[OperationCase]]":
    """machine_results: {machine: [MoveType3Result, ...]}
    pickup_setdown_results: {machine: [PickupSetdownWorkorderResult, ...]}, optional.

    Merges each machine's MoveType=3 and pickup/setdown events into one
    chronological sequence before grouping into cases - see module
    docstring. If pickup_setdown_results is omitted, behaves exactly as
    before (MoveType=3 only)."""
    pickup_setdown_results = pickup_setdown_results or {}
    all_machines = set(machine_results.keys()) | set(pickup_setdown_results.keys())
    out = {}
    for machine in all_machines:
        mt3 = machine_results.get(machine, [])
        ps = pickup_setdown_results.get(machine, [])
        events = merge_machine_events(mt3, ps)
        out[machine] = group_into_cases(events)
    return out
