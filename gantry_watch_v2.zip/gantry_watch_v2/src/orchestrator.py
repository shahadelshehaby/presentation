"""
orchestrator.py
================
- discover_input_files(): finds every machine CSV in the PLC data folder
  (flat layout: one CSV per machine per day, e.g. "A205_2026-07-01.csv"),
  derives machine name + date.
- analyze_machine_day_file(): loads one file, and for every MoveType=3 move
  runs the three independent agents (sequence, performance, necessity) and
  packages their results into one MoveType3Result. This is the "master"
  combination point referenced in the per-machine report.
"""
import os
from dataclasses import dataclass, field
from typing import List, Optional

from data_loader import (load_plc_csv, split_workorders, find_movetype3_phases_with_context,
                          find_pickup_workorders_with_context)
from sequence_agent import evaluate_sequence, SequenceResult
from performance_agent import evaluate_performance, PerformanceResult
from necessity_agent import evaluate_necessity, NecessityResult
from power_agent import evaluate_power, PowerResult
from pickup_setdown_agent import evaluate_pickup_setdown, PickupSetdownResult
from utils import derive_machine_name


@dataclass
class MoveType3Result:
    workorder: int
    machine: str
    date: str
    time_start: str
    time_end: str
    duration_s: float
    workorder_warnings: List[str]
    sequence: SequenceResult
    performance: PerformanceResult
    necessity: NecessityResult
    power: PowerResult

    @property
    def flag(self) -> str:
        if self.sequence.has_abnormal or self.performance.verdict in ("issue", "aborted") \
                or (not self.necessity.necessary and not self.necessity.unknown):
            return "REVIEW"
        return "OK"

    @property
    def is_unnecessary(self) -> bool:
        """True only for a CONFIRMED unnecessary move (never for 'unknown' -
        there's no following workorder to judge it against)."""
        return (not self.necessity.necessary) and (not self.necessity.unknown)

    @property
    def wasted_energy_kwh(self) -> float:
        """Energy attributed to waste: the full energy of this move if it
        was confirmed unnecessary, otherwise 0."""
        return self.power.total_energy_kwh if self.is_unnecessary else 0.0

    def to_dict(self):
        return {
            "workorder": self.workorder,
            "machine": self.machine,
            "date": self.date,
            "time_start": self.time_start,
            "time_end": self.time_end,
            "duration_s": self.duration_s,
            "workorder_warnings": self.workorder_warnings,
            "flag": self.flag,
            "sequence": self.sequence.to_dict(),
            "performance": self.performance.to_dict(),
            "necessity": self.necessity.to_dict(),
            "power": self.power.to_dict(),
            "wasted_energy_kwh": round(self.wasted_energy_kwh, 4),
        }


@dataclass
class PickupSetdownWorkorderResult:
    """Same shape/spirit as MoveType3Result, but for one MoveType=1(+2)
    workorder, produced by pickup_setdown_agent.py.

    Also carries a `power` result now (same power_agent.evaluate_power()
    used for MoveType=3 phases, run across the whole workorder's rows) so
    pickup/setdown moves can be merged into the Operation report's unified
    case grouping/graph alongside MoveType=3 moves - see operation_agent.py
    - and so their energy is counted too when a case turns out unnecessary."""
    workorder: int
    machine: str
    date: str
    time_start: str
    time_end: str
    duration_s: float
    pickup_setdown: PickupSetdownResult
    power: Optional[PowerResult] = None

    @property
    def is_unnecessary(self) -> bool:
        return (not self.pickup_setdown.necessary) and (not self.pickup_setdown.unknown)

    @property
    def wasted_energy_kwh(self) -> float:
        """Same convention as MoveType3Result.wasted_energy_kwh: the full
        energy of this workorder if it was confirmed unnecessary, else 0."""
        if self.power is None or not self.power.has_any_data:
            return 0.0
        return self.power.total_energy_kwh if self.is_unnecessary else 0.0

    def to_dict(self):
        return {
            "workorder": self.workorder,
            "machine": self.machine,
            "date": self.date,
            "time_start": self.time_start,
            "time_end": self.time_end,
            "duration_s": self.duration_s,
            "pickup_setdown": self.pickup_setdown.to_dict(),
            "power": self.power.to_dict() if self.power is not None else None,
            "wasted_energy_kwh": round(self.wasted_energy_kwh, 4),
        }


def discover_input_files(input_dir: str):
    """Returns [(path, machine, fname)] for every CSV/XLSX found in
    input_dir, searched RECURSIVELY:
      - flat layout: file sits directly inside input_dir (e.g.
        "A205_2026-07-01.csv") -> machine parsed from the filename.
      - nested layout: file sits inside a subfolder (e.g.
        input_dir/A205/2026-07-01.csv) -> machine parsed from the
        immediate parent folder name instead, since a file inside a
        machine folder is often not itself prefixed with the machine code.

    Previously this only called os.listdir() on the top-level folder, which
    silently skipped every file sitting inside any subfolder - those days
    never got analyzed at all, which is a likely cause of reported days
    being fewer than the days actually present in the PLC data if any
    files are organized into per-machine subfolders."""
    found = []
    for root, dirs, files in os.walk(input_dir):
        dirs.sort()
        is_top_level = os.path.abspath(root) == os.path.abspath(input_dir)
        for fname in sorted(files):
            if not fname.lower().endswith((".csv", ".xlsx", ".xls")):
                continue
            path = os.path.join(root, fname)
            machine = derive_machine_name(fname) if is_top_level else os.path.basename(root)
            found.append((path, machine, fname))
    return found


def analyze_machine_day_file(path: str, machine: str, config):
    """
    Returns (movetype3_results, pickup_setdown_results, raw_dates) for one
    machine file - all computed from a single load/split of the file. A
    file is USUALLY one calendar day, but if it happens to span midnight
    (or several days), each move/workorder is tagged with the date of its
    OWN start time - not a single date for the whole file - so everything
    lands in the correct day's folder even when one file covers multiple
    days.

    movetype3_results: List[MoveType3Result] - one per MoveType=3 phase.
    pickup_setdown_results: List[PickupSetdownWorkorderResult] - one per
    workorder whose first phase is MoveType=1 (pickup).
    raw_dates: sorted set of every calendar date actually present in this
    file's own PLCTime column - derived directly from the raw data, NOT
    from the results below. A day can legitimately produce zero
    MoveType=3 moves and zero pickup workorders (e.g. an all-idle day, or
    an all-park/calibration day) while still being a real day of data that
    the caller should still create a folder/report for.
    """
    df = load_plc_csv(path)
    raw_dates = sorted(set(df["_ts"].dt.strftime("%Y-%m-%d")))
    workorders = split_workorders(df)
    results = []

    for wo, phase, next_wo in find_movetype3_phases_with_context(workorders):
        seq = evaluate_sequence(phase.rows, config)
        perf = evaluate_performance(phase.rows, seq.dominant_axis, config)
        nec = evaluate_necessity(phase.rows, seq.dominant_axis, next_wo, config)
        pw = evaluate_power(phase.rows, config)

        time_start = str(phase.rows.iloc[0]["_ts"])
        time_end = str(phase.rows.iloc[-1]["_ts"])
        duration_s = (phase.rows.iloc[-1]["_ts"] - phase.rows.iloc[0]["_ts"]).total_seconds()
        date_str = phase.rows.iloc[0]["_ts"].strftime("%Y-%m-%d")

        results.append(MoveType3Result(
            workorder=wo.workorder, machine=machine, date=date_str,
            time_start=time_start, time_end=time_end, duration_s=duration_s,
            workorder_warnings=wo.warnings,
            sequence=seq, performance=perf, necessity=nec, power=pw,
        ))

    pickup_setdown_results = []
    for wo, next_wo in find_pickup_workorders_with_context(workorders):
        ps = evaluate_pickup_setdown(wo, next_wo, config)
        if ps is None:
            continue
        time_start = str(wo.rows.iloc[0]["_ts"])
        time_end = str(wo.rows.iloc[-1]["_ts"])
        duration_s = (wo.rows.iloc[-1]["_ts"] - wo.rows.iloc[0]["_ts"]).total_seconds()
        date_str = wo.rows.iloc[0]["_ts"].strftime("%Y-%m-%d")
        pw = evaluate_power(wo.rows, config)

        pickup_setdown_results.append(PickupSetdownWorkorderResult(
            workorder=wo.workorder, machine=machine, date=date_str,
            time_start=time_start, time_end=time_end, duration_s=duration_s,
            pickup_setdown=ps, power=pw,
        ))

    return results, pickup_setdown_results, raw_dates
