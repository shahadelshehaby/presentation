"""
config_loader.py
=================
Reads config/golden_standard.xml and exposes it as a simple Config object.
No fitting happens here - the numbers in the XML are used as-is.
"""
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from typing import Dict, List, Optional


@dataclass
class AxisKinematics:
    acceleration_mps2: float
    deceleration_mps2: float
    top_speed_mps: float
    offset_s: float


@dataclass
class Thresholds:
    hoist_safe_height_m: float
    step_match_tolerance_m: float
    necessity_tolerance_m: float
    aborted_min_target_distance_m: float
    aborted_completion_pct: float
    performance_slow_threshold_pct: float


# Default drive-current / drive-voltage column names per axis (two drive
# units per axis). Used when golden_standard.xml has no <power_columns>
# section, so older config files keep working unchanged.
DEFAULT_POWER_COLUMNS = {
    "gantry": {
        "current": ["In_GANTRYCurrent1", "In_GANTRYCurrent2"],
        "voltage": ["In_GANTRYVoltage1", "In_GANTRYVoltage2"],
        "legacy": ["In_GANTRYDRIVE1", "In_GANTRYDRIVE2"],
    },
    "trolley": {
        "current": ["In_TROLLEYCurrent1", "In_TROLLEYCurrent2"],
        "voltage": ["In_TROLLEYVoltage1", "In_TROLLEYVoltage2"],
        "legacy": ["In_TROLLEYDRIVE1", "In_TROLLEYDRIVE2"],
    },
    "hoist": {
        "current": ["In_HOISTCurrent1", "In_HOISTCurrent2"],
        "voltage": ["In_HOISTVoltage1", "In_HOISTVoltage2"],
        "legacy": ["In_HOISTDRIVE1", "In_HOISTDRIVE2"],
    },
}


def _default_power_columns():
    return {axis: {k: list(v) for k, v in d.items()} for axis, d in DEFAULT_POWER_COLUMNS.items()}


@dataclass
class ColumnConfig:
    reference: Dict[str, str]
    actual_candidates: Dict[str, List[str]]
    speed_candidates: Dict[str, List[str]]
    # {axis: {"current": [drive1, drive2], "voltage": [drive1, drive2],
    #         "legacy": [drive1, drive2]}} - see power_agent.py
    power_columns: Dict[str, Dict[str, List[str]]] = field(default_factory=_default_power_columns)


@dataclass
class PowerConfig:
    """
    The PLC log has no voltage or power-factor channel - only per-axis drive
    CURRENT (In_GANTRYDRIVE1/2, In_TROLLEYDRIVE1/2, In_HOISTDRIVE1/2). To turn
    current into an estimated power/energy figure we assume a 3-phase AC
    supply at voltage_v with the given power_factor. These are configured
    machine constants (ASSUMPTIONS) - replace with your crane's real
    nameplate values for accurate energy figures.
    """
    voltage_v: float
    power_factor: float
    # Currency cost per kWh, used to turn wasted/total energy into a money
    # figure: cost = energy_kwh * cost_per_kwh. total_energy_kwh (see
    # power_agent.py) is ALREADY an integrated kW-over-time quantity, so no
    # further multiplication by duration is needed or correct here - doing
    # so would double-count time. None if not configured (report then shows
    # energy only, no cost column).
    cost_per_kwh: Optional[float] = None
    currency: str = "USD"


@dataclass
class Config:
    axes: Dict[str, AxisKinematics]
    thresholds: Thresholds
    columns: ColumnConfig
    expected_next_move_type: int
    power: PowerConfig
    source_path: str = ""


def _f(elem, tag, default=None):
    node = elem.find(tag)
    if node is None or node.text is None:
        if default is not None:
            return default
        raise ValueError(f"Missing required <{tag}> in config")
    return float(node.text.strip())


def load_config(path: str) -> Config:
    tree = ET.parse(path)
    root = tree.getroot()

    axes = {}
    for axis_el in root.findall("axis"):
        name = axis_el.get("name")
        axes[name] = AxisKinematics(
            acceleration_mps2=_f(axis_el, "acceleration_mps2"),
            deceleration_mps2=_f(axis_el, "deceleration_mps2"),
            top_speed_mps=_f(axis_el, "top_speed_mps"),
            offset_s=_f(axis_el, "offset_s"),
        )

    th_el = root.find("thresholds")
    thresholds = Thresholds(
        hoist_safe_height_m=_f(th_el, "hoist_safe_height_m"),
        step_match_tolerance_m=_f(th_el, "step_match_tolerance_m"),
        necessity_tolerance_m=_f(th_el, "necessity_tolerance_m"),
        aborted_min_target_distance_m=_f(th_el, "aborted_min_target_distance_m"),
        aborted_completion_pct=_f(th_el, "aborted_completion_pct"),
        performance_slow_threshold_pct=_f(th_el, "performance_slow_threshold_pct"),
    )

    cols_el = root.find("columns")
    ref_el = cols_el.find("reference")
    reference = {child.tag: child.text.strip() for child in ref_el}

    actual_el = cols_el.find("actual_candidates")
    actual_candidates = {}
    for axis_el in actual_el:
        actual_candidates[axis_el.tag] = [
            c.text.strip() for c in axis_el.findall("candidate") if c.text
        ]

    speed_el = cols_el.find("speed_candidates")
    speed_candidates = {}
    for axis_el in speed_el:
        speed_candidates[axis_el.tag] = [
            c.text.strip() for c in axis_el.findall("candidate") if c.text
        ]

    power_columns = _default_power_columns()
    pc_el = cols_el.find("power_columns")
    if pc_el is not None:
        for axis_el in pc_el:
            axis_cfg = power_columns.setdefault(axis_el.tag, {})
            for kind in ("current", "voltage", "legacy"):
                names = [c.text.strip() for c in axis_el.findall(kind) if c.text and c.text.strip()]
                if names:
                    axis_cfg[kind] = names

    columns = ColumnConfig(
        reference=reference,
        actual_candidates=actual_candidates,
        speed_candidates=speed_candidates,
        power_columns=power_columns,
    )

    necessity_el = root.find("necessity")
    expected_next_move_type = 1
    if necessity_el is not None:
        node = necessity_el.find("expected_next_move_type")
        if node is not None and node.text:
            expected_next_move_type = int(node.text.strip())

    power_el = root.find("power")
    # Sensible defaults if <power> is missing entirely (older config files) -
    # a standard 400V 3-phase supply at a typical 0.85 power factor.
    cost_per_kwh = None
    currency = "USD"
    if power_el is not None:
        cost_node = power_el.find("cost_per_kwh")
        if cost_node is not None and cost_node.text and cost_node.text.strip():
            cost_per_kwh = float(cost_node.text.strip())
        currency_node = power_el.find("currency")
        if currency_node is not None and currency_node.text:
            currency = currency_node.text.strip()
    power = PowerConfig(
        voltage_v=_f(power_el, "voltage_v", default=400.0) if power_el is not None else 400.0,
        power_factor=_f(power_el, "power_factor", default=0.85) if power_el is not None else 0.85,
        cost_per_kwh=cost_per_kwh,
        currency=currency,
    )

    return Config(
        axes=axes,
        thresholds=thresholds,
        columns=columns,
        expected_next_move_type=expected_next_move_type,
        power=power,
        source_path=path,
    )
