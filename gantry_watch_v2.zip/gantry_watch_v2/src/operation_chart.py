"""
operation_chart.py
=====================
Illustrations for the Operation report: a row of small RMG crane icons
connected by arrows, each arrow labeled with the distance (m) and duration
(HH:MM:SS) of that move - e.g. crane -> arrow "12.54m / 00:05:00" -> crane
-> arrow "25.5m / 00:12:00" -> crane.

FIXES (this revision):
- Title/legend overlap: the figure is now saved with bbox_inches='tight',
  which asks matplotlib to compute the ACTUAL space needed for every
  artist (title, legend, drawing) and grow the canvas to fit, rather than
  squeezing them into a fixed pre-guessed box - the previous tight_layout
  + bbox_to_anchor combination didn't reserve enough room and the title
  and legend text overlapped. The resulting PNG's real pixel aspect ratio
  is measured afterward so the reportlab Image is sized without stretching.
- Distance labels are now SIGNED: negative when the dominant axis' actual
  position DECREASED over the move (i.e. it traveled toward the opposite
  end), positive when it increased. Arrow/label COLOR still follows the
  necessity verdict only, unaffected by this sign.
- A move whose ending position did NOT reach ITS OWN commanded reference
  (performance.reached_reference is False) gets a small red "X" warning
  mark drawn above the crane icon it arrives at.

Arrow/label color still follows the necessity verdict:
  green  (#1e7e34) = necessary move
  red    (#c0392b) = confirmed unnecessary move
  grey   (#888888) = unknown (no following workorder to check against)
"""
import io
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from PIL import Image as PILImage
from reportlab.platypus import Image
from reportlab.lib.units import inch

from utils import format_hms
from operation_agent import (is_pickup_setdown_event, event_is_unknown,
                              event_is_necessary_confirmed, event_label)

NECESSARY_COLOR = "#1e7e34"
UNNECESSARY_COLOR = "#c0392b"
UNKNOWN_COLOR = "#888888"
CRANE_COLOR = "#9a9a9a"
WHEEL_COLOR = "#3d3d3d"
WARNING_COLOR = "#c0392b"

ICON_SPACING = 2.9    # x-axis units from one crane icon to the next
CRANE_HEIGHT = 2.6     # x-axis units, ground to top of beam
BEAM_HALF_W = 1.0
BEAM_THICK = 0.16
LEG_HALF_W = 0.16
LEG_CENTER_FRAC = 0.82   # leg centerline as a fraction of the beam half-width
WHEEL_W = 0.15
WHEEL_H = 0.22
SPREADER_DROP = 1.05     # cable length below the beam
SPREADER_SIZE = 0.32


def _move_color(move) -> str:
    """Works for both MoveType=3 moves and pickup/setdown workorders -
    both expose is_unnecessary, and event_is_unknown()/
    event_is_necessary_confirmed() read the right underlying field for
    whichever kind this event is (see operation_agent.py)."""
    if event_is_unknown(move):
        return UNKNOWN_COLOR
    return NECESSARY_COLOR if event_is_necessary_confirmed(move) else UNNECESSARY_COLOR


def _signed_distance_label(move) -> str:
    """Positive when the dominant axis' actual position increased over the
    move, negative when it decreased (traveled toward the opposite end).
    Uses position_start/position_end (the real recorded positions), not
    the unsigned distance magnitude used elsewhere.

    Pickup/setdown workorders now have their own dominant-axis distance
    too (see pickup_setdown_agent._dominant_axis_and_distance) - shown the
    same way as a MoveType=3 move. Falls back to the event's short kind
    label (e.g. "pickup only") only if a distance genuinely couldn't be
    computed (e.g. required position columns missing from that file)."""
    if is_pickup_setdown_event(move):
        ps = move.pickup_setdown
        if ps.position_start is None or ps.position_end is None:
            return event_label(move)
        signed = ps.position_end - ps.position_start
        return f"{signed:.2f}m"
    perf = move.performance
    if perf.position_start is None or perf.position_end is None:
        return f"{perf.distance_m:.2f}m"
    signed = perf.position_end - perf.position_start
    return f"{signed:.2f}m"


def _reached_reference(move):
    """None (no warning mark) for pickup/setdown events - the 'reached its
    own commanded reference' concept is specific to performance_agent's
    MoveType=3 kinematic model and has no equivalent here."""
    if is_pickup_setdown_event(move):
        return None
    return move.performance.reached_reference


def _draw_crane_icon(ax, x: float, y_base: float, scale: float = 1.0, color: str = CRANE_COLOR):
    """Draws one RMG gantry-crane pictogram (solid silhouette), feet resting
    on y_base, modeled on the reference photo: a beam with a stylized
    "break" mark, two solid legs, tandem wheel bogies, and a lattice-frame
    spreader hanging on cables from the beam center."""
    top_y = y_base + CRANE_HEIGHT * scale
    beam_hw = BEAM_HALF_W * scale
    beam_thick = BEAM_THICK * scale
    leg_hw = LEG_HALF_W * scale
    leg_cx_offset = LEG_CENTER_FRAC * beam_hw

    # top beam
    ax.add_patch(plt.Rectangle((x - beam_hw, top_y - beam_thick), 2 * beam_hw, beam_thick,
                                color=color, linewidth=0, zorder=3))
    # stylized "break" notches near the beam center (echoes the reference photo)
    for dx in (-0.14 * scale, 0.14 * scale):
        ax.plot([x + dx - 0.06 * scale, x + dx + 0.06 * scale],
                [top_y - beam_thick * 0.1, top_y - beam_thick * 0.9],
                color="white", lw=1.3, solid_capstyle="round", zorder=4)

    wheel_y = y_base
    leg_bottom_y = wheel_y + WHEEL_H * scale

    for side in (-1, 1):
        leg_cx = x + side * leg_cx_offset
        ax.add_patch(plt.Rectangle((leg_cx - leg_hw, leg_bottom_y), 2 * leg_hw,
                                    (top_y - beam_thick) - leg_bottom_y,
                                    color=color, linewidth=0, zorder=2))
        for wdx in (-0.11 * scale, 0.11 * scale):
            ax.add_patch(plt.Rectangle((leg_cx + wdx - WHEEL_W * scale / 2, wheel_y),
                                        WHEEL_W * scale, WHEEL_H * scale,
                                        color=WHEEL_COLOR, linewidth=0, zorder=5))

    # spreader: two thin cables + a small lattice-frame block + platform
    cable_top = top_y - beam_thick
    cable_bottom = cable_top - SPREADER_DROP * scale
    spreader_h = SPREADER_SIZE * scale
    spreader_w = SPREADER_SIZE * scale
    for cdx in (-0.06 * scale, 0.06 * scale):
        ax.plot([x + cdx, x + cdx], [cable_top, cable_bottom], color=color, lw=0.9, zorder=3)
    frame_bottom = cable_bottom - spreader_h
    ax.add_patch(plt.Rectangle((x - spreader_w / 2, frame_bottom), spreader_w, spreader_h,
                                fill=False, edgecolor=color, linewidth=1.1, zorder=4))
    ax.plot([x - spreader_w / 2, x + spreader_w / 2], [cable_bottom, frame_bottom],
            color=color, lw=0.9, zorder=4)
    ax.plot([x - spreader_w / 2, x + spreader_w / 2], [frame_bottom, cable_bottom],
            color=color, lw=0.9, zorder=4)
    ax.add_patch(plt.Rectangle((x - spreader_w * 0.65, frame_bottom - 0.05 * scale),
                                spreader_w * 1.3, 0.05 * scale, color=color, linewidth=0, zorder=4))

    return top_y


def _draw_reference_warning(ax, x: float, top_y: float, scale: float = 1.0):
    """Small red 'X' mark ABOVE the crane's beam (clear of the small grey
    spreader-hook X below it) flagging that this move's actual position
    did NOT reach its own commanded reference position."""
    wy = top_y + 0.32 * scale
    ax.plot([x], [wy], marker="X", markersize=11 * scale, markeredgewidth=1.4,
            markerfacecolor=WARNING_COLOR, markeredgecolor="#7a1f1f", zorder=10)


def _draw_arrow(ax, x_from: float, x_to: float, y: float, color: str,
                 distance_label: str, duration_label: str, scale: float = 1.0):
    ax.annotate(
        "", xy=(x_to - 0.85 * scale, y), xytext=(x_from + 0.85 * scale, y),
        arrowprops=dict(arrowstyle="-|>", color=color, lw=2.0, mutation_scale=18),
    )
    mid_x = (x_from + x_to) / 2.0
    ax.text(mid_x, y + 0.32 * scale, distance_label, color=color, fontsize=7.5,
            ha="center", va="bottom", fontweight="bold")
    ax.text(mid_x, y - 0.32 * scale, duration_label, color=color, fontsize=7.5,
            ha="center", va="top", fontweight="bold")


def _draw_chain(ax, moves, max_per_row: int = 4, case_end_labels: dict = None, scale: float = 1.0):
    """
    Draws `moves` (a time-ordered list of MoveType3Result) as a chain of
    crane icons + labeled arrows, wrapping to a new row every
    `max_per_row` moves. case_end_labels: optional {move_index: "Case N"}
    - a small tag drawn under the icon that CLOSES that case.
    Returns (xlim, ylim, n_rows) the caller should apply to the axes.
    """
    case_end_labels = case_end_labels or {}
    row_h = CRANE_HEIGHT * scale + 2.1 * scale
    arrow_y_frac = 0.38

    max_x = 0.0
    max_top_y = CRANE_HEIGHT * scale
    row = 0
    x = 0.0
    y_base = 0.0
    _draw_crane_icon(ax, x, y_base, scale)

    for i, m in enumerate(moves):
        col_in_row = i % max_per_row
        if col_in_row == 0 and i > 0:
            row += 1
            x = 0.0
            y_base = -row * row_h
            _draw_crane_icon(ax, x, y_base, scale)

        x_next = x + ICON_SPACING * scale
        color = _move_color(m)
        arrow_y = y_base + arrow_y_frac * CRANE_HEIGHT * scale
        _draw_arrow(ax, x, x_next, arrow_y, color,
                    _signed_distance_label(m), format_hms(m.duration_s), scale)
        top_y = _draw_crane_icon(ax, x_next, y_base, scale)

        if _reached_reference(m) is False:
            _draw_reference_warning(ax, x_next, top_y, scale)
            max_top_y = max(max_top_y, top_y + 0.7 * scale)

        if i in case_end_labels:
            ax.text(x_next, y_base - 0.45 * scale, case_end_labels[i], fontsize=6.5,
                    color="#333333", ha="center", va="top", style="italic")

        x = x_next
        max_x = max(max_x, x)

    xlim = (-1.3 * scale, max_x + 1.3 * scale)
    ylim = (-row * row_h - 1.1 * scale, max_top_y + 0.5 * scale)
    return xlim, ylim, row + 1


def _add_legend(fig, y_frac: float):
    """Horizontal legend (ncol=4, single row) placed in FIGURE coordinates
    at a fixed fraction of the figure height - see build_case_illustration()
    for why this must be figure-relative (not axes-relative) to keep a
    consistent gap from the title regardless of how many rows a case has."""
    handles = [
        Line2D([0], [0], color=NECESSARY_COLOR, lw=2.2, label="necessary"),
        Line2D([0], [0], color=UNNECESSARY_COLOR, lw=2.2, label="unnecessary"),
        Line2D([0], [0], color=UNKNOWN_COLOR, lw=2.2, label="unknown"),
        Line2D([0], [0], marker="X", color="none", markerfacecolor=WARNING_COLOR,
               markeredgecolor="#7a1f1f", markersize=9, label="didn't reach reference"),
    ]
    fig.legend(handles=handles, fontsize=7, loc="center", bbox_to_anchor=(0.5, y_frac),
               ncol=4, frameon=False, columnspacing=1.3, handletextpad=0.5)


# Fixed, ABSOLUTE (inches) header layout - deliberately NOT a fraction of
# the axes, because the axes' physical height changes with the number of
# rows a case needs (more moves -> taller figure). Using axes-relative
# fractions (e.g. bbox_to_anchor=(0.5, 1.06) on the axes) made the title
# and legend collide specifically on SHORT (single-row) cases, since the
# same fractional offset is a much smaller absolute gap on a short figure.
# Reserving a fixed number of inches from the top of the FIGURE keeps the
# gap identical no matter how tall the drawing below it is.
TITLE_FROM_TOP_IN = 0.30
LEGEND_FROM_TOP_IN = 0.62
HEADER_RESERVED_IN = 0.95   # axes drawing starts this far from the top


def build_case_illustration(case, width_in: float = 6.3, max_per_row: int = 4):
    """Returns a reportlab Image for one OperationCase, or None if it has
    no moves."""
    if not case.moves:
        return None

    n_rows_estimate = max(1, -(-len(case.moves) // max_per_row))  # ceil div
    height_in = 1.9 * n_rows_estimate + 1.0 + HEADER_RESERVED_IN

    fig, ax = plt.subplots(figsize=(width_in, height_in), dpi=150)
    xlim, ylim, n_rows = _draw_chain(ax, case.moves, max_per_row=max_per_row)
    ax.set_xlim(*xlim)
    ax.set_ylim(*ylim)
    ax.set_aspect("equal")
    ax.axis("off")

    fig.suptitle(
        f"Case {case.case_num} ({case.machine}) \u2014 total {case.total_distance_m:.1f} m, "
        f"{case.n_unnecessary} unnecessary of {case.n_moves} move(s)",
        fontsize=9, y=1 - TITLE_FROM_TOP_IN / height_in,
    )
    _add_legend(fig, y_frac=1 - LEGEND_FROM_TOP_IN / height_in)
    fig.subplots_adjust(top=1 - HEADER_RESERVED_IN / height_in)

    buf = io.BytesIO()
    # bbox_inches='tight' measures the REAL space every artist needs
    # (title, legend, drawing) and grows the saved canvas to fit all of it,
    # so nothing gets clipped at the edges - the actual title/legend
    # overlap fix is the fixed-inch header layout above; this just avoids
    # any edge clipping on top of that.
    fig.savefig(buf, format="png", bbox_inches="tight", pad_inches=0.2)
    plt.close(fig)
    buf.seek(0)

    # bbox_inches='tight' can change the output's pixel aspect ratio versus
    # the figure's original figsize, so measure the real PNG and size the
    # reportlab Image to match it exactly (fixed width, height computed
    # from the actual aspect ratio) rather than guessing - this avoids any
    # stretching/distortion.
    pil_img = PILImage.open(buf)
    px_w, px_h = pil_img.size
    actual_height_in = width_in * (px_h / px_w)
    buf.seek(0)

    # Cap the final image to fit within a single page frame. Without this,
    # a case with many chained moves (n_rows_estimate grows with
    # len(case.moves)) can produce an image TALLER than the usable page
    # height - reportlab then raises an unrecoverable LayoutError (the
    # flowable literally cannot fit on any page, blank or not), which
    # previously crashed the ENTIRE run_analysis.py process partway
    # through - silently dropping every day that would have been
    # processed after the crash, even though it existed in the raw PLC
    # data. Scaling down (preserving aspect ratio) instead of crashing
    # keeps large chains readable-but-smaller rather than fatal.
    from pdf_style import PAGE_SIZE, MARGIN
    max_width_in = (PAGE_SIZE[0] - 2 * MARGIN) / inch - 0.2   # small safety buffer
    max_height_in = (PAGE_SIZE[1] - 2 * MARGIN) / inch - 1.6  # leave room for the
    # heading/summary text/tables that are always placed above the
    # illustration on the same page (see report_operation.py) - this is a
    # conservative estimate, not exact, since that content varies in size.
    final_width_in, final_height_in = width_in, actual_height_in
    scale = min(max_width_in / final_width_in, max_height_in / final_height_in, 1.0)
    if scale < 1.0:
        final_width_in *= scale
        final_height_in *= scale

    return Image(buf, width=final_width_in * inch, height=final_height_in * inch)
