"""
data_loader.py
===============
Loads one PLC CSV (one machine, one day) and reconstructs workorders/phases.

Timestamp gotcha (see project reference doc, Section 2.2):
PLCTime looks like "2026-06-18-19:41:12" - hyphens throughout, no space/'T'.
Parse with format="%Y-%m-%d-%H:%M:%S". To grab just the time portion for
display, use rsplit("-", 1)[-1] (splits on the LAST hyphen only) - a naive
split(" ") does nothing useful here.
"""
from dataclasses import dataclass, field
from typing import List, Optional
import pandas as pd

from influx_clean import looks_like_influx, read_raw_file, normalize_plctime


TIME_FORMAT = "%Y-%m-%d-%H:%M:%S"


def time_only(plctime_str: str) -> str:
    return plctime_str.rsplit("-", 1)[-1]


def date_only(plctime_str: str) -> str:
    return plctime_str.rsplit("-", 1)[0]


@dataclass
class Phase:
    workorder: int
    phase_num: int
    move_type: int
    rows: pd.DataFrame  # rows belonging to this phase (MoveType == move_type)


@dataclass
class Workorder:
    workorder: int
    rows: pd.DataFrame
    phases: List[Phase] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)


def _peek_rows(path, n=5):
    if path.lower().endswith((".xlsx", ".xls")):
        return pd.read_excel(path, header=None, nrows=n, dtype=object).values.tolist()
    import csv
    with open(path, newline="", encoding="utf-8-sig") as f:
        return [row for _, row in zip(range(n), csv.reader(f))]


def load_plc_csv(path: str) -> pd.DataFrame:
    """Loads a PLC file (.csv or .xlsx/.xls), drops any manually-added
    'remark' column, de-duplicates repeated column names, and parses time.

    Raw InfluxDB exports are cleaned automatically (annotation rows and the
    result/table columns removed - see influx_clean.py), so they can be
    uploaded exactly as downloaded."""
    peek = _peek_rows(path)
    if peek and looks_like_influx(peek[0], peek[1:]):
        df = read_raw_file(path)
    elif path.lower().endswith((".xlsx", ".xls")):
        df = pd.read_excel(path)
    else:
        df = pd.read_csv(path, low_memory=False)

    # Defensive: if the source file has a column name repeated (e.g. PLCTime
    # listed twice in the export), pandas renames the second one PLCTime.1 -
    # drop those duplicates and keep the first occurrence of each name.
    if df.columns.duplicated().any():
        dup_names = df.columns[df.columns.duplicated()].tolist()
        df = df.loc[:, ~df.columns.duplicated()]
        print(f"    WARNING: duplicate column name(s) found and dropped (kept first "
              f"occurrence): {dup_names}")

    if "remark" in df.columns:
        df = df.drop(columns=["remark"])
    try:
        df["_ts"] = pd.to_datetime(df["PLCTime"], format=TIME_FORMAT)
    except (KeyError, ValueError, TypeError):
        # PLCTime missing, blank in places, or in another format: rebuild it
        # (from InfluxDB's _time, converted to local time, where needed).
        df = normalize_plctime(df)
        df["_ts"] = pd.to_datetime(df["PLCTime"], format=TIME_FORMAT)
    df = df.sort_values("_ts").reset_index(drop=True)
    return df


def split_workorders(df: pd.DataFrame) -> List[Workorder]:
    """Groups rows by WorkorderIdent, preserving first-seen order."""
    order = list(dict.fromkeys(df["WorkorderIdent"].tolist()))
    workorders = []
    for wo_id in order:
        wo_rows = df[df["WorkorderIdent"] == wo_id].reset_index(drop=True)
        wo = Workorder(workorder=int(wo_id), rows=wo_rows)
        for mt in wo_rows["MoveType"].unique():
            if int(mt) in (0, 4, 5) and int(mt) != 3:
                if int(mt) in (0,):
                    continue  # idle rows: skipped, not flagged
                wo.warnings.append(f"Unexpected MoveType {int(mt)} present in workorder")
        wo.phases = split_phases(wo_rows, wo_id)
        workorders.append(wo)
    return workorders


def split_phases(wo_rows: pd.DataFrame, wo_id: int) -> List[Phase]:
    """
    Detects phase boundaries by changes in MoveType. MoveType=0 rows are
    idle/transition rows - skipped when splitting phases, not flagged.
    """
    active = wo_rows[wo_rows["MoveType"] != 0].reset_index(drop=True)
    if active.empty:
        return []

    phases = []
    phase_num = 0
    current_mt = None
    current_rows = []

    def flush():
        nonlocal phase_num, current_rows
        if current_rows:
            phase_num += 1
            phase_df = pd.DataFrame(current_rows).reset_index(drop=True)
            phases.append(Phase(workorder=wo_id, phase_num=phase_num,
                                 move_type=current_mt, rows=phase_df))
            current_rows = []

    for _, row in active.iterrows():
        mt = int(row["MoveType"])
        if current_mt is None:
            current_mt = mt
        if mt != current_mt:
            flush()
            current_mt = mt
        current_rows.append(row)
    flush()
    return phases


def find_movetype3_phases_with_context(workorders: List[Workorder]):
    """
    Returns a list of (workorder, phase, next_workorder_or_None) for every
    MoveType=3 phase in the file. next_workorder is the very next Workorder
    object in the file (by first-seen order) - used only for the necessity
    check's "did we pre-position for what comes next" comparison.
    """
    results = []
    for i, wo in enumerate(workorders):
        for phase in wo.phases:
            if phase.move_type == 3:
                next_wo = workorders[i + 1] if i + 1 < len(workorders) else None
                results.append((wo, phase, next_wo))
    return results


def find_pickup_workorders_with_context(workorders: List[Workorder]):
    """
    Returns a list of (workorder, next_workorder_or_None) for every workorder
    whose FIRST phase is MoveType=1 (a pickup) - i.e. every workorder that is
    supposed to be a pickup(+setdown) job, per the doc's rule that Phase 1 of
    a two-part (non-MoveType=3) workorder is always MoveType=1.

    next_workorder is the very next Workorder object in the file (by
    first-seen order) - used by pickup_setdown_agent.py to detect a pickup
    that was never followed by a setdown IN THE SAME workorder.
    """
    results = []
    for i, wo in enumerate(workorders):
        if wo.phases and wo.phases[0].move_type == 1:
            next_wo = workorders[i + 1] if i + 1 < len(workorders) else None
            results.append((wo, next_wo))
    return results
