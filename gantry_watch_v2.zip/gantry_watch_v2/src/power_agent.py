"""
power_agent.py
================
Evaluation 4 - Power / Energy (real per-drive current x voltage).

Each axis (gantry, trolley, hoist) has TWO drive units, and each drive unit
now has its OWN current and voltage channel:

    gantry:  In_GANTRYCurrent1/2,  In_GANTRYVoltage1/2
    trolley: In_TROLLEYCurrent1/2, In_TROLLEYVoltage1/2
    hoist:   In_HOISTCurrent1/2,   In_HOISTVoltage1/2

Estimated instantaneous 3-phase AC power, computed PER DRIVE UNIT (since
each drive can legitimately have a different measured voltage) and then
summed:

    P_kW = sqrt(3) * PF / 1000 * (V1 * I1 + V2 * I2)

where V1/I1 and V2/I2 are drive-1's and drive-2's own voltage/current
readings for that axis, and PF (power factor) remains a configured machine
constant (see golden_standard.xml <power> section) since the PLC log still
has no power-factor channel - this one figure is still an ASSUMPTION that
should be corrected to the crane's real nameplate value if known.

Backward compatibility: if a file does NOT have the new Current/Voltage
columns for a given axis (older exports), this falls back to the previous
approach - treating the legacy In_<AXIS>DRIVE1/2 columns as a current
proxy and using the single configured voltage_v for that axis - so older
data files keep producing a (less accurate) power estimate rather than
silently zeroing that axis out.

Energy for a phase = trapezoidal integration of TOTAL instantaneous power
(summed across all three axes - not just the dominant one, since idle axes
can still draw holding/standby current) over elapsed time -> kWh.

This agent runs on every MoveType=3 phase, independently of sequence /
performance / necessity. Whether the resulting energy counts as "wasted"
is purely a function of the necessity agent's verdict (unnecessary moves'
energy = wasted energy) - decided by the caller, not by this module.
"""
import math
from dataclasses import dataclass, field
from typing import Dict, List

# New (real) per-drive current + voltage columns, one pair of each per
# drive unit, per axis.
AXIS_CURRENT_VOLTAGE_COLUMNS = {
    "gantry": {
        "current": ("In_GANTRYCurrent1", "In_GANTRYCurrent2"),
        "voltage": ("In_GANTRYVoltage1", "In_GANTRYVoltage2"),
    },
    "trolley": {
        "current": ("In_TROLLEYCurrent1", "In_TROLLEYCurrent2"),
        "voltage": ("In_TROLLEYVoltage1", "In_TROLLEYVoltage2"),
    },
    "hoist": {
        "current": ("In_HOISTCurrent1", "In_HOISTCurrent2"),
        "voltage": ("In_HOISTVoltage1", "In_HOISTVoltage2"),
    },
}

# Legacy fallback: older exports only had a current-like signal per drive
# (no voltage channel at all) - combined with the configured voltage_v
# assumption, same as the original version of this module.
AXIS_LEGACY_CURRENT_COLUMNS = {
    "gantry": ("In_GANTRYDRIVE1", "In_GANTRYDRIVE2"),
    "trolley": ("In_TROLLEYDRIVE1", "In_TROLLEYDRIVE2"),
    "hoist": ("In_HOISTDRIVE1", "In_HOISTDRIVE2"),
}


@dataclass
class PowerResult:
    axis_energy_kwh: Dict[str, float]
    total_energy_kwh: float
    avg_power_kw: float
    duration_s: float
    missing_columns: List[str] = field(default_factory=list)
    # axes where the new real current+voltage columns were used, vs axes
    # that fell back to the legacy current-only + assumed-voltage method.
    axes_using_real_voltage: List[str] = field(default_factory=list)
    axes_using_legacy_estimate: List[str] = field(default_factory=list)
    # axes where the expected column(s) EXIST in the file but contain no
    # usable readings for this phase (every row NaN/blank) - distinct from
    # missing_columns (column doesn't exist in the file at all). Both cases
    # mean "no consumption data for this axis", but are kept separate since
    # they point to different root causes (older export vs. a data gap).
    no_data_axes: List[str] = field(default_factory=list)

    @property
    def has_any_data(self) -> bool:
        """False only when EVERY axis had no usable reading at all - i.e.
        total_energy_kwh is meaningless (not just zero) for this phase."""
        return bool(self.axes_using_real_voltage or self.axes_using_legacy_estimate)

    def cost(self, config):
        """Wasted/total energy cost = energy_kwh * cost_per_kwh directly.
        total_energy_kwh is already an INTEGRATED quantity (kW integrated
        over the move's elapsed time via the trapezoidal rule - see
        _trapezoidal_energy_kwh below), so it is already "kilowatt-HOURS",
        not an instantaneous power figure. Multiplying it by duration again
        would double-count time and inflate the cost. Returns None (rather
        than 0.0) when there is no usable data at all, so callers can show
        "no consumption data" instead of a misleading $0.00."""
        if not self.has_any_data:
            return None
        rate = getattr(config.power, "cost_per_kwh", None)
        if rate is None:
            return None
        return self.total_energy_kwh * rate

    def to_dict(self):
        return {
            "axis_energy_kwh": {k: round(v, 4) for k, v in self.axis_energy_kwh.items()},
            "total_energy_kwh": round(self.total_energy_kwh, 4),
            "avg_power_kw": round(self.avg_power_kw, 3),
            "duration_s": round(self.duration_s, 1),
            "missing_columns": self.missing_columns,
            "axes_using_real_voltage": self.axes_using_real_voltage,
            "axes_using_legacy_estimate": self.axes_using_legacy_estimate,
            "no_data_axes": self.no_data_axes,
            "has_any_data": self.has_any_data,
        }


def _trapezoidal_energy_kwh(t_seconds, power_kw) -> float:
    """Integrates a power-vs-time series (kW, seconds) into energy (kWh)
    using the trapezoidal rule."""
    energy = 0.0
    for k in range(len(power_kw) - 1):
        dt_h = (t_seconds[k + 1] - t_seconds[k]) / 3600.0
        if dt_h <= 0:
            continue
        energy += 0.5 * (power_kw[k] + power_kw[k + 1]) * dt_h
    return energy


def _clean_numeric(series):
    """Coerces a column to numeric (blank cells / non-numeric junk -> NaN),
    then repairs sporadic gaps by linear interpolation with edge fill.

    Why this matters: a handful of empty cells among hundreds of rows used
    to poison the WHOLE energy total. _trapezoidal_energy_kwh() accumulates
    a running sum (`energy += ...`), so a single NaN power reading turns
    every subsequent partial sum - and therefore the final total - into NaN
    too, even though only one row out of hundreds was actually bad. That
    surfaced to the user as a literal "nan" in the PDF/JSON output for an
    otherwise perfectly good move. Interpolating fills those sporadic gaps
    from neighbouring readings instead of letting them wipe out the total.
    Returns (values, all_nan) so the caller can tell "a few gaps, patched"
    apart from "no usable data at all"."""
    import pandas as pd
    s = pd.to_numeric(series, errors="coerce")
    all_nan = bool(s.isna().all())
    if not all_nan and s.isna().any():
        s = s.interpolate(limit_direction="both")
        # interpolate() can't fill leading/trailing NaNs on its own in
        # older pandas without limit_direction="both"; belt-and-braces:
        s = s.ffill().bfill()
    return s.abs(), all_nan


def _axis_power_kw_real(phase_df, current_cols, voltage_cols, power_factor, sqrt3):
    """P_kW(t) = sqrt(3) * PF / 1000 * sum over drives of (V_drive * I_drive).
    Each drive's own current is multiplied by ITS OWN voltage before summing
    - correct even if the two drives on an axis run at different voltages.
    Returns (p_kw_list, all_nan) - all_nan True means every reading needed
    for this axis was blank across the WHOLE phase (a genuine "no
    consumption data" case, not just a couple of patched gaps)."""
    p_kw = None
    any_all_nan = False
    for i_col, v_col in zip(current_cols, voltage_cols):
        i, i_all_nan = _clean_numeric(phase_df[i_col])
        v, v_all_nan = _clean_numeric(phase_df[v_col])
        any_all_nan = any_all_nan or i_all_nan or v_all_nan
        term = (sqrt3 * power_factor / 1000.0) * (v * i)
        p_kw = term if p_kw is None else (p_kw + term)
    return p_kw.tolist(), any_all_nan


def _axis_power_kw_legacy(phase_df, current_cols, voltage_v, power_factor, sqrt3):
    """Legacy estimate: both drives' current-proxy readings combined, times
    one assumed shared voltage (the pre-upgrade behaviour of this module)."""
    c1, c2 = current_cols
    i1, i1_all_nan = _clean_numeric(phase_df[c1])
    i2, i2_all_nan = _clean_numeric(phase_df[c2])
    i_total = i1 + i2
    p_kw = (sqrt3 * voltage_v * power_factor / 1000.0) * i_total
    return p_kw.tolist(), (i1_all_nan or i2_all_nan)


def evaluate_power(phase_df, config) -> PowerResult:
    """
    phase_df: the full set of rows for one MoveType=3 phase (same dataframe
    passed to the sequence/performance agents).
    """
    power_factor = config.power.power_factor
    fallback_voltage_v = config.power.voltage_v
    sqrt3 = math.sqrt(3)

    ts = phase_df["_ts"]
    duration_s = (ts.iloc[-1] - ts.iloc[0]).total_seconds() if len(ts) > 1 else 0.0
    t_seconds = (ts - ts.iloc[0]).dt.total_seconds().tolist()

    axis_energy = {}
    missing = []
    real_axes = []
    legacy_axes = []
    no_data_axes = []
    total_energy = 0.0

    # Column names come from the active settings profile when available
    # (config.columns.power_columns), else the module-level defaults.
    cfg_cols = getattr(getattr(config, "columns", None), "power_columns", None) or {}

    for axis, cv_cols in AXIS_CURRENT_VOLTAGE_COLUMNS.items():
        axis_cfg = cfg_cols.get(axis, {})
        current_cols = tuple(axis_cfg.get("current") or cv_cols["current"])
        voltage_cols = tuple(axis_cfg.get("voltage") or cv_cols["voltage"])
        has_real = (len(current_cols) == len(voltage_cols) and len(current_cols) > 0
                    and all(c in phase_df.columns for c in current_cols + voltage_cols))

        if has_real:
            p_kw_list, all_nan = _axis_power_kw_real(phase_df, current_cols, voltage_cols, power_factor, sqrt3)
            if all_nan:
                # Column(s) exist but every row was blank for this phase -
                # "no consumption data", not a genuine zero-energy result.
                no_data_axes.append(axis)
                axis_energy[axis] = 0.0
                continue
            real_axes.append(axis)
        else:
            legacy_cols = tuple(axis_cfg.get("legacy") or AXIS_LEGACY_CURRENT_COLUMNS.get(axis, ()))
            has_legacy = len(legacy_cols) == 2 and all(c in phase_df.columns for c in legacy_cols)
            if has_legacy:
                p_kw_list, all_nan = _axis_power_kw_legacy(phase_df, legacy_cols, fallback_voltage_v, power_factor, sqrt3)
                if all_nan:
                    no_data_axes.append(axis)
                    axis_energy[axis] = 0.0
                    continue
                legacy_axes.append(axis)
            else:
                missing.append(axis)
                axis_energy[axis] = 0.0
                continue

        energy_kwh = _trapezoidal_energy_kwh(t_seconds, p_kw_list) if len(p_kw_list) > 1 else 0.0
        axis_energy[axis] = energy_kwh
        total_energy += energy_kwh

    avg_power_kw = (total_energy / (duration_s / 3600.0)) if duration_s > 0 else 0.0

    return PowerResult(
        axis_energy_kwh=axis_energy,
        total_energy_kwh=total_energy,
        avg_power_kw=avg_power_kw,
        duration_s=duration_s,
        missing_columns=missing,
        axes_using_real_voltage=real_axes,
        axes_using_legacy_estimate=legacy_axes,
        no_data_axes=no_data_axes,
    )
