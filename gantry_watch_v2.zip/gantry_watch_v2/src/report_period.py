"""
report_period.py
=================
"Period Overview" PDF for a date range (e.g. 01.01.2026 to 03.01.2026).

The Summary and Operation reports can already be built over a whole period
(the pipeline just hands them every result in the range). What they don't
show is how the period developed day by day, or how lanes compare - that's
this report:

  - headline totals for the period and the active filters
  - a per-day chart: reposition moves (necessary / unnecessary / unknown)
    and wasted energy
  - per-day, per-lane and per-crane tables

Energy here = MoveType=3 repositions + pickup/setdown workorders. Wasted
energy = the energy of every move/workorder confirmed unnecessary (same rule
as the other reports; 'unknown' is never counted as waste).
"""
import io
from collections import defaultdict

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, Image
from reportlab.lib import colors
from reportlab.lib.units import inch

from pdf_style import get_styles, PAGE_SIZE, MARGIN, HEADER_BG
from utils import format_cost, display_date, lane_of

NEC_COLOR = "#2E7D4F"
UNNEC_COLOR = "#C0392B"
UNK_COLOR = "#9AA4AE"


def _energy(power):
    return power.total_energy_kwh if (power is not None and power.has_any_data) else 0.0


class _Tally:
    def __init__(self):
        self.machines = set()
        self.moves = self.flagged = self.unnec = self.nec = self.unknown = 0
        self.pickups = self.ps_unnec = 0
        self.energy = self.wasted = 0.0

    def add_move(self, r):
        self.machines.add(r.machine)
        self.moves += 1
        self.flagged += r.flag == "REVIEW"
        if r.necessity.unknown:
            self.unknown += 1
        elif r.necessity.necessary:
            self.nec += 1
        else:
            self.unnec += 1
        self.energy += _energy(r.power)
        self.wasted += r.wasted_energy_kwh if r.power.has_any_data else 0.0

    def add_ps(self, r):
        self.machines.add(r.machine)
        self.pickups += 1
        self.ps_unnec += r.is_unnecessary
        self.energy += _energy(r.power)
        self.wasted += r.wasted_energy_kwh


def _tally(results_by_date, ps_by_date, key_fn):
    out = defaultdict(_Tally)
    for date, by_machine in results_by_date.items():
        for machine, rs in by_machine.items():
            for r in rs:
                out[key_fn(date, machine)].add_move(r)
    for date, by_machine in ps_by_date.items():
        for machine, rs in by_machine.items():
            for r in rs:
                out[key_fn(date, machine)].add_ps(r)
    return out


def _table(first_header, rows, styles, config, extra_first=None, show_cranes=True):
    show_cost = config is not None and getattr(config.power, "cost_per_kwh", None) is not None
    headers = [first_header] + ([extra_first] if extra_first else []) + (["Cranes"] if show_cranes else []) + [
        "Reposition moves", "Flagged for review", "Unnecessary repositions",
        "Pickup workorders", "Unnecessary pickups", "Energy (kWh)", "Wasted energy (kWh)"]
    if show_cost:
        headers.append(f"Wasted cost ({config.power.currency})")
    P = lambda t, st="Body9": Paragraph(str(t), styles[st])
    data = [[P(h, "TableHeader") for h in headers]]
    total = _Tally()
    for label, extra, t in rows:
        row = [P(label)] + ([P(extra)] if extra_first else []) + ([P(len(t.machines))] if show_cranes else []) + [
            P(t.moves), P(t.flagged), P(t.unnec), P(t.pickups), P(t.ps_unnec),
            P(f"{t.energy:.3f}"), P(f"{t.wasted:.3f}")]
        if show_cost:
            row.append(P(format_cost(t.wasted, config)))
        data.append(row)
        total.machines |= t.machines
        for f in ("moves", "flagged", "unnec", "pickups", "ps_unnec", "energy", "wasted"):
            setattr(total, f, getattr(total, f) + getattr(t, f))
    b = lambda v: P(f"<b>{v}</b>")
    tot = [b("TOTAL")] + ([P("")] if extra_first else []) + ([b(len(total.machines))] if show_cranes else []) + [
        b(total.moves), b(total.flagged), b(total.unnec), b(total.pickups),
        b(total.ps_unnec), b(f"{total.energy:.3f}"), b(f"{total.wasted:.3f}")]
    if show_cost:
        tot.append(b(format_cost(total.wasted, config)))
    data.append(tot)

    n = len(headers)
    first_w = 1.15 * inch
    rest = (PAGE_SIZE[0] - 2 * MARGIN - first_w) / (n - 1)
    t = Table(data, repeatRows=1, colWidths=[first_w] + [rest] * (n - 1))
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), HEADER_BG),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("ROWBACKGROUNDS", (0, 1), (-1, -2), [colors.white, colors.HexColor("#f7f7f7")]),
        ("BACKGROUND", (0, -1), (-1, -1), colors.HexColor("#eeeeee")),
    ]))
    return t


def _daily_chart(dates, per_day):
    labels = [display_date(d)[:5] for d in dates]
    nec = [per_day[d].nec for d in dates]
    unnec = [per_day[d].unnec for d in dates]
    unk = [per_day[d].unknown for d in dates]
    wasted = [per_day[d].wasted for d in dates]
    x = range(len(dates))

    fig, (a1, a2) = plt.subplots(1, 2, figsize=(10.4, 2.9), dpi=150)
    a1.bar(x, nec, color=NEC_COLOR, label="Necessary")
    a1.bar(x, unnec, bottom=nec, color=UNNEC_COLOR, label="Unnecessary")
    a1.bar(x, unk, bottom=[a + b for a, b in zip(nec, unnec)], color=UNK_COLOR, label="Unknown")
    a1.set_title("Reposition moves per day", fontsize=10)
    a1.legend(fontsize=7, frameon=False, ncol=3, loc="upper left")
    a2.bar(x, wasted, color=UNNEC_COLOR)
    a2.set_title("Wasted energy per day (kWh)", fontsize=10)
    step = max(1, len(dates) // 15)  # keep x labels readable on long periods
    for ax in (a1, a2):
        ax.set_xticks(list(x)[::step])
        ax.set_xticklabels(labels[::step], fontsize=7, rotation=45 if len(dates) > 10 else 0)
        ax.tick_params(axis="y", labelsize=7)
        ax.spines[["top", "right"]].set_visible(False)
        ax.grid(axis="y", alpha=.3)
    a1.set_ylim(top=max([a + b + c for a, b, c in zip(nec, unnec, unk)] + [1]) * 1.25)
    fig.tight_layout()
    buf = io.BytesIO()
    fig.savefig(buf, format="png")
    plt.close(fig)
    buf.seek(0)
    w = PAGE_SIZE[0] - 2 * MARGIN
    return Image(buf, width=w, height=w * 2.9 / 10.4)


def generate_period_report(period_label, results_by_date, ps_by_date, out_path,
                           filters_text="", config=None):
    """results_by_date: {date: {machine: [MoveType3Result]}}
    ps_by_date: {date: {machine: [PickupSetdownWorkorderResult]}}"""
    styles = get_styles()
    doc = SimpleDocTemplate(out_path, pagesize=PAGE_SIZE, leftMargin=MARGIN, rightMargin=MARGIN,
                            topMargin=MARGIN, bottomMargin=MARGIN)
    dates = sorted(set(results_by_date) | set(ps_by_date))
    per_day = _tally(results_by_date, ps_by_date, lambda d, m: d)
    per_lane = _tally(results_by_date, ps_by_date, lambda d, m: lane_of(m))
    per_machine = _tally(results_by_date, ps_by_date, lambda d, m: m)
    total = _tally(results_by_date, ps_by_date, lambda d, m: "all")["all"]

    flow = [Paragraph(f"Period Overview &mdash; {period_label}", styles["H1"])]
    if filters_text:
        flow.append(Paragraph(filters_text, styles["Body9"]))
    show_cost = config is not None and getattr(config.power, "cost_per_kwh", None) is not None
    pct = f" ({100 * total.wasted / total.energy:.1f}% of total)" if total.energy > 0 else ""
    flow.append(Paragraph(
        f"Days with data: <b>{len(dates)}</b> &nbsp;&nbsp; Cranes: <b>{len(total.machines)}</b> &nbsp;&nbsp; "
        f"Reposition moves: <b>{total.moves}</b> (unnecessary: <b>{total.unnec}</b>, flagged: {total.flagged}) "
        f"&nbsp;&nbsp; Pickup workorders: <b>{total.pickups}</b> (unnecessary: <b>{total.ps_unnec}</b>)",
        styles["Body9"]))
    flow.append(Paragraph(
        f"Energy: <b>{total.energy:.3f} kWh</b> &nbsp;&nbsp; Wasted energy: <b>{total.wasted:.3f} kWh</b>{pct}"
        + (f" &nbsp;&nbsp; Wasted cost: <b>{format_cost(total.wasted, config)}</b>" if show_cost else ""),
        styles["Body9"]))
    flow.append(Spacer(1, 8))

    if not dates:
        flow.append(Paragraph("No data found for the selected cranes in this period.", styles["Body9"]))
        doc.build(flow)
        return out_path

    flow.append(_daily_chart(dates, per_day))
    flow.append(Spacer(1, 6))
    flow.append(Paragraph(
        "Energy includes repositions (MoveType 3) and pickup/setdown workorders. Wasted energy is the "
        "energy of moves confirmed unnecessary; moves with no following workorder to check against "
        "count as unknown, not waste.", styles["Body8"]))

    flow.append(Spacer(1, 12))
    flow.append(Paragraph("Per day", styles["H2"]))
    flow.append(_table("Date", [(display_date(d), None, per_day[d]) for d in dates], styles, config))

    flow.append(Spacer(1, 16))
    flow.append(Paragraph("Per lane", styles["H2"]))
    flow.append(_table("Lane", [(lane, None, per_lane[lane]) for lane in sorted(per_lane)], styles, config))

    flow.append(Spacer(1, 16))
    flow.append(Paragraph("Per crane", styles["H2"]))
    flow.append(_table("Crane", [(m, lane_of(m), per_machine[m]) for m in sorted(per_machine)],
                       styles, config, extra_first="Lane", show_cranes=False))

    doc.build(flow)
    return out_path
