/* CodeGuard web interface. Everything is local: no internet libraries.
   All text from the server is escaped with esc() before it is put into the page. */
"use strict";

const S = { state: null, tab: "dashboard", findings: [], selected: null, checked: new Set(), settings: null,
            browsePath: "", lastRunning: false };
const SEV = ["critical", "high", "medium", "low", "info"];
const $ = (id) => document.getElementById(id);

function esc(v) {
  return String(v == null ? "" : v).replace(/[&<>"']/g, (c) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}
function setHTML(el, s) { el.innerHTML = s; } // codeguard: ignore - every caller builds s with esc()

async function api(path, opts) {
  const o = Object.assign({ headers: {} }, opts || {});
  if (o.json !== undefined) { o.method = o.method || "POST"; o.headers["Content-Type"] = "application/json"; o.body = JSON.stringify(o.json); }
  const r = await fetch(path, o);
  let data = null;
  try { data = await r.json(); } catch (e) { data = null; }
  if (!r.ok || (data && data.ok === false)) throw new Error((data && data.error) || ("Request failed (" + r.status + ")"));
  return data;
}
function toast(msg, bad) {
  const t = $("toast");
  t.textContent = msg; t.className = "toast" + (bad ? " bad" : ""); t.hidden = false;
  clearTimeout(toast._t); toast._t = setTimeout(() => { t.hidden = true; }, bad ? 7000 : 3500);
}
async function run(fn, okMsg) {
  try { const r = await fn(); if (okMsg) toast(okMsg); return r; } catch (e) { toast(e.message, true); return null; }
}
function store(k, v) { try { if (v === undefined) return localStorage.getItem(k); localStorage.setItem(k, v); } catch (e) { return null; } return null; }
function me() { return $("person").value || ""; }

/* ---------------------------------------------------------------- modal (PIN, confirm, input) */
function modal(title, bodyHtml, okLabel) {
  return new Promise((resolve) => {
    $("modalTitle").textContent = title;
    setHTML($("modalBody"), bodyHtml);
    $("modalOk").textContent = okLabel || "OK";
    $("modal").hidden = false;
    const first = $("modalBody").querySelector("input,textarea,select"); if (first) first.focus();
    const done = (ok) => {
      $("modal").hidden = true; $("modalOk").onclick = $("modalCancel").onclick = null;
      if (!ok) return resolve(null);
      const vals = {}; $("modalBody").querySelectorAll("[name]").forEach((el) => { vals[el.name] = el.value; });
      resolve(vals);
    };
    $("modalOk").onclick = () => done(true); $("modalCancel").onclick = () => done(false);
    $("modalBody").onkeydown = (e) => { if (e.key === "Enter" && e.target.tagName === "INPUT") done(true); };
  });
}
async function askPin(why) {
  if (!S.state || !S.state.pin_set) return "";
  const v = await modal("Approval PIN", '<p class="muted">' + esc(why) + '</p><input type="password" name="pin" placeholder="PIN">', "Confirm");
  return v ? v.pin : null;
}
function needMe() {
  if (!me()) { toast("Choose who you are (top right) first. Add people in Settings.", true); return false; }
  return true;
}

/* ---------------------------------------------------------------- state polling */
async function refreshState() {
  try { S.state = await api("/api/state"); } catch (e) { setLive("error", "CodeGuard server not reachable"); return; }
  const st = S.state, p = st.progress, ap = st.ai_progress;
  if (p.running) {
    setLive("working", "Scanning " + p.platform + " - " + (p.step || "") + (p.queue.length ? "  (" + p.queue.length + " waiting)" : ""),
      p.total ? (100 * p.done / p.total) : 5);
  } else if (ap.running) {
    setLive("working", "AI: " + (ap.step || "working") + (ap.queue ? "  (" + ap.queue + " waiting)" : ""), ap.total ? 100 * ap.done / ap.total : 5);
  } else if (p.last_error) {
    setLive("error", "Last scan error: " + p.last_error, 0);
  } else {
    setLive("idle", "Idle" + (st.nightly ? " - next automatic scan at " + st.nightly : ""), 0);
  }
  const running = p.running || ap.running;
  if (S.lastRunning && !running) onWorkFinished();
  S.lastRunning = running;
  const waiting = st.platforms.reduce((a, x) => a + x.fixes_waiting, 0);
  $("fixCount").textContent = waiting ? String(waiting) : "";
  fillPeople();
  if (S.tab === "dashboard") renderDashboard();
}
function setLive(kind, text, pct) {
  $("live").querySelector(".dot").className = "dot " + kind;
  $("live").classList.toggle("is-error", kind === "error");
  $("liveText").textContent = text; $("liveText").title = text;
  $("liveBar").style.width = (pct || 0) + "%";
}
function onWorkFinished() {
  if (S.tab === "findings") loadFindings();
  if (S.tab === "platforms") renderPlatforms();
  if (S.tab === "scans") loadScans();
  if (S.tab === "fixes") loadFixes();
  if (S.tab === "ai") renderAI();
  if (S.selected) openFinding(S.selected, true);
}
function fillPeople() {
  const sel = $("person"), cur = sel.value || store("cg_person") || "";
  const names = (S.state.people || []).map((p) => p.name);
  const key = names.join("|");
  if (sel.dataset.key === key) return;
  sel.dataset.key = key;
  setHTML(sel, '<option value="">- choose -</option>' + names.map((n) => '<option>' + esc(n) + '</option>').join(""));
  if (names.includes(cur)) sel.value = cur;
}

/* ---------------------------------------------------------------- company logo
   Same logo file as your other platforms: copy it into this platform's  static  folder as
   logo.png (or logo.svg / logo.jpg / logo.webp). It is shown at double size and used as the tab icon. */
const LOGO_FILES = ["/static/logo.svg", "/static/logo.png", "/static/logo.jpg", "/static/logo.jpeg", "/static/logo.webp"];
function loadLogo(i) {
  i = i || 0;
  if (i >= LOGO_FILES.length) { $("logoWrap").hidden = true; $("logoAdd").hidden = false; return; }
  const img = $("logoImg");
  img.onload = () => { $("logoWrap").hidden = false; $("logoAdd").hidden = true; $("favicon").href = LOGO_FILES[i]; };
  img.onerror = () => loadLogo(i + 1);
  img.src = LOGO_FILES[i] + "?v=" + Date.now();
}
async function explainLogo() {
  await modal("Add the company logo", "<p>Copy the same logo file you use in your other platforms into CodeGuard's <code>static</code> folder " +
    "and name it <code>logo.png</code> (or <code>logo.svg</code>), next to <code>app.css</code>.</p><p class=\"muted\">Then click OK; the logo appears at once, " +
    "no restart needed.</p>", "OK");
  loadLogo(0);
}

/* ---------------------------------------------------------------- tabs */
function showTab(t) {
  S.tab = t;
  document.querySelectorAll("#tabs button").forEach((b) => b.classList.toggle("on", b.dataset.tab === t));
  document.querySelectorAll(".tab").forEach((s) => s.classList.toggle("on", s.id === "tab-" + t));
  store("cg_tab", t);
  ({ dashboard: renderDashboard, findings: initFindings, platforms: renderPlatforms, ai: renderAI, fixes: loadFixes,
     libraries: loadLibraries, scans: loadScans, reports: renderReports, settings: loadSettings }[t] || (() => {}))();
}

/* ---------------------------------------------------------------- dashboard */
function sevBar(c) {
  const tot = SEV.slice(0, 4).reduce((a, s) => a + (c[s] || 0), 0);
  if (!tot) return '<div class="sevbar"></div>';
  return '<div class="sevbar">' + SEV.slice(0, 4).map((s) => c[s] ? '<i class="' + s + '" style="width:' + (100 * c[s] / tot) + '%"></i>' : "").join("") + "</div>";
}
function renderDashboard() {
  const st = S.state; if (!st) return;
  const notes = [];
  if (!st.platforms.filter((p) => p.enabled).length) notes.push(["", 'No platforms connected yet. Open <b>Platforms</b> to connect your platform folders.']);
  if (!st.vulndb.loaded) notes.push(["", "The vulnerability database is not installed, so libraries are only checked for pinned versions. Import it in Settings."]);
  if (!st.people.length) notes.push(["", "Add the people who review findings in Settings, then pick your name at the top right."]);
  if (!st.pin_set) notes.push(["", "No approval PIN is set. Anyone using this page can accept risks or apply fixes. Set one in Settings."]);
  st.platforms.filter((p) => p.enabled && !p.exists).forEach((p) => notes.push(["bad", "Folder not found for " + esc(p.name) + ": " + esc(p.path)]));
  setHTML($("notices"), notes.map((n) => '<div class="notice ' + n[0] + '">' + n[1] + "</div>").join(""));
  const t = st.totals, plats = st.platforms.filter((p) => p.enabled);
  const awaiting = plats.reduce((a, p) => a + p.awaiting, 0), fixes = plats.reduce((a, p) => a + p.fixes_waiting, 0);
  setHTML($("kpis"), [
    ["critical", t.critical, "Critical open"], ["high", t.high, "High open"], ["medium", t.medium, "Medium open"],
    ["low", t.low, "Low open"], ["", awaiting, "New, not yet reviewed"], ["", fixes, "Fixes waiting approval"],
    ["", plats.length, "Platforms connected"]].map((k) =>
    '<div class="kpi ' + k[0] + '"><b>' + esc(k[1]) + "</b><span>" + esc(k[2]) + "</span></div>").join(""));
  setHTML($("platformCards"), st.platforms.map((p) => {
    const c = p.counts || {};
    const g = p.grade || "none";
    return '<div class="card' + (p.enabled ? "" : " off") + '"><div class="head"><div class="grade ' + esc(g) + '">' +
      esc(p.grade || "-") + '</div><div style="min-width:0"><div class="title">' + esc(p.name) + '</div><div class="path">' +
      esc(p.path) + '</div></div></div>' + sevBar(c) +
      '<div class="counts"><span><b>' + (c.critical || 0) + '</b> critical</span><span><b>' + (c.high || 0) + '</b> high</span><span><b>' +
      (c.medium || 0) + '</b> medium</span><span><b>' + (c.low || 0) + '</b> low</span></div>' +
      '<div class="muted" style="font-size:12px">' + (p.last_scan ? "Score " + esc(p.score) + " &middot; " + esc(p.files) + " files, " +
      esc(p.lines) + " lines &middot; scanned " + esc(p.last_scan) : (p.last_status === "running" ? "Scanning..." : "Not scanned yet")) +
      (p.last_status === "error" ? '<br><span class="st-bad">Last scan failed: ' + esc(p.last_error) + "</span>" : "") + "</div>" +
      '<div class="row gap"><button class="btn small" data-scan="' + p.id + '">Scan now</button>' +
      '<button class="btn small" data-view="' + p.id + '">Findings (' + esc(p.awaiting) + ' new)</button>' +
      '<a class="btn small" href="/report?platform_id=' + p.id + '" target="_blank" rel="noopener noreferrer">Report</a></div></div>';
  }).join(""));
}

/* ---------------------------------------------------------------- findings */
function initFindings() {
  const st = S.state;
  const fp = $("fPlatform"), keep = fp.value;
  setHTML(fp, '<option value="">All platforms</option>' + st.platforms.map((p) => '<option value="' + p.id + '">' + esc(p.name) + "</option>").join(""));
  fp.value = keep;
  if ($("fSeverity").options.length < 2) {
    setHTML($("fSeverity"), '<option value="">All severities</option><option value="critical,high">Critical + high</option>' +
      SEV.map((s) => "<option>" + s + "</option>").join(""));
    setHTML($("fLayer"), '<option value="">All layers</option>' + Object.entries(st.layers).map((l) => '<option value="' + esc(l[0]) + '">' + esc(l[1]) + "</option>").join(""));
    setHTML($("fStatus"), '<option value="new,under_review,confirmed">Needs action</option><option value="">Any status</option>' +
      Object.entries(st.statuses).map((s) => '<option value="' + esc(s[0]) + '">' + esc(s[1]) + "</option>").join(""));
    setHTML($("bulkStatus"), Object.entries(st.statuses).map((s) => '<option value="' + esc(s[0]) + '">Set: ' + esc(s[1]) + "</option>").join(""));
  }
  loadFindings();
}
async function loadFindings() {
  const qs = new URLSearchParams();
  const add = (k, v) => { if (v) qs.set(k, v); };
  add("platform_id", $("fPlatform").value); add("severity", $("fSeverity").value); add("layer", $("fLayer").value);
  add("status", $("fStatus").value); qs.set("state", $("fState").value); add("q", $("fSearch").value.trim());
  const rows = await run(() => api("/api/findings?" + qs.toString()));
  if (!rows) return;
  S.findings = rows;
  S.checked.forEach((id) => { if (!rows.find((r) => r.id === id)) S.checked.delete(id); });
  $("fCount").textContent = rows.length + " finding" + (rows.length === 1 ? "" : "s");
  renderFindingList();
}
function renderFindingList() {
  const statuses = S.state.statuses;
  if (!S.findings.length) { setHTML($("findingList"), '<div class="empty muted" style="padding:30px;text-align:center">Nothing here. Good news, or try other filters.</div>'); updateBulk(); return; }
  setHTML($("findingList"), S.findings.map((f) =>
    '<div class="frow' + (S.selected === f.id ? " sel" : "") + '" data-id="' + f.id + '">' +
    '<input type="checkbox" data-check="' + f.id + '"' + (S.checked.has(f.id) ? " checked" : "") + '>' +
    '<div><span class="sev ' + esc(f.severity) + '">' + esc(f.severity) + "</span></div>" +
    '<div style="min-width:0"><div class="t">' + esc(f.title) + '</div><div class="m">' + esc(f.msg) + "</div>" +
    '<div class="tags"><span class="loc">' + esc(f.platform) + " &rsaquo; " + esc(f.file) + (f.line ? ":" + esc(f.line) : "") + "</span>" +
    '<span class="status ' + esc(f.status) + '">' + esc(statuses[f.status] || f.status) + "</span>" +
    (f.source === "ai" ? '<span class="tag ai">AI only</span>' : "") + (f.tool ? '<span class="tag">' + esc(f.tool) + "</span>" : "") +
    (f.has_ai && f.source !== "ai" ? '<span class="tag ai">AI explained</span>' : "") +
    (f.remarks ? '<span class="tag">' + esc(f.remarks) + " remark" + (f.remarks > 1 ? "s" : "") + "</span>" : "") +
    (f.state === "resolved" ? '<span class="tag">gone</span>' : "") + "</div></div></div>").join(""));
  updateBulk();
}
function updateBulk() {
  $("bulk").hidden = S.checked.size === 0;
  $("bulkCount").textContent = S.checked.size + " selected";
}
function codeBlock(start, lines, hit) {
  return '<div class="code">' + lines.map((l, i) => {
    const n = start + i;
    return '<div class="' + (n === hit ? "hit" : "") + '"><span class="n">' + n + "</span><span>" + esc(l) + "</span></div>";
  }).join("") + "</div>";
}
function diffBlock(lines) {
  return '<div class="diff">' + (lines || []).map((l) => {
    const cls = l.startsWith("+++") || l.startsWith("---") || l.startsWith("@@") ? "h" : l.startsWith("+") ? "a" : l.startsWith("-") ? "d" : "";
    return '<span class="' + cls + '" style="display:block">' + esc(l || " ") + "</span>";
  }).join("") + "</div>";
}
async function openFinding(id, quiet) {
  S.selected = id;
  document.querySelectorAll(".frow").forEach((r) => r.classList.toggle("sel", Number(r.dataset.id) === id));
  const f = quiet ? await api("/api/findings/" + id).catch(() => null) : await run(() => api("/api/findings/" + id));
  if (!f) return;
  const st = S.state, ri = f.rule_info;
  let h = '<div class="row gap wrap"><span class="sev ' + esc(f.severity) + '">' + esc(f.severity) + '</span><span class="status ' + esc(f.status) +
    '">' + esc(st.statuses[f.status] || f.status) + "</span>" + '<span class="tag">' + esc(f.rule) + "</span>" +
    (ri.cwe ? '<span class="tag">' + esc(ri.cwe) + "</span>" : "") + '<span class="tag">' + esc(st.layers[f.layer] || f.layer) + "</span>" +
    (f.source === "ai" ? '<span class="tag ai">AI only - needs review</span>' : "") + "</div>";
  h += "<h2>" + esc(f.title) + "</h2>";
  h += '<div class="loc" style="font-family:var(--mono);font-size:12px;color:var(--link)">' + esc(f.platform) + " &rsaquo; " + esc(f.file) + (f.line ? " line " + esc(f.line) : "") + "</div>";
  h += '<p style="margin:8px 0">' + esc(f.msg) + "</p>";
  if (f.context && f.context.lines) h += codeBlock(f.context.start, f.context.lines, f.line);
  else if (f.code) h += codeBlock(f.line || 0, [f.code], f.line);
  else if (f.context && f.context.error) h += '<p class="muted">Code not available: ' + esc(f.context.error) + "</p>";
  if (f.source !== "ai") h += '<div class="explain"><div><b>Why it matters</b>' + esc(ri.why) + "</div><div><b>How to fix</b>" + esc(ri.fix) + "</div></div>";
  h += '<div class="muted" style="font-size:12px">First seen ' + esc(f.first_seen) + " &middot; last seen " + esc(f.last_seen) +
    (f.review_by ? " &middot; accepted until " + esc(f.review_by) : "") + "</div>";
  // decision
  h += "<h3>Decision</h3><div class=\"statusbtns\">" + Object.entries(st.statuses).map((s) =>
    '<button class="btn small' + (s[0] === f.status ? " cur" : "") + '" data-status="' + esc(s[0]) + '">' + esc(s[1]) + "</button>").join("") + "</div>";
  h += '<textarea id="remarkText" placeholder="Remark from the OT security engineer (what you checked, why, what happens next)"></textarea>' +
    '<div class="row gap" style="margin-top:6px"><button class="btn primary" id="addRemark">Add remark</button><span class="muted" style="font-size:12px">as ' + esc(me() || "(choose your name)") + "</span></div>";
  // AI
  h += '<div class="aibox"><h3>AI reviewer</h3>';
  if (f.ai) {
    const a = f.ai;
    h += '<div><span class="verdict ' + esc(a.verdict) + '">' + esc({ real: "Likely real", false_positive: "Likely false positive", unsure: "Unsure" }[a.verdict] || a.verdict || "") +
      "</span>" + (a.confidence != null ? " &middot; " + esc(a.confidence) + "% confident" : "") + (a.severity ? " &middot; suggests " + esc(a.severity) : "") +
      '<span class="muted" style="font-size:11px"> &middot; ' + esc(a.model || "") + " " + esc(a.at || "") + "</span></div>" +
      (a.plain_explanation ? "<p>" + esc(a.plain_explanation) + "</p>" : "") + (a.impact_here ? "<p><b>Impact here:</b> " + esc(a.impact_here) + "</p>" : "") +
      (a.how_to_fix ? "<p><b>How to fix:</b> " + esc(a.how_to_fix) + "</p>" : "") + (a.suggested_remark ? '<p class="muted">Suggested remark: ' + esc(a.suggested_remark) + "</p>" : "");
  } else if (!st.ai_enabled) {
    h += '<p class="muted">The AI reviewer is off. Switch it on in Settings once the local AI server is installed.</p>';
  }
  if (st.ai_enabled) {
    h += '<div class="row gap"><button class="btn" id="aiExplain">' + (f.ai ? "Ask again" : "Explain this finding") + "</button>" +
      (f.file && f.line && f.state === "open" ? '<button class="btn" id="aiFix">Propose a fix</button>' : "") + '<span class="muted" id="aiBusy"></span></div>';
  }
  h += "</div>";
  // fixes
  if (f.fixes.length) {
    h += "<h3>Fixes</h3>" + f.fixes.map(fixCard).join("");
  }
  // history
  h += "<h3>History</h3><div class=\"timeline\">" + (f.remarks.length ? f.remarks.slice().reverse().map((r) =>
    '<div class="tl ' + esc(r.kind) + '"><div class="h"><b>' + esc(r.author) + "</b>" + (r.role ? " (" + esc(r.role) + ")" : "") + " &middot; " + esc(r.created) +
    '</div><div class="b">' + esc(r.text) + "</div></div>").join("") : '<div class="muted">No remarks yet.</div>') + "</div>";
  setHTML($("findingDetail"), h);
  bindDetail(f);
}
function fixCard(fx) {
  const lbl = { proposed: "Waiting for approval", applied: "Applied", rejected: "Rejected", reverted: "Undone" }[fx.status] || fx.status;
  let h = '<div class="fixcard" data-fix="' + fx.id + '"><div class="row gap wrap"><b>Fix #' + fx.id + "</b><span class=\"status\">" + esc(lbl) + "</span>" +
    '<span class="muted" style="font-size:12px">' + esc(fx.file) + " lines " + esc(fx.start_line) + "-" + esc(fx.end_line) + " &middot; " + esc(fx.created) +
    (fx.decided_by ? " &middot; " + esc(fx.decided_by) : "") + "</span>" + (fx.platform ? '<span class="tag">' + esc(fx.platform) + "</span>" : "") + "</div>";
  if (fx.title) h += '<div style="margin-top:4px"><span class="sev ' + esc(fx.severity) + '">' + esc(fx.severity) + "</span> " + esc(fx.title) + "</div>";
  if (fx.explanation) h += '<p style="white-space:pre-wrap">' + esc(fx.explanation) + "</p>";
  h += diffBlock(fx.diff);
  if (fx.status === "proposed") {
    h += '<details><summary class="muted" style="cursor:pointer">Edit the new code before applying</summary><textarea class="fixedit" style="font-family:var(--mono);min-height:120px">' +
      esc(fx.proposed) + "</textarea></details>" +
      '<div class="row gap" style="margin-top:6px"><button class="btn primary" data-fixact="apply">Approve and apply</button>' +
      '<button class="btn" data-fixact="reject">Reject</button></div>';
  } else if (fx.status === "applied") {
    h += '<div class="row gap"><button class="btn danger" data-fixact="undo">Undo (restore backup)</button><span class="muted" style="font-size:11px">' + esc(fx.backup_path || "") + "</span></div>";
  }
  return h + "</div>";
}
async function fixAction(card, act) {
  if (!needMe()) return;
  const id = card.dataset.fix, body = { by: me() };
  if (act === "apply" || act === "undo") {
    const pin = await askPin(act === "apply" ? "Approve and write this change into the platform file (a backup is kept)." : "Restore the original file from backup.");
    if (pin === null) return; body.pin = pin;
    const ed = card.querySelector(".fixedit"); if (ed && act === "apply") body.proposed = ed.value;
  }
  if (act === "reject") {
    const v = await modal("Reject fix", '<textarea name="reason" placeholder="Why? (optional)"></textarea>', "Reject");
    if (!v) return; body.reason = v.reason;
  }
  const r = await run(() => api("/api/fixes/" + id + "/" + act, { json: body }),
    { apply: "Fix applied. Backup kept; re-scanning the platform.", undo: "Original restored; re-scanning.", reject: "Fix rejected." }[act]);
  if (r) { if (S.selected) openFinding(S.selected, true); if (S.tab === "fixes") loadFixes(); refreshState(); }
}
function bindDetail(f) {
  const d = $("findingDetail");
  d.querySelectorAll("[data-status]").forEach((b) => b.onclick = () => setStatus([f.id], b.dataset.status, $("remarkText").value));
  $("addRemark").onclick = async () => {
    if (!needMe()) return;
    const text = $("remarkText").value.trim(); if (!text) return toast("Write the remark first.", true);
    const r = await run(() => api("/api/findings/" + f.id + "/remark", { json: { by: me(), text, mark_under_review: true } }), "Remark saved.");
    if (r) { openFinding(f.id, true); loadFindings(); }
  };
  if ($("aiExplain")) $("aiExplain").onclick = async () => {
    $("aiBusy").textContent = "The local AI is thinking... (can take a minute)"; $("aiExplain").disabled = true;
    await run(() => api("/api/ai/explain/" + f.id, { json: {} }), "AI explanation saved as a remark.");
    openFinding(f.id, true); loadFindings();
  };
  if ($("aiFix")) $("aiFix").onclick = async () => {
    if (!needMe()) return;
    $("aiBusy").textContent = "The local AI is writing a fix..."; $("aiFix").disabled = true;
    await run(() => api("/api/ai/fix/" + f.id, { json: { by: me() } }), "Fix proposed. Check the before/after and approve or reject it.");
    openFinding(f.id, true); refreshState();
  };
  d.querySelectorAll("[data-fixact]").forEach((b) => b.onclick = () => fixAction(b.closest(".fixcard"), b.dataset.fixact));
}
async function setStatus(ids, status, remark) {
  if (!needMe()) return;
  const body = { by: me(), status, remark: (remark || "").trim() };
  if ((status === "false_positive" || status === "accepted_risk") && !body.remark) {
    const v = await modal(S.state.statuses[status], '<label>Reason (required)</label><textarea name="remark"></textarea>' +
      (status === "accepted_risk" ? '<label>Review again by (optional)</label><input type="date" name="review_by">' : ""), "Save");
    if (!v) return; body.remark = v.remark; body.review_by = v.review_by;
  } else if (status === "accepted_risk") {
    const v = await modal("Accepted risk", '<label>Review again by (optional)</label><input type="date" name="review_by">', "Save");
    if (!v) return; body.review_by = v.review_by;
  }
  if (status === "false_positive" || status === "accepted_risk") {
    const pin = await askPin("Marking findings as '" + S.state.statuses[status] + "' removes them from the score.");
    if (pin === null) return; body.pin = pin;
  }
  let r;
  if (ids.length === 1) r = await run(() => api("/api/findings/" + ids[0] + "/status", { json: body }), "Saved.");
  else r = await run(() => api("/api/findings/bulk_status", { json: Object.assign(body, { ids }) }), "Updated " + ids.length + " findings.");
  if (r) { S.checked.clear(); await loadFindings(); if (S.selected) openFinding(S.selected, true); refreshState(); }
}

/* ---------------------------------------------------------------- platforms + folder browser */
function renderPlatforms() {
  const st = S.state; if (!st) return;
  setHTML($("platformList"), st.platforms.length ? st.platforms.map((p) =>
    '<div class="plat" data-pid="' + p.id + '"><div class="grid"><div><label>Name</label><input data-f="name" value="' + esc(p.name) + '"></div>' +
    '<div><label>Folder</label><input data-f="path" value="' + esc(p.path) + '"></div>' +
    '<div><label>Extra folders to skip</label><input data-f="excludes" value="' + esc(p.excludes || "") + '" placeholder="e.g. clips, exports"></div>' +
    '<div><label>&nbsp;</label><label class="check"><input type="checkbox" data-f="enabled"' + (p.enabled ? " checked" : "") + '> Included in "Scan all" and the nightly scan</label></div></div>' +
    '<div class="muted" style="font-size:12px;margin:6px 0">' + (p.exists ? "" : '<span class="st-bad">Folder not found. </span>') +
    "Baseline: " + esc(p.baseline_at ? p.baseline_at + " by " + p.baseline_by : "not set (the first scan sets it)") + "</div>" +
    '<div class="row gap wrap"><button class="btn small primary" data-act="save">Save</button><button class="btn small" data-act="scan">Scan now</button>' +
    '<button class="btn small" data-act="baseline">Approve current files as baseline</button>' +
    '<a class="btn small" href="/api/sbom/' + p.id + '">Download SBOM</a><button class="btn small danger" data-act="remove">Remove</button></div></div>').join("")
    : '<p class="muted">None yet. Use the folder browser on the right.</p>');
  if (!S.browsePath && !$("browser").dataset.loaded) browse(store("cg_browse") || "");
}
async function platformAction(card, act) {
  const id = card.dataset.pid;
  if (act === "scan") { await run(() => api("/api/scan", { json: { platform_id: Number(id) } }), "Scan queued."); return refreshState(); }
  if (act === "save") {
    const v = {}; card.querySelectorAll("[data-f]").forEach((el) => { v[el.dataset.f] = el.type === "checkbox" ? el.checked : el.value; });
    if (await run(() => api("/api/platforms/" + id, { method: "PUT", json: v }), "Saved.")) { await refreshState(); renderPlatforms(); }
    return;
  }
  if (act === "baseline") {
    if (!needMe()) return;
    const pin = await askPin("Accept every file as it is now. Changes after this will be reported as tampering until approved again.");
    if (pin === null) return;
    const r = await run(() => api("/api/platforms/" + id + "/baseline", { json: { by: me(), pin } }));
    if (r) { toast("Baseline approved (" + r.files + " files)."); refreshState(); }
    return;
  }
  if (act === "remove") {
    const ok = await modal("Remove platform", '<p>Remove this platform and all its findings and remarks from CodeGuard? The platform files are not touched.</p>', "Remove");
    if (!ok) return;
    const pin = await askPin("Removing a platform deletes its history in CodeGuard."); if (pin === null) return;
    if (await run(() => api("/api/platforms/" + id, { method: "DELETE", json: { pin } }), "Removed.")) { await refreshState(); renderPlatforms(); }
  }
}
async function browse(path) {
  const r = await run(() => api("/api/browse?path=" + encodeURIComponent(path || "")));
  if (!r) return;
  S.browsePath = r.path; $("browsePath").value = r.path; $("browser").dataset.loaded = "1";
  if (r.path) store("cg_browse", r.path);
  const parts = r.path ? r.path.split(/[\\/]/).filter(Boolean) : [];
  const sep = r.path.includes("\\") ? "\\" : "/";
  let acc = "";
  const crumbs = ['<a data-path="">Computer</a>'];
  parts.forEach((p, i) => {
    acc = i === 0 ? (r.path.startsWith("/") ? "/" + p : p + sep) : acc + (acc.endsWith(sep) ? "" : sep) + p;
    crumbs.push(" &rsaquo; " + '<a data-path="' + esc(acc) + '">' + esc(p) + "</a>");
  });
  setHTML($("browseCrumbs"), crumbs.join(""));
  setHTML($("browser"), (r.parent !== null && r.parent !== undefined ? '<div data-path="' + esc(r.parent) + '"><span class="ic">..</span> up one level</div>' : "") +
    r.dirs.map((d) => '<div data-path="' + esc(d.path) + '"><span class="ic">[ ]</span>' + esc(d.name) + (d.platform ? '<span class="pf">looks like a platform</span>' : "") + "</div>").join("") +
    (r.dirs.length ? "" : '<div class="muted">No sub-folders.</div>'));
  setHTML($("discovered"), "");
}
async function discover() {
  const r = await run(() => api("/api/discover", { json: { parent: $("browsePath").value } }));
  if (!r) return;
  if (!r.found.length) { setHTML($("discovered"), '<p class="muted">No platform folders found here.</p>'); return; }
  setHTML($("discovered"), '<div class="disc"><h3>Found ' + r.found.length + " folder(s)</h3>" + r.found.map((f, i) =>
    "<div><input type=\"checkbox\" data-i=\"" + i + '"' + (f.added ? " disabled" : " checked") + '><input class="nm" data-n="' + i + '" value="' + esc(f.name) + '"' +
    (f.added ? " disabled" : "") + '><span class="muted" style="font-family:var(--mono);font-size:11px">' + esc(f.path) + (f.added ? " (already connected)" : "") + "</span></div>").join("") +
    '<div style="border:0;padding-top:8px"><button class="btn primary" id="addFound">Add selected</button></div></div>');
  $("addFound").onclick = async () => {
    const items = [];
    r.found.forEach((f, i) => {
      const cb = document.querySelector('[data-i="' + i + '"]');
      if (cb && cb.checked && !f.added) items.push({ path: f.path, name: document.querySelector('[data-n="' + i + '"]').value });
    });
    if (!items.length) return toast("Nothing selected.", true);
    const res = await run(() => api("/api/platforms", { json: { items, scan: $("scanAfterAdd").checked } }));
    if (res) { toast("Added " + res.ids.length + " platform(s)." + (res.errors.length ? " " + res.errors.join("; ") : "")); await refreshState(); renderPlatforms(); discover(); }
  };
}

/* ---------------------------------------------------------------- AI tab */
async function renderAI() {
  const st = S.state; if (!st) return;
  setHTML($("aiStatus"), st.ai_enabled
    ? '<p><span class="st-ok">On</span> &middot; model <code>' + esc(st.ai_model) + '</code></p><p class="muted">' + esc(st.ai_progress.running ? "Working: " + st.ai_progress.step : "Waiting for work.") +
      (st.ai_progress.last_error ? '<br><span class="st-bad">Last problem: ' + esc(st.ai_progress.last_error) + "</span>" : "") + "</p>"
    : '<p><span class="st-bad">Off.</span> Install the local AI server (see README, Phase 2), then switch it on in Settings &rsaquo; AI reviewer.</p>');
  const opts = st.platforms.map((p) => '<option value="' + p.id + '">' + esc(p.name) + "</option>").join("");
  ["aiPlatform", "aiTriagePlatform"].forEach((id) => { const el = $(id), v = el.value; setHTML(el, opts); if (v) el.value = v; });
  loadAIFiles();
}
async function loadAIFiles() {
  const pid = $("aiPlatform").value; if (!pid) { setHTML($("aiFiles"), ""); return; }
  const files = await run(() => api("/api/files?platform_id=" + pid)); if (!files) return;
  const flt = $("aiFileFilter").value.toLowerCase();
  setHTML($("aiFiles"), files.filter((f) => !flt || f.file.toLowerCase().includes(flt)).map((f) =>
    '<div><span>' + esc(f.file) + '</span><span class="muted" style="flex:0 0 auto">' + esc(f.findings) + ' open</span><button class="btn small" data-review="' +
    esc(f.file) + '"' + (S.state.ai_enabled ? "" : " disabled") + ">Review with AI</button></div>").join("") || '<div class="muted">Scan the platform first.</div>');
}

/* ---------------------------------------------------------------- fixes tab */
async function loadFixes() {
  const rows = await run(() => api("/api/fixes?status=" + encodeURIComponent($("fixFilter").value)));
  if (!rows) return;
  setHTML($("fixList"), rows.length ? rows.map(fixCard).join("") : '<p class="muted">No fixes here. Ask the AI to propose one from a finding.</p>');
  $("fixList").querySelectorAll("[data-fixact]").forEach((b) => b.onclick = () => fixAction(b.closest(".fixcard"), b.dataset.fixact));
}

/* ---------------------------------------------------------------- libraries */
async function loadLibraries() {
  const sel = $("libPlatform"), v = sel.value;
  setHTML(sel, '<option value="">All platforms</option>' + S.state.platforms.map((p) => '<option value="' + p.id + '">' + esc(p.name) + "</option>").join(""));
  sel.value = v;
  const vdb = S.state.vulndb;
  $("vdbInfo").textContent = vdb.loaded ? "Vulnerability database: " + vdb.count + " advisories, built " + vdb.built_at : "Vulnerability database not installed";
  const rows = await run(() => api("/api/components" + (sel.value ? "?platform_id=" + sel.value : ""))); if (!rows) return;
  setHTML($("libTable"), '<table class="t"><tr><th>Platform</th><th>Package</th><th>Version in use</th><th>Declared</th><th>Where</th><th>Known vulnerabilities</th></tr>' +
    rows.map((c) => "<tr><td>" + esc(c.platform) + "</td><td><b>" + esc(c.name) + "</b></td><td>" + esc(c.version || "unknown") + "</td><td>" + esc(c.declared) +
      '</td><td style="font-family:var(--mono);font-size:11px">' + esc(c.where) + "</td><td>" + ((c.vulns || []).length ? '<span class="st-bad">' + esc(c.vulns.join(", ")) + "</span>" : '<span class="muted">none known</span>') + "</td></tr>").join("") +
    "</table>" + (rows.length ? "" : '<p class="muted">Scan a platform to list its libraries.</p>'));
}

/* ---------------------------------------------------------------- scans */
async function loadScans() {
  const rows = await run(() => api("/api/scans")); if (!rows) return;
  setHTML($("scanList"), '<table class="t"><tr><th>#</th><th>Platform</th><th>Started</th><th>Result</th><th>Grade</th><th>New / gone</th><th>Changed files</th><th>Notes</th></tr>' +
    rows.map((s) => "<tr><td>" + s.id + "</td><td>" + esc(s.platform) + "<br><span class=\"muted\" style=\"font-size:11px\">" + esc(s.trigger) + "</span></td><td>" + esc(s.started) +
      "</td><td>" + (s.status === "error" ? '<span class="st-bad">Error: ' + esc(s.error) + "</span>" : esc(s.status) + (s.files ? "<br>" + esc(s.files) + " files, " + esc(s.lines) + " lines" : "")) +
      "</td><td><b>" + esc(s.grade || "-") + "</b> " + esc(s.score == null ? "" : s.score) + "</td><td>" +
      (s.status === "done" ? '<a href="#" data-newscan="' + s.id + '" data-pid="' + s.platform_id + '">' + esc(s.new_findings) + " new</a> / " + esc(s.resolved) + " gone" : "") +
      '</td><td style="font-family:var(--mono);font-size:11px">' + s.changed_files.slice(0, 8).map(esc).join("<br>") + (s.changed_files.length > 8 ? "<br>... " + (s.changed_files.length - 8) + " more" : "") +
      '</td><td class="muted" style="font-size:12px">' + s.notes.map(esc).join("<br>") + "</td></tr>").join("") + "</table>");
}

/* ---------------------------------------------------------------- reports */
function renderReports() {
  const plats = S.state.platforms.filter((p) => p.enabled);
  setHTML($("reportButtons"), '<a class="btn primary" href="/report" target="_blank" rel="noopener noreferrer">All platforms</a>' +
    plats.map((p) => '<a class="btn" href="/report?platform_id=' + p.id + '" target="_blank" rel="noopener noreferrer">' + esc(p.name) + "</a>").join(""));
  setHTML($("exportButtons"), '<a class="btn" href="/api/export.csv">All findings (CSV for Excel)</a>' +
    plats.map((p) => '<a class="btn" href="/api/sbom/' + p.id + '">SBOM: ' + esc(p.name) + "</a>").join(""));
}

/* ---------------------------------------------------------------- settings */
async function loadSettings() {
  const s = await run(() => api("/api/settings")); if (!s) return;
  S.settings = s;
  if (!$("saveMsg").classList.contains("ok")) saveMsg("", "");
  renderPeople();
  $("nightlyOn").checked = !!s.nightly_enabled; $("nightlyAt").value = s.nightly_scan || "02:30";
  $("defExcl").value = s.default_excludes || ""; $("maxMb").value = s.max_file_mb || 3; $("hostSel").value = s.host || "127.0.0.1";
  $("aiOn").checked = !!s.ai.enabled; $("aiUrl").value = s.ai.base_url || ""; $("aiModel").value = s.ai.model || "";
  $("aiTimeout").value = s.ai.timeout || 240; $("aiLines").value = s.ai.max_context_lines || 60; $("aiAuto").checked = !!s.ai.auto_triage_after_scan;
  $("extOn").checked = s.external_tools_enabled !== false; $("semgrepRules").value = s.semgrep_rules || "";
  $("gitleaksPath").value = s.gitleaks_path || ""; $("clamPath").value = s.clamscan_path || "";
  const v = S.state.vulndb;
  setHTML($("vdbStatus"), v.loaded ? '<span class="st-ok">Installed</span>: ' + esc(v.count) + " advisories for " + esc(v.packages) + " packages, built " + esc(v.built_at) + " (" + esc(v.source) + ")"
    : '<span class="st-bad">Not installed.</span> Run tools\\prepare_usb_bundle.bat on an internet PC, then import the file here.');
  const t = S.state.tools;
  setHTML($("toolStatus"), Object.entries(t).map((x) => esc(x[0]) + ": " + (x[1] ? '<span class="st-ok">found</span>' : "not installed")).join(" &middot; "));
}
function renderPeople() {
  setHTML($("people"), (S.settings.people || []).map((p, i) =>
    '<div class="row gap" style="margin-bottom:6px"><input data-pn="' + i + '" value="' + esc(p.name) + '" placeholder="Name"><input data-pr="' + i + '" value="' + esc(p.role) +
    '" placeholder="Role"><button class="btn small danger" data-del="' + i + '">x</button></div>').join(""));
}
function readPeople() {
  return (S.settings.people || []).map((p, i) => ({ name: document.querySelector('[data-pn="' + i + '"]').value, role: document.querySelector('[data-pr="' + i + '"]').value }));
}
async function saveSettings() {
  const pin = await askPin("Changing settings needs the approval PIN."); if (pin === null) return;
  const settings = {
    people: readPeople(), nightly_enabled: $("nightlyOn").checked, nightly_scan: $("nightlyAt").value, default_excludes: $("defExcl").value,
    max_file_mb: Number($("maxMb").value) || 3, host: $("hostSel").value, external_tools_enabled: $("extOn").checked, semgrep_rules: $("semgrepRules").value,
    gitleaks_path: $("gitleaksPath").value, clamscan_path: $("clamPath").value,
    ai: { enabled: $("aiOn").checked, base_url: $("aiUrl").value.trim(), model: $("aiModel").value.trim(), timeout: Number($("aiTimeout").value) || 240,
          max_context_lines: Number($("aiLines").value) || 60, auto_triage_after_scan: $("aiAuto").checked }
  };
  if (await run(() => api("/api/settings", { json: { settings, pin } }), "Settings saved.")) {
    saveMsg("Saved.", "ok"); await refreshState(); loadSettings();
  } else {
    saveMsg("Not saved - see the message.", "err");
  }
}
function saveMsg(text, kind) { $("saveMsg").textContent = text; $("saveMsg").className = "save-msg " + (kind || ""); }

/* ---------------------------------------------------------------- wiring */
function wire() {
  $("tabs").onclick = (e) => { const b = e.target.closest("button[data-tab]"); if (b) showTab(b.dataset.tab); };
  $("person").onchange = () => { store("cg_person", me()); if (S.selected) openFinding(S.selected, true); };
  $("scanAll").onclick = async () => { const r = await run(() => api("/api/scan", { json: { all: true } })); if (r) { toast(r.queued + " platform(s) queued for scanning."); refreshState(); } };
  $("platformCards").onclick = async (e) => {
    const s = e.target.closest("[data-scan]"), v = e.target.closest("[data-view]");
    if (s) { await run(() => api("/api/scan", { json: { platform_id: Number(s.dataset.scan) } }), "Scan queued."); refreshState(); }
    if (v) { $("fPlatform").value = v.dataset.view; showTab("findings"); $("fPlatform").value = v.dataset.view; loadFindings(); }
  };
  ["fPlatform", "fSeverity", "fLayer", "fStatus", "fState"].forEach((id) => $(id).onchange = loadFindings);
  let tm; $("fSearch").oninput = () => { clearTimeout(tm); tm = setTimeout(loadFindings, 300); };
  $("findingList").onclick = (e) => {
    const cb = e.target.closest("[data-check]");
    if (cb) { const id = Number(cb.dataset.check); if (cb.checked) S.checked.add(id); else S.checked.delete(id); updateBulk(); return; }
    const row = e.target.closest(".frow"); if (row) openFinding(Number(row.dataset.id));
  };
  $("bulkApply").onclick = () => setStatus(Array.from(S.checked), $("bulkStatus").value, $("bulkRemark").value);
  $("platformList").onclick = (e) => { const b = e.target.closest("[data-act]"); if (b) platformAction(b.closest(".plat"), b.dataset.act); };
  $("browser").onclick = (e) => { const d = e.target.closest("[data-path]"); if (d) browse(d.dataset.path); };
  $("browseCrumbs").onclick = (e) => { const a = e.target.closest("[data-path]"); if (a) browse(a.dataset.path); };
  $("browseGo").onclick = () => browse($("browsePath").value.trim());
  $("browsePath").onkeydown = (e) => { if (e.key === "Enter") browse($("browsePath").value.trim()); };
  $("addThis").onclick = async () => {
    const path = $("browsePath").value.trim(); if (!path) return toast("Open a folder first.", true);
    const r = await run(() => api("/api/platforms", { json: { path, scan: $("scanAfterAdd").checked } }), "Platform added.");
    if (r) { await refreshState(); renderPlatforms(); }
  };
  $("discover").onclick = discover;
  $("aiPlatform").onchange = loadAIFiles; $("aiFileFilter").oninput = loadAIFiles;
  $("aiFiles").onclick = async (e) => {
    const b = e.target.closest("[data-review]"); if (!b) return;
    await run(() => api("/api/ai/review_file", { json: { platform_id: Number($("aiPlatform").value), file: b.dataset.review } }), "AI review started. Results appear in Findings (layer: AI reviewer).");
    refreshState();
  };
  $("aiTriage").onclick = async () => { await run(() => api("/api/ai/triage", { json: { platform_id: Number($("aiTriagePlatform").value) } }), "AI triage started."); refreshState(); };
  $("fixFilter").onchange = loadFixes;
  $("libPlatform").onchange = loadLibraries;
  $("scanList").onclick = (e) => {
    const a = e.target.closest("[data-newscan]"); if (!a) return; e.preventDefault();
    showTab("findings"); $("fPlatform").value = a.dataset.pid; $("fStatus").value = ""; $("fState").value = "all"; loadFindings();
  };
  $("addPerson").onclick = () => { S.settings.people = readPeople().concat([{ name: "", role: "OT Security Engineer" }]); renderPeople(); };
  $("people").onclick = (e) => { const b = e.target.closest("[data-del]"); if (b) { const p = readPeople(); p.splice(Number(b.dataset.del), 1); S.settings.people = p; renderPeople(); } };
  $("pinSave").onclick = async () => {
    const r = await run(() => api("/api/settings/pin", { json: { old_pin: $("pinOld").value, new_pin: $("pinNew").value } }));
    if (r) { toast(r.pin_set ? "PIN saved." : "PIN removed."); $("pinOld").value = $("pinNew").value = ""; refreshState(); }
  };
  $("saveSettings").onclick = saveSettings;
  const dirty = (e) => { if (!e.target.closest("#pinOld,#pinNew,#vdbPath")) saveMsg("Unsaved changes", "warn"); };
  $("tab-settings").addEventListener("input", dirty); $("tab-settings").addEventListener("change", dirty);
  $("logoAdd").onclick = explainLogo;
  $("aiTest").onclick = async () => {
    $("aiTestOut").textContent = "Testing... (save settings first if you changed them)";
    const r = await run(() => api("/api/ai/test", { json: {} }));
    $("aiTestOut").textContent = r ? (r.ok ? "Connected in " + r.seconds + " s." + (r.models.length ? " Models: " + r.models.join(", ") : "") : "Answered, but not as expected.") : "Failed.";
  };
  $("vdbImport").onclick = async () => {
    const r = await run(() => api("/api/vulndb/import", { json: { path: $("vdbPath").value } }));
    if (r) { toast("Imported " + r.count + " advisories."); await refreshState(); loadSettings(); }
  };
  $("selftest").onclick = async () => {
    setHTML($("selftestOut"), '<p class="muted">Running...</p>');
    const r = await run(() => api("/api/selftest", { json: {} }));
    if (!r) { setHTML($("selftestOut"), ""); return; }
    setHTML($("selftestOut"), "<p>" + (r.ok ? '<span class="st-ok">PASSED</span> - every rule fired.' : '<span class="st-bad">Some rules did not fire.</span>') + "</p>" +
      '<div style="columns:2;font-size:12px">' + r.results.map((x) => '<div><span class="' + (x.ok ? "st-ok" : "st-bad") + '">' + (x.ok ? "OK " : "MISS") + "</span> " + esc(x.rule) + " " + esc(x.title) + "</div>").join("") + "</div>");
    refreshState();
  };
  document.addEventListener("keydown", (e) => { if (e.key === "Escape" && !$("modal").hidden) $("modalCancel").click(); });
}

(async function start() {
  wire();
  loadLogo(0);
  await refreshState();
  showTab(store("cg_tab") || "dashboard");
  setInterval(refreshState, 3000);
})();
