The vulnerability database is created here when you import PyPI_all.zip (Settings > Vulnerability database).
