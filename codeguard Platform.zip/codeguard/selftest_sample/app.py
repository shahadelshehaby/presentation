"""SELF-TEST SAMPLE - deliberately unsafe code. CodeGuard must find every problem here.
Never run this file; it only exists to prove the scanner works."""
import os
import subprocess
import pickle
import sqlite3
import hashlib
import json
import yaml
import requests
from flask import Flask, request, send_file

app = Flask(__name__)
app.secret_key = "s3cr3t-key-in-code"
NVR_URL = "rtsp://admin:Hanwha2024!@192.168.1.53:558/PlaybackChannel/0/media.smp"
DB_PASSWORD = "Pl@ntP4ss99"


@app.route("/clip")
def clip():
    start = request.args.get("start")
    cmd = "ffmpeg -ss " + start + " -i input.mp4 out.mp4"
    subprocess.run(cmd, shell=True)
    return "ok"


@app.route("/convert")
def convert():
    name = request.args.get("name")
    subprocess.run(["ffmpeg", "-i", name, "out.mp4"])
    os.system("echo done")
    return "ok"


@app.route("/download/<fname>")
def download(fname):
    return send_file(os.path.join("clips", fname))


@app.route("/search")
def search():
    term = request.args.get("q")
    con = sqlite3.connect("x.db")
    rows = con.execute(f"SELECT * FROM machines WHERE name = '{term}'").fetchall()
    return json.dumps(rows)


@app.route("/search")
def search_again():
    return "never runs"


@app.route("/upload", methods=["POST"])
def upload():
    f = request.files["file"]
    f.save(os.path.join("uploads", f.filename))
    return "ok"


def load_state():
    with open("state.pkl", "rb") as fh:
        return pickle.load(fh)


def load_cfg():
    return yaml.load(open("cfg.yaml"))


def calc(expr):
    return eval(expr)


def fetch():
    return requests.get("https://192.168.1.10/api", verify=False)


def checksum(data):
    return hashlib.md5(data).hexdigest()


def add_item(item, bucket=[]):
    bucket.append(item)
    return bucket


def risky():
    try:
        return 1 / 0
    except Exception:
        pass


def compare(x):
    return x is "OK"


def dead():
    return 1
    print("never")


def broken():
    return undefined_helper()


def load_state():
    return None


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5999, debug=True)
