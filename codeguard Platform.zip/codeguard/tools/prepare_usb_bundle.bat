@echo off
rem ============================================================================
rem  CodeGuard - prepare the USB bundle.  RUN THIS ON A PC WITH INTERNET ACCESS.
rem  It creates the folder  usb_bundle  next to this tools folder. Copy that folder
rem  to a USB stick, then run tools\install_from_usb.bat on the offline OT PC.
rem
rem  Set PYVER to the Python version of the OT PC (run  python --version  there).
rem ============================================================================
setlocal
set PYVER=3.11
cd /d "%~dp0.."
set B=usb_bundle
if not exist %B%\wheels mkdir %B%\wheels
if not exist %B%\vulndb mkdir %B%\vulndb
set PY=python
where python >nul 2>nul || set PY=py

echo [1/3] Downloading Flask for Python %PYVER% (Windows 64-bit)...
%PY% -m pip download flask --only-binary=:all: --platform win_amd64 --python-version %PYVER% -d %B%\wheels & rem codeguard: ignore - runs on the internet PC only
echo       Optional extra scanner Bandit...
%PY% -m pip download bandit --only-binary=:all: --platform win_amd64 --python-version %PYVER% -d %B%\wheels & rem codeguard: ignore - runs on the internet PC only

echo [2/3] Downloading the OSV vulnerability database for Python packages...
curl.exe -L --fail -o %B%\vulndb\PyPI_all.zip https://osv-vulnerabilities.storage.googleapis.com/PyPI/all.zip & rem codeguard: ignore - runs on the internet PC only
if errorlevel 1 echo       Download failed. Open the address above in a browser and save it as %B%\vulndb\PyPI_all.zip

echo [3/3] Writing checksums (the OT PC checks them before installing)...
if exist %B%\checksums.txt del %B%\checksums.txt
for /r %B% %%F in (*.whl *.zip) do certutil -hashfile "%%F" SHA256 | findstr /v /c:"hash of" /c:"CertUtil" > "%%F.sha256"

echo.
echo Done. Copy the folder  %CD%\%B%  to the USB stick.
echo Optional tools (see README): gitleaks.exe, ClamAV with its signature files.
pause
