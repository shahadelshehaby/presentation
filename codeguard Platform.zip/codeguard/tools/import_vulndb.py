"""Import the OSV PyPI vulnerability database (PyPI_all.zip from the USB bundle) into CodeGuard.

    python tools\\import_vulndb.py E:\\usb_bundle\\vulndb\\PyPI_all.zip

The same import is available in the web page: Settings > Vulnerability database.
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import deps  # noqa: E402

if len(sys.argv) != 2 or not os.path.isfile(sys.argv[1]):
    print(__doc__)
    sys.exit(1)
meta = deps.build_db_from_osv_zip(sys.argv[1])
print("Imported %(count)s advisories (%(skipped)s damaged files skipped), built %(built_at)s." % meta)
