@echo off
rem CodeGuard - install from the USB bundle on the OFFLINE PC. No internet is used.
rem Copy the usb_bundle folder from the stick into the CodeGuard folder first
rem (or pass its path:  install_from_usb.bat E:\usb_bundle).
cd /d "%~dp0.."
set PY=python
where python >nul 2>nul || set PY=py
set BUNDLE=%~1
if "%BUNDLE%"=="" set BUNDLE=usb_bundle
%PY% tools\verify_and_install.py "%BUNDLE%"
pause
