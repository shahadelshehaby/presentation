"""Run by install_from_usb.bat on the offline PC:
1. checks every file in the bundle against the SHA-256 written on the internet PC,
2. installs Flask (and Bandit if present) from the bundle without internet,
3. imports the vulnerability database.
Usage: python tools\\verify_and_install.py <bundle folder>
"""
import glob
import hashlib
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, HERE)


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def main(bundle):
    bad, checked = [], 0
    for f in glob.glob(os.path.join(bundle, "**", "*.whl"), recursive=True) + \
            glob.glob(os.path.join(bundle, "**", "*.zip"), recursive=True):
        sig = f + ".sha256"
        if not os.path.isfile(sig):
            bad.append("%s (no checksum file)" % os.path.basename(f))
            continue
        with open(sig, encoding="utf-8", errors="replace") as fh:
            expected = "".join(fh.read().split()).lower()
        if sha256(f) != expected:
            bad.append("%s (checksum does not match)" % os.path.basename(f))
        checked += 1
    if bad:
        print("STOP - these files failed the integrity check and were NOT installed:")
        for b in bad:
            print("   ", b)
        print("Prepare the bundle again on the internet PC.")
        return 1
    print("Integrity check passed for %d files." % checked)
    wheels = os.path.join(bundle, "wheels")
    if os.path.isdir(wheels):
        pkgs = ["flask"] + (["bandit"] if glob.glob(os.path.join(wheels, "bandit-*.whl")) else [])
        r = subprocess.run([sys.executable, "-m", "pip", "install", "--no-index", "--find-links", wheels] + pkgs)
        if r.returncode:
            print("pip could not install from the bundle (is it for this Python version: %s?)" % sys.version.split()[0])
            return 1
    zips = glob.glob(os.path.join(bundle, "vulndb", "*.zip"))
    if zips:
        import deps
        meta = deps.build_db_from_osv_zip(zips[0])
        print("Vulnerability database imported: %s advisories." % meta["count"])
    print("Done. Start CodeGuard with run.bat.")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, "usb_bundle")))
