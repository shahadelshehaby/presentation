"""
building_status.py - read-only status page for the "Engineering Building" dashboard.

    GET /building/status   ->  small JSON, answered from a 5-second cache.

It can never slow down or break the platform: the answer is cached, every error is caught
(a failure is reported INSIDE the JSON, the page itself always answers), and it only reads.

Edit TEAM below to change the roles or the minutes a person would need by hand.
An "item" is one camera inspection.
"""
import threading
import time
from datetime import datetime, timedelta, timezone

PLATFORM_NAME = "Camera Health Platform"
CACHE_SECONDS = 5
ERROR_VISIBLE_MINUTES = 60        # a failure keeps the status at "error" for this long

# Who would do this work by hand, step by step, for ONE camera.
# manual_minutes_per_item are estimates - set them to what is true at your site.
TEAM = [
    {"role": "Camera Operator",
     "description": "Logs in to each camera or recorder, opens the live view and takes a screenshot.",
     "automated": True, "manual_minutes_per_item": 3.0},
    {"role": "Image Reviewer",
     "description": "Looks at each screenshot for no view, too dark, overexposed, colour tint, dirty or blurry lens.",
     "automated": True, "manual_minutes_per_item": 2.0},
    {"role": "Report Clerk",
     "description": "Writes every result, with the photo, into the daily camera health report.",
     "automated": True, "manual_minutes_per_item": 1.5},
    {"role": "Verification Engineer",
     "description": "Checks flagged cameras on site or live, confirms the diagnosis and arranges cleaning or repair.",
     "automated": False, "manual_minutes_per_item": 5.0},
]

_lock = threading.Lock()
_cache = {"at": 0.0, "data": None}


def _utc_iso(dt):
    return dt.astimezone(timezone.utc).replace(tzinfo=None).isoformat()


def _counters():
    import db                                           # imported here so a problem never stops start-up
    local_midnight = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
    since_today = _utc_iso(local_midnight)
    since_hour = _utc_iso(datetime.now() - timedelta(hours=1))
    conn = db.get_conn()
    try:
        row = conn.execute(
            "SELECT COUNT(*) AS n, COALESCE(SUM(CASE WHEN COALESCE(final_status, status) != 'OK' "
            "THEN 1 ELSE 0 END), 0) AS issues "
            "FROM inspections WHERE timestamp >= ?", (since_today,)).fetchone()
        last_hour = conn.execute("SELECT COUNT(*) FROM inspections WHERE timestamp >= ?",
                                 (since_hour,)).fetchone()[0]
    finally:
        conn.close()
    return {"items_today": int(row["n"]), "items_last_hour": int(last_hour), "issues_today": int(row["issues"])}


def _build():
    import capture
    prog = capture.progress()
    err = capture.last_error()
    working = bool(prog.get("running"))
    recent_error = bool(err and (datetime.now() - err["at"]) < timedelta(minutes=ERROR_VISIBLE_MINUTES))

    if working:
        status = "working"
    elif recent_error:
        status = "error"
    else:
        status = "idle"

    job = None
    if working:
        step = "Capturing and diagnosing cameras"
        if prog.get("current"):
            step += f" - {prog['current']}"
        job = {"step": step, "items_done": int(prog.get("done", 0)), "items_total": int(prog.get("total", 0))}

    return {
        "platform": PLATFORM_NAME,
        "status": status,
        "current_job": job,
        "counters": _counters(),
        "last_error": err["message"] if recent_error else None,
        "team": TEAM,
    }


def _fallback(message):
    return {"platform": PLATFORM_NAME, "status": "error", "current_job": None,
            "counters": {"items_today": 0, "items_last_hour": 0, "issues_today": 0},
            "last_error": message, "team": TEAM}


def get_status():
    """Cached for CACHE_SECONDS; never raises."""
    now = time.monotonic()
    with _lock:
        if _cache["data"] is not None and now - _cache["at"] < CACHE_SECONDS:
            return _cache["data"]
    try:
        data = _build()
    except Exception as e:                              # report it inside the JSON, never break the platform
        data = _fallback(f"status page error: {e}")
    with _lock:
        _cache.update(at=now, data=data)
    return data


def register(app):
    """Call once from app.py:  building_status.register(app)"""
    from flask import jsonify

    @app.route("/building/status")
    def building_status():
        try:
            resp = jsonify(get_status())
        except Exception as e:
            resp = jsonify(_fallback(f"status page error: {e}"))
        resp.headers["Access-Control-Allow-Origin"] = "*"      # lets the building page read it from the browser
        resp.headers["Cache-Control"] = "no-store"
        return resp
