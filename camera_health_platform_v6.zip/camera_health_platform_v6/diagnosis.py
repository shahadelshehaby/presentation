"""
Diagnosis engine — analyzes a single captured image (not a live stream, since
capture now happens once via the scheduled screenshot job) and returns:
  status, confidence (0-100), metrics dict

Confidence is a heuristic: how far the measured value sits past the
decision threshold, mapped to a 0-100 scale. It is NOT a statistical
probability — it's meant to give engineers a relative sense of how
borderline vs. obvious a detection is.
"""
import cv2
import numpy as np

CONFIG = {
    "no_signal_std_thresh": 3.0,
    "dark_mean_thresh": 25,
    "overexposed_mean_thresh": 235,
    "blur_laplacian_thresh": 60.0,
    "color_cast_ratio_thresh": 1.35,
    "grid_size": 4,
    "occlusion_cell_ratio": 0.3,
    # The date / camera-name text is burnt into the picture and is razor sharp, so it is cut off
    # before every measurement (fraction of the picture height).  Raise it if a camera's text is taller;
    # use the bottom value for cameras that print it at the bottom.
    # Auto-match: a new picture gets the engineer's earlier verdict when it is the same or BETTER than the
    # one he verified.  If its confidence is more than this many points HIGHER (worse), it is flagged instead.
    "worse_confidence_points": 15.0,
    # Learned confidence (trust in an auto-matched result): 99 - (99 - start) * decay ** repeats.
    # 1st repeat ~68%, 2nd ~77%, 3rd ~84%, 5th ~92%, 10th ~98%.  It is TRUST, not a probability.
    "learned_ceiling": 99.0,
    "learned_gap": 44.0,
    "learned_decay": 0.7,
    "overlay_top_fraction": 0.12,
    "overlay_bottom_fraction": 0.0,
    # Haze / milky veil (counted as Dirty / blurry lens).  A hazy picture has no real blacks AND little
    # contrast.  Starting values from sample pictures - lower black_level or raise contrast_range to be
    # stricter, the other way round to catch more.
    "haze_black_level_thresh": 76,     # 1st-percentile brightness above this = "blacks are grey"
    "haze_contrast_range_thresh": 135, # 99th - 1st percentile brightness below this = flat picture
}


# Detections an administrator may switch off in Settings > Schedule (No view is always on: no picture = no view).
SWITCHABLE = [
    ("TOO_DARK", "Too dark"),
    ("OVEREXPOSED", "Overexposed"),
    ("DIRTY_OR_BLURRY", "Dirty / blurry lens (includes hazy picture)"),
    ("COLOR_CAST_RED", "Red tint"),
    ("COLOR_CAST_GREEN", "Green tint"),
    ("COLOR_CAST_BLUE", "Blue tint"),
    ("PARTIAL_OCCLUSION", "Partial occlusion"),
]


def _confidence_from_margin(value, threshold, higher_is_bad, scale):
    """
    Maps how far `value` is past `threshold` into a 50-99.9 confidence score.
    higher_is_bad=True  -> triggered when value > threshold (e.g. overexposed)
    higher_is_bad=False -> triggered when value < threshold (e.g. blur, no_signal)
    `scale` controls how quickly confidence rises with margin.
    """
    margin = (value - threshold) if higher_is_bad else (threshold - value)
    margin = max(margin, 0)
    conf = 50 + 49.9 * (1 - np.exp(-margin / scale))
    return round(float(min(conf, 99.9)), 1)


def laplacian_variance(gray):
    return cv2.Laplacian(gray, cv2.CV_64F).var()


def grid_sharpness_map(gray, grid_size):
    h, w = gray.shape
    gh, gw = max(h // grid_size, 1), max(w // grid_size, 1)
    scores = np.zeros((grid_size, grid_size))
    for i in range(grid_size):
        for j in range(grid_size):
            cell = gray[i * gh:(i + 1) * gh, j * gw:(j + 1) * gw]
            scores[i, j] = laplacian_variance(cell) if cell.size else 0
    return scores


def color_cast_check(frame_bgr, ratio_thresh):
    b, g, r = (float(frame_bgr[:, :, i].mean()) for i in range(3))
    means = {"blue": b, "green": g, "red": r}
    dominant = max(means, key=means.get)
    others_avg = (sum(means.values()) - means[dominant]) / 2
    if others_avg < 1e-3:
        return False, None, 0
    ratio = means[dominant] / others_avg
    return ratio >= ratio_thresh, dominant, ratio


def analyze_image(image_path: str, disabled=()) -> dict:
    return analyze_frame(cv2.imread(image_path), disabled)


def analyze_frame(frame, disabled=()) -> dict:
    """Analyze an image already in memory (BGR array). None means 'no picture'.
    `disabled` = detections that are switched off (see SWITCHABLE); they are simply not checked."""
    off = set(disabled or ())
    if frame is None:
        return {
            "status": "NO_VIEW",
            "confidence": 99.9,
            "metrics": {"reason": "unreadable_or_missing_image"},
        }

    h = frame.shape[0]
    top = int(h * CONFIG["overlay_top_fraction"])
    bottom = h - int(h * CONFIG["overlay_bottom_fraction"])
    if bottom - top >= 16:                         # leave the text strip out of all measurements
        frame = frame[top:bottom]

    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    black_level, white_level = (float(v) for v in np.percentile(gray, [1, 99]))
    contrast_range = white_level - black_level
    mean_val = float(gray.mean())
    std_val = float(gray.std())
    focus = float(laplacian_variance(gray))
    has_cast, dominant, cast_ratio = color_cast_check(frame, CONFIG["color_cast_ratio_thresh"])

    metrics = {
        "mean_brightness": round(mean_val, 2),
        "std_dev": round(std_val, 2),
        "focus_score": round(focus, 2),
        "dominant_channel": dominant,
        "color_ratio": round(cast_ratio, 3),
        "black_level": round(black_level, 1),
        "contrast_range": round(contrast_range, 1),
    }

    # 1. No view (blank / disconnected / solid frame)
    if std_val < CONFIG["no_signal_std_thresh"]:
        conf = _confidence_from_margin(std_val, CONFIG["no_signal_std_thresh"],
                                        higher_is_bad=False, scale=1.5)
        return {"status": "NO_VIEW", "confidence": conf, "metrics": metrics}

    # 2. Too dark
    if "TOO_DARK" not in off and mean_val < CONFIG["dark_mean_thresh"]:
        conf = _confidence_from_margin(mean_val, CONFIG["dark_mean_thresh"],
                                        higher_is_bad=False, scale=8)
        return {"status": "TOO_DARK", "confidence": conf, "metrics": metrics}

    # 3. Overexposed
    if "OVEREXPOSED" not in off and mean_val > CONFIG["overexposed_mean_thresh"]:
        conf = _confidence_from_margin(mean_val, CONFIG["overexposed_mean_thresh"],
                                        higher_is_bad=True, scale=8)
        return {"status": "OVEREXPOSED", "confidence": conf, "metrics": metrics}

    # 4. Hazy / milky picture -> Dirty / blurry lens (checked BEFORE colour, because haze is often
    #    warm or grey and used to be mistaken for a tint or a partial occlusion)
    if ("DIRTY_OR_BLURRY" not in off and black_level > CONFIG["haze_black_level_thresh"]
            and contrast_range < CONFIG["haze_contrast_range_thresh"]):
        conf = _confidence_from_margin(contrast_range, CONFIG["haze_contrast_range_thresh"],
                                        higher_is_bad=False, scale=25)
        return {"status": "DIRTY_OR_BLURRY", "confidence": conf, "metrics": metrics}

    # 5. Color cast (green / blue / red tint)
    if has_cast and f"COLOR_CAST_{dominant.upper()}" not in off:
        conf = _confidence_from_margin(cast_ratio, CONFIG["color_cast_ratio_thresh"],
                                        higher_is_bad=True, scale=0.25)
        return {"status": f"COLOR_CAST_{dominant.upper()}", "confidence": conf, "metrics": metrics}

    # 6. Dirty / blurry lens (soft picture)
    if "DIRTY_OR_BLURRY" not in off and focus < CONFIG["blur_laplacian_thresh"]:
        conf = _confidence_from_margin(focus, CONFIG["blur_laplacian_thresh"],
                                        higher_is_bad=False, scale=25)
        return {"status": "DIRTY_OR_BLURRY", "confidence": conf, "metrics": metrics}

    # 7. Partial occlusion
    grid = grid_sharpness_map(gray, CONFIG["grid_size"])
    sharp_cells = int((grid > CONFIG["blur_laplacian_thresh"]).sum())
    total_cells = grid.size
    sharp_ratio = sharp_cells / total_cells
    metrics["sharp_cell_ratio"] = round(sharp_ratio, 2)
    if "PARTIAL_OCCLUSION" not in off and 0 < sharp_cells < total_cells * (1 - CONFIG["occlusion_cell_ratio"]):
        conf = _confidence_from_margin(1 - sharp_ratio, CONFIG["occlusion_cell_ratio"],
                                        higher_is_bad=True, scale=0.2)
        return {"status": "PARTIAL_OCCLUSION", "confidence": conf, "metrics": metrics}

    return {"status": "OK", "confidence": 95.0, "metrics": metrics}


def learned_confidence(repeats):
    """Trust in an auto-matched result after `repeats` consecutive confirmations (1 = first repeat)."""
    repeats = max(int(repeats), 1)
    value = CONFIG["learned_ceiling"] - CONFIG["learned_gap"] * (CONFIG["learned_decay"] ** repeats)
    return round(float(min(value, CONFIG["learned_ceiling"])), 1)


def compare_to_verified(new_confidence, verified_confidence):
    """'same_or_better' or 'worse'.  For one detection type, a higher confidence always means the
    problem sits further past its threshold, i.e. it is more severe."""
    if new_confidence is None or verified_confidence is None:
        return "same_or_better"
    if new_confidence > verified_confidence + CONFIG["worse_confidence_points"]:
        return "worse"
    return "same_or_better"


def metrics_are_similar(m1: dict, m2: dict, tolerance=0.15) -> bool:
    """
    Compares two metric snapshots to decide if they represent 'the same
    condition' on the same camera (used for auto-matching engineer verdicts).
    Numeric fields are compared with a relative tolerance; the dominant
    color channel, if present, must match exactly.
    """
    if not m1 or not m2:
        return False
    numeric_keys = ["mean_brightness", "std_dev", "focus_score", "color_ratio"]
    for key in numeric_keys:
        v1, v2 = m1.get(key), m2.get(key)
        if v1 is None or v2 is None:
            continue
        denom = max(abs(v1), abs(v2), 1e-6)
        if abs(v1 - v2) / denom > tolerance:
            return False
    if m1.get("dominant_channel") and m2.get("dominant_channel"):
        if m1["dominant_channel"] != m2["dominant_channel"]:
            return False
    return True
