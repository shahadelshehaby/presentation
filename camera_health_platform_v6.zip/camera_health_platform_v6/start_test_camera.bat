@echo off
REM ------------------------------------------------------------------
REM Dummy IP camera: loops a video file as a real RTSP stream.
REM Needs (put both in this folder, no install required):
REM   mediamtx.exe  - https://github.com/bluenviron/mediamtx/releases
REM   ffmpeg.exe    - https://www.gyan.dev/ffmpeg/builds/
REM Usage:  start_test_camera.bat myvideo.mp4 cam1
REM Then in Settings add a camera with:
REM   IP = 127.0.0.1:8554    RTSP path = /cam1    (no username/password)
REM ------------------------------------------------------------------
cd /d "%~dp0"
set VIDEO=%~1
set NAME=%~2
if "%VIDEO%"=="" set VIDEO=test.mp4
if "%NAME%"=="" set NAME=cam1

tasklist /FI "IMAGENAME eq mediamtx.exe" | find /I "mediamtx.exe" >nul
if errorlevel 1 start "MediaMTX RTSP server" mediamtx.exe
timeout /t 2 >nul

echo Streaming %VIDEO% to rtsp://127.0.0.1:8554/%NAME%  (Ctrl+C to stop)
ffmpeg -re -stream_loop -1 -i "%VIDEO%" -an -c:v libx264 -preset veryfast -tune zerolatency -g 25 -f rtsp rtsp://127.0.0.1:8554/%NAME%
pause
