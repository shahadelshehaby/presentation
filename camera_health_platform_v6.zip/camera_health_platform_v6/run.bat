@echo off
cd /d "%~dp0"
REM Prefer the Python launcher (py.exe) - it picks your newest installed
REM version regardless of PATH order, avoiding "wrong python version" issues.
where py >nul 2>nul
if %errorlevel%==0 (
    py run.py
) else (
    python run.py
)
pause
