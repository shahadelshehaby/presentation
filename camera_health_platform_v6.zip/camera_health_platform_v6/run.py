"""
run.py — double-click (or `python run.py`) to start the Camera Health Platform.

What it does:
1. Makes sure required packages are installed (installs them automatically
   if missing — only touches your local machine, no internet needed after
   the first install).
2. Starts the Flask app + scheduler.
3. Opens your browser to the dashboard automatically.

This is the ONLY file you need to run.
"""
import subprocess
import sys
import os
import time
import threading
import webbrowser

REQUIRED_PACKAGES = {
    "flask": "flask",
    "cv2": "opencv-python-headless",
    "numpy": "numpy",
    "apscheduler": "apscheduler",
    "reportlab": "reportlab",
    "openpyxl": "openpyxl",
}

HOST = "0.0.0.0"            # reachable from other PCs on the network (the Engineering Building)
BROWSER_HOST = "127.0.0.1"
PORT = 5070                # own port: not 5000, 5002 or 5050


def ensure_dependencies():
    missing = []
    for import_name, pip_name in REQUIRED_PACKAGES.items():
        try:
            __import__(import_name)
        except ImportError:
            missing.append(pip_name)

    if missing:
        print(f"Installing missing packages: {', '.join(missing)} ...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", *missing])
        print("Done installing dependencies.\n")


def open_browser_when_ready():
    time.sleep(1.5)
    webbrowser.open(f"http://{BROWSER_HOST}:{PORT}")


def main():
    os.chdir(os.path.dirname(os.path.abspath(__file__)))

    ensure_dependencies()

    # Import after dependencies are confirmed installed
    from app import app, _refresh_schedule  # noqa: E402

    _refresh_schedule()

    threading.Thread(target=open_browser_when_ready, daemon=True).start()

    print(f"\nCamera Health Platform starting at http://{BROWSER_HOST}:{PORT}\n(Engineering Building status page: http://<this PC's IP>:{PORT}/building/status)")
    print("Keep this window open while using the platform. Press Ctrl+C to stop.\n")

    app.run(host=HOST, port=PORT, debug=False, use_reloader=False)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nStopped.")
    except Exception as e:
        print(f"\nSomething went wrong: {e}")
        input("Press Enter to close...")
