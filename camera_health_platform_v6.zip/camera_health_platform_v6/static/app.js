/* Small progressive-enhancement helpers. The platform still works without this
   file; it only adds live status, loading states and the Save-bar messages. */
(function () {
  "use strict";

  /* 1. Live status text in the header (refreshes every 30 s) */
  var statusEl = document.getElementById("live-status");
  function refreshStatus() {
    if (!statusEl || !statusEl.dataset.url) return;
    fetch(statusEl.dataset.url, { cache: "no-store" })
      .then(function (r) { if (!r.ok) throw new Error("bad response"); return r.json(); })
      .then(function (d) {
        statusEl.textContent = d.text;
        statusEl.classList.toggle("is-error", !!d.error);
      })
      .catch(function () {
        statusEl.textContent = "Server unreachable";
        statusEl.classList.add("is-error");
      });
  }
  if (statusEl) {
    setInterval(refreshStatus, 30000);
    document.addEventListener("visibilitychange", function () {
      if (!document.hidden) refreshStatus();
    });
  }

  /* 2. Loading state for slow actions: <form data-loading="Working…"> */
  function resetLoading() {
    document.querySelectorAll(".is-loading").forEach(function (b) {
      b.classList.remove("is-loading");
      b.removeAttribute("aria-busy");
      b.disabled = false;
      if (b.dataset.label) b.textContent = b.dataset.label;
    });
  }
  window.addEventListener("pageshow", function (e) { if (e.persisted) resetLoading(); });

  document.querySelectorAll("form[data-loading]").forEach(function (form) {
    form.addEventListener("submit", function (e) {
      if (e.defaultPrevented) return;            // e.g. the user cancelled a confirm()
      var btn = form.querySelector('button[type="submit"]');
      if (!btn) return;
      btn.dataset.label = btn.textContent;
      btn.textContent = form.dataset.loading || "Working…";
      btn.classList.add("is-loading");
      btn.setAttribute("aria-busy", "true");
      setTimeout(function () { btn.disabled = true; }, 0);
    });
  });

  /* 3. Broken screenshot -> neutral "Image unavailable" block */
  document.querySelectorAll(".insp-thumb img").forEach(function (img) {
    img.addEventListener("error", function () {
      var box = document.createElement("div");
      box.className = "no-image";
      box.textContent = "Image unavailable";
      img.replaceWith(box);
    });
  });

  /* 4. Settings: Save bar status (Unsaved changes / Saving / errors) - any form marked data-savebar */
  var form = document.querySelector("form[data-savebar]");
  var saveStatus = document.getElementById("save-status");
  var saveBtn = document.querySelector("button[data-save]");
  function setSaveStatus(text, cls) {
    saveStatus.textContent = text;
    saveStatus.className = "save-status" + (cls ? " " + cls : "");
  }
  if (form && saveStatus) {
    form.addEventListener("input", function () { setSaveStatus("Unsaved changes", "is-warn"); });
    form.addEventListener("invalid", function () {
      setSaveStatus("Please fill in the required fields.", "is-error");
    }, true);
    form.addEventListener("submit", function (e) {
      if (e.defaultPrevented) return;
      setSaveStatus("Saving…", "");
      if (saveBtn) {
        saveBtn.dataset.label = saveBtn.textContent;
        saveBtn.textContent = "Saving…";
        saveBtn.classList.add("is-loading");
        setTimeout(function () { saveBtn.disabled = true; }, 0);
      }
    });
  }

  /* 4b. Schedule page: live estimate of how long a run takes */
  var scheduleForm = document.getElementById("schedule-form");
  if (scheduleForm) {
    var estimate = document.getElementById("schedule-estimate");
    var cams = parseInt(scheduleForm.dataset.cameras, 10) || 0;
    var per = parseInt(scheduleForm.dataset.perCapture, 10) || 3;
    var pauseInput = document.getElementById("pause_seconds");
    var timeInput = document.getElementById("schedule_time");
    var workersInput = document.getElementById("workers");
    var updateEstimate = function () {
      var pause = Math.max(0, parseInt(pauseInput.value, 10) || 0);
      var workers = Math.max(1, parseInt(workersInput && workersInput.value, 10) || 1);
      var secs = cams * (pause + per) / workers, h = Math.floor(secs / 3600), m = Math.floor((secs % 3600) / 60);
      var text = "About " + (h ? h + " h " + m + " min" : Math.max(m, secs ? 1 : 0) + " min") +
                 " for " + cams.toLocaleString() + " camera" + (cams === 1 ? "" : "s") + " in the daily run";
      var t = (timeInput.value || "").split(":");
      if (t.length === 2 && cams) {
        var end = new Date(2000, 0, 1, parseInt(t[0], 10), parseInt(t[1], 10) + Math.round(secs / 60));
        text += " (finishes around " + String(end.getHours()).padStart(2, "0") + ":" + String(end.getMinutes()).padStart(2, "0") + ")";
      }
      estimate.textContent = text + ".";
    };
    pauseInput.addEventListener("input", updateEstimate);
    timeInput.addEventListener("input", updateEstimate);
    if (workersInput) workersInput.addEventListener("input", updateEstimate);
    updateEstimate();

    /* terminal box <-> its machine boxes (also shows the "some machines" state) */
    Array.prototype.forEach.call(scheduleForm.querySelectorAll(".sched-tree .tree-group"), function (group) {
      var head = group.querySelector(".sched-terminal");
      var boxes = group.querySelectorAll(".sched-machine");
      var sync = function () {
        var on = Array.prototype.filter.call(boxes, function (b) { return b.checked; }).length;
        head.checked = on === boxes.length;
        head.indeterminate = on > 0 && on < boxes.length;
      };
      head.addEventListener("change", function () {
        Array.prototype.forEach.call(boxes, function (b) { b.checked = head.checked; });
        head.indeterminate = false;
      });
      Array.prototype.forEach.call(boxes, function (b) { b.addEventListener("change", sync); });
      sync();
    });
  }

  /* 5. Diagnose: "Select all" checkbox for the PDF export */
  var selectAll = document.getElementById("select-all");
  if (selectAll) {
    var boxes = Array.prototype.slice.call(document.querySelectorAll(".insp-check"));
    selectAll.addEventListener("change", function () {
      boxes.forEach(function (b) { b.checked = selectAll.checked; });
    });
    boxes.forEach(function (b) {
      b.addEventListener("change", function () {
        selectAll.checked = boxes.every(function (x) { return x.checked; });
      });
    });
  }

  /* 6. Diagnose: pick terminals / machines and see how many cameras that is */
  var runForm = document.getElementById("run-form");
  if (runForm) {
    var items = Array.prototype.slice.call(runForm.querySelectorAll('input[name="groups"]'));
    var groups = Array.prototype.slice.call(runForm.querySelectorAll(".tree-group"));
    var runBtn = document.getElementById("run-btn");
    var runHint = document.getElementById("run-hint");
    var pause = parseFloat(runForm.dataset.pause) || 0;
    var refreshRun = function () {
      var cams = 0;
      items.forEach(function (i) { if (i.checked) cams += parseInt(i.dataset.count, 10) || 0; });
      groups.forEach(function (g) {                       // keep each terminal box in step with its machines
        var boxes = g.querySelectorAll('input[name="groups"]');
        g.querySelector(".tree-all").checked = Array.prototype.every.call(boxes, function (b) { return b.checked; });
      });
      runBtn.disabled = cams === 0;
      runBtn.textContent = cams ? "Diagnose " + cams.toLocaleString() + " camera" + (cams === 1 ? "" : "s") : "Diagnose";
      var mins = Math.max(1, Math.round(cams * (pause + 3) / 60));
      runHint.textContent = cams ? "One at a time, about " + mins + " min in total." : "Nothing selected yet.";
    };
    runForm.addEventListener("change", function (e) {
      if (e.target.classList.contains("tree-all")) {
        e.target.closest(".tree-group").querySelectorAll('input[name="groups"]').forEach(function (b) { b.checked = e.target.checked; });
      }
      refreshRun();
    });
    runForm.querySelector("[data-run-all]").addEventListener("click", function () { items.forEach(function (b) { b.checked = true; }); refreshRun(); });
    runForm.querySelector("[data-run-none]").addEventListener("click", function () { items.forEach(function (b) { b.checked = false; }); refreshRun(); });
    runForm.addEventListener("submit", function (e) {
      if (e.defaultPrevented) return;
      runBtn.textContent = "Queuing…";
      setTimeout(function () { runBtn.disabled = true; }, 0);
    });
    refreshRun();
  }

  /* 7. Diagnose: progress of a running diagnosis (checks every 2 s) */
  var progressCard = document.getElementById("progress-card");
  if (progressCard) {
    var wasRunning = false;
    var pText = document.getElementById("progress-text"), pLabel = document.getElementById("progress-label");
    var pFill = document.getElementById("progress-fill"), pCurrent = document.getElementById("progress-current");
    var pStop = document.getElementById("progress-stop-form"), pRefresh = document.getElementById("progress-refresh");
    pRefresh.addEventListener("click", function () { window.location.reload(); });
    var poll = function () {
      fetch(progressCard.dataset.url, { cache: "no-store" })
        .then(function (r) { return r.json(); })
        .then(function (p) {
          if (p.running) {
            wasRunning = true;
            progressCard.hidden = false; pStop.hidden = false; pRefresh.hidden = true;
            pText.textContent = p.done + " / " + p.total;
            pLabel.textContent = "cameras diagnosed";
            pFill.style.width = (p.total ? Math.round(100 * p.done / p.total) : 0) + "%";
            pCurrent.textContent = p.current ? "Now: " + p.current : "";
          } else if (wasRunning) {                           // just finished
            pText.textContent = p.done + " / " + p.total;
            pLabel.textContent = "cameras diagnosed — finished";
            pFill.style.width = "100%"; pCurrent.textContent = "";
            pStop.hidden = true; pRefresh.hidden = false;
          }
        })
        .catch(function () {});
    };
    poll();
    setInterval(poll, 2000);
  }

  /* 8. Settings > Cameras: tick several cameras and delete them together */
  // Engineer verdict: the "reason" list only appears (and is required) for "Normal / false detection".
  Array.prototype.forEach.call(document.querySelectorAll(".verdict-form"), function (form) {
    var verdict = form.querySelector(".verdict-select"), reason = form.querySelector(".reason-select");
    if (!verdict || !reason) return;
    var sync = function () {
      var needs = verdict.value === "normal";
      reason.hidden = !needs;
      reason.required = needs;
      if (!needs) reason.value = "";
    };
    verdict.addEventListener("change", sync);
    sync();
  });

  /* Diagnose: saving an engineer verdict updates the card in place - the page does not reload or jump to the top */
  Array.prototype.forEach.call(document.querySelectorAll(".verdict-form"), function (form) {
    form.addEventListener("submit", function (e) {
      if (!window.fetch || !window.FormData) return;                 // old browser: normal save + reload
      e.preventDefault();
      var card = form.closest(".insp"), btn = form.querySelector("button[type=submit]");
      var label = btn ? btn.textContent : "";
      if (btn) { btn.disabled = true; btn.textContent = "Saving…"; }
      window.fetch(form.action, {method: "POST", body: new FormData(form),
                                 headers: {"X-Requested-With": "fetch"}, credentials: "same-origin"})
        .then(function (r) { if (!r.ok) throw new Error("save failed"); return r.json(); })
        .then(function (d) {
          var verdict = card.querySelector(".verdict");
          verdict.hidden = false;
          verdict.querySelector(".verdict-text").textContent =
            d.verdict + (d.reason ? " — reason: " + d.reason : "") + (d.comment ? " — " + d.comment : "");
          verdict.querySelector(".verdict-meta").textContent = "(" + d.engineer + ", " + d.when + ")";
          var pill = card.querySelector(".insp-pill");
          pill.textContent = d.final_label;
          pill.className = "pill insp-pill " + ({ok: "pill-success", error: "pill-danger", attention: "pill-warn"})[d.sev];
          card.querySelector(".insp-dot").className = "dot insp-dot dot-" + d.sev;
          var det = card.querySelector(".insp-detected");
          det.textContent = "detected: " + d.detected_label;
          det.hidden = !d.changed;
          var details = form.closest("details");
          details.querySelector("summary").textContent = "Update verdict";
          details.open = false;
          if (btn) { btn.disabled = false; btn.textContent = label; }
        })
        .catch(function () {
          if (btn) { btn.disabled = false; btn.textContent = label; }
          form.submit();                                              // fall back to the normal save
        });
    });
  });

  /* Diagnose: click a picture to see it large (arrow keys / buttons move between pictures, Esc closes) */
  var lightbox = document.getElementById("lightbox");
  if (lightbox) {
    var lbImg = document.getElementById("lb-img"), lbCap = document.getElementById("lb-caption");
    var thumbs = Array.prototype.slice.call(document.querySelectorAll("[data-lightbox]"));
    var lbIndex = 0;
    var lbShow = function (n) {
      if (!thumbs.length) return;
      lbIndex = (n + thumbs.length) % thumbs.length;
      lbImg.src = thumbs[lbIndex].dataset.src;
      lbCap.textContent = thumbs[lbIndex].dataset.caption || "";
    };
    var lbOpen = function (n) { lbShow(n); lightbox.hidden = false; document.body.classList.add("lb-open"); };
    var lbClose = function () { lightbox.hidden = true; lbImg.removeAttribute("src"); document.body.classList.remove("lb-open"); };
    thumbs.forEach(function (t, n) { t.addEventListener("click", function () { lbOpen(n); }); });
    document.getElementById("lb-close").addEventListener("click", lbClose);
    document.getElementById("lb-prev").addEventListener("click", function () { lbShow(lbIndex - 1); });
    document.getElementById("lb-next").addEventListener("click", function () { lbShow(lbIndex + 1); });
    lightbox.addEventListener("click", function (e) { if (e.target === lightbox) lbClose(); });
    document.addEventListener("keydown", function (e) {
      if (lightbox.hidden) return;
      if (e.key === "Escape") lbClose();
      else if (e.key === "ArrowLeft") lbShow(lbIndex - 1);
      else if (e.key === "ArrowRight") lbShow(lbIndex + 1);
    });
  }

  /* Diagnose: "Delete selected" asks first, and for more than 10 inspections you must type DELETE */
  var delBtn = document.querySelector("[data-delete-inspections]");
  if (delBtn) {
    delBtn.addEventListener("click", function (e) {
      var n = document.querySelectorAll(".insp-check:checked").length;
      if (!n) { e.preventDefault(); window.alert("Tick the inspections you want to delete first."); return; }
      var what = n === 1 ? "1 inspection" : n.toLocaleString() + " inspections";
      if (!window.confirm("Delete " + what + " together with their engineer verdicts and stored pictures?\n\nThis cannot be undone.")) {
        e.preventDefault(); return;
      }
      if (n > 10) {
        var typed = window.prompt("You are about to delete " + what + ".\nType DELETE to confirm.");
        if (typed === null || typed.trim().toUpperCase() !== "DELETE") { e.preventDefault(); }
      }
    });
  }

  var bulkForm = document.getElementById("bulk-form");
  var checkAll = document.getElementById("check-all");
  if (bulkForm && checkAll) {
    var rows = Array.prototype.slice.call(document.querySelectorAll(".row-check"));
    var bar = document.getElementById("bulk-bar"), countEl = document.getElementById("bulk-count");
    var banner = document.getElementById("bulk-banner"), bannerText = document.getElementById("bulk-banner-text");
    var allMatching = document.getElementById("bulk-all-matching"), scope = document.getElementById("bulk-scope");
    var total = parseInt(bulkForm.dataset.total, 10) || 0;
    var allLabel = allMatching ? allMatching.textContent : "";   // the server-written "Select all N cameras ..." text
    var wholeFilter = false;                               // true = "all N matching the filter" is chosen
    var selectedCount = function () { return wholeFilter ? total : rows.filter(function (r) { return r.checked; }).length; };
    var refreshBulk = function () {
      var onPage = rows.filter(function (r) { return r.checked; }).length;
      if (onPage < rows.length) { wholeFilter = false; scope.value = "selected"; }
      checkAll.checked = rows.length > 0 && onPage === rows.length;
      checkAll.indeterminate = onPage > 0 && onPage < rows.length;
      var n = selectedCount();
      bar.hidden = n === 0;
      countEl.textContent = n.toLocaleString() + " selected" + (wholeFilter ? " (every camera in this list)" : "");
      if (banner) {
        banner.hidden = !(onPage === rows.length && total > rows.length);
        if (wholeFilter) {
          bannerText.textContent = "All " + total.toLocaleString() + " cameras in this list are selected, on every page.";
          allMatching.textContent = "Select only this page";
        } else {
          bannerText.textContent = "All " + rows.length + " cameras on this page are selected.";
          allMatching.textContent = allLabel;
        }
      }
    };
    checkAll.addEventListener("change", function () {
      rows.forEach(function (r) { r.checked = checkAll.checked; });
      wholeFilter = false; scope.value = "selected";
      refreshBulk();
    });
    rows.forEach(function (r) { r.addEventListener("change", refreshBulk); });
    document.getElementById("bulk-clear").addEventListener("click", function () {
      rows.forEach(function (r) { r.checked = false; });
      wholeFilter = false; scope.value = "selected"; refreshBulk();
    });
    if (allMatching) {
      allMatching.addEventListener("click", function () {
        wholeFilter = !wholeFilter;
        scope.value = wholeFilter ? "filtered" : "selected";
        if (!wholeFilter) { rows.forEach(function (r) { r.checked = true; }); }
        refreshBulk();
      });
    }
    bulkForm.addEventListener("submit", function (e) {
      var n = selectedCount();
      if (!n) { e.preventDefault(); return; }
      var what = n === 1 ? "1 camera" : n.toLocaleString() + " cameras";
      if (!window.confirm("Delete " + what + " from the camera list?\n\nTheir previous inspections and reports are kept.")) {
        e.preventDefault(); return;
      }
      if (n > 10) {
        var typed = window.prompt("You are about to delete " + what + ".\nType DELETE to confirm.");
        if (typed === null || typed.trim().toUpperCase() !== "DELETE") { e.preventDefault(); return; }
      }
      var btn = document.getElementById("bulk-delete");
      btn.textContent = "Deleting…";
      setTimeout(function () { btn.disabled = true; }, 0);
    });
    refreshBulk();
  }
})();
