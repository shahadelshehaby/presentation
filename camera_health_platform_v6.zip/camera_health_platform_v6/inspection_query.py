"""
inspection_query.py - Diagnose-tab queries with MULTI-VALUE filters.

The Diagnose filters (terminal, machine, camera, status, verdict) can each hold several values, e.g.
machine = A101 + A102 + B201.  Values inside one filter are OR-ed ("any of these machines"); different
filters are AND-ed ("these machines AND these statuses").  An empty filter means "all".

Only reads the database (through db.get_conn), so db.py does not need to change.
The Status filter and the "Issues detected" count use the FINAL status (the engineer's correction when there
is one) when the inspections table has a final_status column, otherwise the detected status.
"""
import db

NO_TERMINAL = getattr(db, "NO_TERMINAL", "__none__")
VERDICT_KEYS = ("awaiting", "verified", "auto", "worse")
SORT_COLUMNS = getattr(db, "SORT_COLUMNS", {
    "timestamp": "i.timestamp", "status": "i.status", "confidence": "i.confidence",
    "learned_confidence": "i.learned_confidence", "machine_name": "c.machine_name",
    "camera_name": "c.camera_name", "terminal": "c.terminal"})
_MAX_IN = 900                     # SQLite allows a limited number of ? placeholders in one query
_final_col = None


def _has_final_status(conn):
    global _final_col
    if _final_col is None:
        _final_col = "final_status" in {r[1] for r in conn.execute("PRAGMA table_info(inspections)")}
    return _final_col


def as_list(value):
    """None / '' / 'x' / ['x', ''] -> clean list of strings."""
    if value is None:
        return []
    if isinstance(value, (list, tuple, set)):
        return [str(v) for v in value if str(v).strip() != ""]
    return [str(value)] if str(value).strip() != "" else []


def _in(column, values, params):
    values = list(values)[:_MAX_IN]
    params.extend(values)
    return f"{column} IN ({','.join('?' for _ in values)})"


def _where(conn, status=None, camera_id=None, terminal=None, machine=None, date_from=None, date_to=None,
           latest_only=False, verdict=None, conf_min=None, conf_max=None, learned_min=None, learned_max=None, **_ignored):
    where, params = ["1=1"], []
    status_col = "COALESCE(i.final_status, i.status)" if _has_final_status(conn) else "i.status"

    statuses = as_list(status)
    if statuses:
        where.append(_in(status_col, statuses, params))

    cam_ids = [int(v) for v in as_list(camera_id) if str(v).isdigit()]
    if cam_ids:
        where.append(_in("i.camera_id", cam_ids, params))

    terminals = as_list(terminal)
    if terminals:
        parts = []
        named = [t for t in terminals if t != NO_TERMINAL]
        if named:
            parts.append(_in("c.terminal", named, params))
        if NO_TERMINAL in terminals:
            parts.append("(c.terminal IS NULL OR c.terminal = '')")
        where.append("(" + " OR ".join(parts) + ")")

    machines = as_list(machine)
    if machines:
        where.append(_in("c.machine_name", machines, params))

    if date_from:
        where.append("i.timestamp >= ?"); params.append(date_from)
    if date_to:
        where.append("i.timestamp <= ?"); params.append(date_to)

    verdict_sql = {
        "awaiting": "(i.status != 'OK' AND NOT EXISTS (SELECT 1 FROM feedback f WHERE f.inspection_id = i.id))",
        "verified": "EXISTS (SELECT 1 FROM feedback f WHERE f.inspection_id = i.id "
                    "AND COALESCE(f.engineer_name, '') != 'auto-match')",
        "auto": "i.auto_matched = 1",
        "worse": "i.worse_flag = 1",
    }
    chosen = [verdict_sql[v] for v in as_list(verdict) if v in verdict_sql]
    if chosen:
        where.append("(" + " OR ".join(chosen) + ")")

    for col, lo, hi in (("i.confidence", conf_min, conf_max), ("i.learned_confidence", learned_min, learned_max)):
        if lo is not None:
            where.append(f"{col} >= ?"); params.append(lo)
        if hi is not None:
            where.append(f"{col} <= ?"); params.append(hi)
    if latest_only:
        where.append("i.id IN (SELECT MAX(id) FROM inspections GROUP BY camera_id)")
        where.append("c.deleted = 0")
    return " AND ".join(where), params


def _newest_n(where, params, last):
    if not last:
        return where, params
    sub = ("SELECT i.id FROM inspections i JOIN cameras c ON i.camera_id = c.id "
           f"WHERE {where} ORDER BY i.timestamp DESC, i.id DESC LIMIT ?")
    return f"i.id IN ({sub})", params + [int(last)]


def list_inspections(sort_by="timestamp", sort_dir="desc", limit=200, last=None, **filters):
    conn = db.get_conn()
    try:
        where, params = _where(conn, **filters)
        where, params = _newest_n(where, params, last)
        col = SORT_COLUMNS.get(sort_by, "i.timestamp")
        direction = "ASC" if str(sort_dir).lower() == "asc" else "DESC"
        q = (f"SELECT i.*, c.machine_name, c.camera_name, c.ip, c.terminal, c.deleted AS camera_removed "
             f"FROM inspections i JOIN cameras c ON i.camera_id = c.id WHERE {where} "
             f"ORDER BY {col} {direction}, i.id DESC LIMIT ?")
        return [dict(r) for r in conn.execute(q, params + [limit]).fetchall()]
    finally:
        conn.close()


def inspection_summary(last=None, **filters):
    """Totals over ALL inspections matching the filters (not just the ones shown on screen)."""
    conn = db.get_conn()
    try:
        where, params = _where(conn, **filters)
        where, params = _newest_n(where, params, last)
        if _has_final_status(conn):
            issue = "COALESCE(i.final_status, i.status) != 'OK'"
        else:
            issue = "i.status != 'OK' AND COALESCE(i.learned_status, '') NOT IN ('OK', 'OLD_CAMERA')"
        q = f"""SELECT COUNT(*) AS total,
                       COALESCE(SUM(CASE WHEN {issue} THEN 1 ELSE 0 END), 0) AS issues,
                       COALESCE(SUM(CASE WHEN i.status != 'OK' AND NOT EXISTS
                            (SELECT 1 FROM feedback f WHERE f.inspection_id = i.id) THEN 1 ELSE 0 END), 0) AS awaiting,
                       COALESCE(SUM(i.auto_matched), 0) AS auto_matched
                FROM inspections i JOIN cameras c ON i.camera_id = c.id WHERE {where}"""
        return dict(conn.execute(q, params).fetchone())
    finally:
        conn.close()
