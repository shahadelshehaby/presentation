import os
import re
import csv
import io
import json
from datetime import datetime, timedelta

from flask import (Flask, render_template, request, redirect, url_for,
                    send_file, jsonify, flash)
from apscheduler.schedulers.background import BackgroundScheduler

import db
import capture
import diagnosis
import report
import importer
import building_status
import timeutil
import inspection_query            # Diagnose queries with multi-value filters (several machines, statuses, ...)

app = Flask(__name__)
app.secret_key = "change-me-in-production"
app.config["MAX_CONTENT_LENGTH"] = 20 * 1024 * 1024      # biggest Excel/CSV upload (20 MB)

db.init_db()
building_status.register(app)       # read-only status page for the Engineering Building dashboard

scheduler = BackgroundScheduler()
scheduler.start()

DEFAULT_TIME = "09:00"
DISPLAY_LIMIT = 200          # inspections listed on one Diagnose page
MAX_REPORT_ROWS = 2000       # one PDF report holds at most this many inspections
PAGE_SIZE = 50               # cameras per page in Settings > Cameras
SECONDS_PER_CAPTURE = 3      # rough time one capture takes (only used for the time estimate)


# ---------------------------------------------------------------------------
# Schedule helpers
# ---------------------------------------------------------------------------
def _parse_time(value):
    m = re.fullmatch(r"(\d{1,2}):(\d{2})", (value or "").strip())
    if m and int(m.group(1)) < 24 and int(m.group(2)) < 60:
        return int(m.group(1)), int(m.group(2))
    return 9, 0


def _valid_time(value):
    m = re.fullmatch(r"(\d{1,2}):(\d{2})", (value or "").strip())
    return bool(m) and int(m.group(1)) < 24 and int(m.group(2)) < 60


def _pause_seconds():
    try:
        return max(0, int(float(db.get_setting("pause_seconds", capture.DEFAULT_PAUSE_SECONDS))))
    except (TypeError, ValueError):
        return capture.DEFAULT_PAUSE_SECONDS


def _parse_date(value):
    try:
        return datetime.strptime((value or "").strip(), "%Y-%m-%d").date()
    except ValueError:
        return None


def _schedule_config():
    """The saved schedule (Settings > Schedule) as keyword arguments for capture.schedule_inspection()."""
    hour, minute = _parse_time(db.get_setting("schedule_time", DEFAULT_TIME))
    frequency = db.get_setting("schedule_frequency", "daily")
    if frequency not in dict(capture.FREQUENCIES):
        frequency = "daily"
    try:
        every_days = min(capture.MAX_EVERY_DAYS, max(2, int(db.get_setting("schedule_every_days", 2))))
    except (TypeError, ValueError):
        every_days = 2
    weekdays = [d for d in (db.get_setting("schedule_weekdays", "mon") or "").split(",") if d in dict(capture.WEEKDAYS)]
    month_day = db.get_setting("schedule_month_day", "1") or "1"
    if month_day != "last" and not (month_day.isdigit() and 1 <= int(month_day) <= 28):
        month_day = "1"
    return {"hour": hour, "minute": minute, "frequency": frequency, "every_days": every_days,
            "weekdays": weekdays or ["mon"], "month_day": month_day,
            "start_date": _parse_date(db.get_setting("schedule_start_date")) or datetime.now().date()}


def _refresh_schedule():
    capture.schedule_inspection(scheduler, **_schedule_config())


_refresh_schedule()


def _duration_text(cameras, pause, workers=1):
    seconds = cameras * (pause + SECONDS_PER_CAPTURE) / max(1, workers)
    hours, rest = divmod(int(seconds), 3600)
    minutes = rest // 60
    if hours:
        return f"{hours} h {minutes} min"
    return f"{max(minutes, 1) if seconds else 0} min"


VERDICT_LABELS = {                       # what is shown (the last two are older verdicts, still displayed)
    "same": "Same as detected",
    "normal": "Normal / false detection",
    "old_camera": "Old camera (expected for this unit)",
    "other": "Other issue",
}
VERDICT_CHOICES = ["same", "normal"]     # what an engineer can pick now

STATUS_LABELS = {
    "OK": "OK",
    "NO_VIEW": "No view",
    "TOO_DARK": "Too dark",
    "OVEREXPOSED": "Overexposed",
    "COLOR_CAST_GREEN": "Green tint",
    "COLOR_CAST_BLUE": "Blue tint",
    "COLOR_CAST_RED": "Red tint",
    "DIRTY_OR_BLURRY": "Dirty / blurry lens",
    "PARTIAL_OCCLUSION": "Partial occlusion",
}

# Reasons an engineer can give when the detection was wrong ("Normal / false detection")
REASON_LABELS = {"OLD_CAMERA": "Old camera (expected for this unit)",
                 "OK": "OK - nothing wrong, the scene caused it",
                 **{k: v for k, v in STATUS_LABELS.items() if k != "OK"}}


# ---------------------------------------------------------------------------
# THEME HELPERS (look only)
# ---------------------------------------------------------------------------
def _find_logo():
    """Company logo: drop static/logo.svg or static/logo.png in place and it is
    used in the header and as the browser-tab icon. None if neither exists."""
    static_dir = os.path.join(app.root_path, "static")
    for name in ("logo.svg", "logo.png"):
        if os.path.exists(os.path.join(static_dir, name)):
            return name
    return None


def _plural(n, word):
    return f"{n} {word}{'' if n == 1 else 's'}"


def _status_summary():
    """Short live status line for the header, e.g. '8 cameras monitored · 2 need attention'."""
    try:
        n_cams = db.count_cameras(active_only=True)
        if n_cams == 0:
            return {"text": "No cameras yet", "error": False}
        counts = db.latest_status_counts()
        no_view = counts.get("NO_VIEW", 0)
        attention = sum(n for s, n in counts.items() if s not in ("OK", "NO_VIEW"))
        parts = [_plural(n_cams, "camera") + " monitored"]
        if no_view:
            parts.append(f"{no_view} with no view")
        if attention:
            parts.append(f"{attention} need{'s' if attention == 1 else ''} attention")
        prog = capture.progress()
        if prog["running"]:
            parts.append(f"diagnosing {prog['done']} / {prog['total']}")
        return {"text": " · ".join(parts), "error": no_view > 0}
    except Exception:
        return {"text": "Status unavailable", "error": True}


@app.context_processor
def inject_theme():
    return {"logo_file": _find_logo(), "status_summary": _status_summary()}


@app.route("/api/status")
def api_status():
    return jsonify(_status_summary())


@app.route("/api/progress")
def api_progress():
    return jsonify(capture.progress())


@app.route("/")
def index():
    return redirect(url_for("diagnose"))


def _back(default_endpoint):
    return redirect(request.referrer or url_for(default_endpoint))


# ---------------------------------------------------------------------------
# SETTINGS > CAMERAS (list)
# ---------------------------------------------------------------------------
@app.route("/settings")
def settings():
    q = request.args.get("q", "").strip()
    terminal = request.args.get("terminal") or None
    try:
        page = max(int(request.args.get("page", 1)), 1)
    except ValueError:
        page = 1
    total = db.count_cameras(terminal=terminal, search=q or None)
    pages = max((total + PAGE_SIZE - 1) // PAGE_SIZE, 1)
    page = min(page, pages)
    cameras = db.list_cameras(terminal=terminal, search=q or None,
                              limit=PAGE_SIZE, offset=(page - 1) * PAGE_SIZE)
    return render_template(
        "settings.html", section="cameras", cameras=cameras, total=total,
        total_all=db.count_cameras(), page=page, pages=pages, page_size=PAGE_SIZE,
        q=q, terminal=terminal, terminals=db.list_terminals(), no_terminal=db.NO_TERMINAL,
    )


# ---------------------------------------------------------------------------
# SETTINGS > ADD / EDIT CAMERA
# ---------------------------------------------------------------------------
def _camera_form_data(form):
    return {
        "terminal": form.get("terminal", "").strip(),
        "machine_name": form.get("machine_name", "").strip(),
        "camera_name": form.get("camera_name", "").strip(),
        "ip": form.get("ip", "").strip(),
        "username": form.get("username", "").strip(),
        "password": form.get("password", ""),
        "rtsp_path": form.get("rtsp_path", "").strip() or "/Streaming/Channels/101",
        "description": form.get("description", "").strip(),
    }


def _validate_camera(data):
    labels = {"terminal": "Terminal", "machine_name": "Machine name",
              "camera_name": "Camera name", "ip": "Camera IP"}
    missing = [label for key, label in labels.items() if not data[key]]
    return f"Please fill in: {', '.join(missing)}." if missing else None


def _form_page(mode, cam, camera_id=None):
    return render_template(
        "settings_form.html", section="add" if mode == "add" else "cameras", mode=mode,
        cam=cam, camera_id=camera_id, terminals=db.list_terminals(), machines=db.list_machines(),
    )


@app.route("/settings/add", methods=["GET", "POST"])
def settings_add():
    if request.method == "POST":
        data = _camera_form_data(request.form)
        error = _validate_camera(data)
        if error:
            flash(error, "error")
            return _form_page("add", data)
        res = db.add_camera(**data)
        if res["restored"]:
            flash("Camera added. A removed camera with the same terminal, machine and camera name existed, "
                  "so its previous inspections and reports are linked to this camera again.", "success")
        else:
            flash("Camera added.", "success")
        return redirect(url_for("settings_add"))
    return _form_page("add", None)


@app.route("/settings/edit/<int:camera_id>", methods=["GET", "POST"])
def settings_edit(camera_id):
    cam = db.get_camera(camera_id)
    if not cam or cam.get("deleted"):
        flash("That camera no longer exists.", "warning")
        return redirect(url_for("settings"))
    if request.method == "POST":
        data = _camera_form_data(request.form)
        error = _validate_camera(data)
        if error:
            flash(error, "error")
            return _form_page("edit", {**cam, **data, "active": 1 if request.form.get("active") else 0}, camera_id)
        if not request.form.get("password"):
            del data["password"]                     # empty = keep the current password
        data["active"] = 1 if request.form.get("active") else 0
        db.update_camera(camera_id, **data)
        flash(f"Saved changes to {data['camera_name']}.", "success")
        return redirect(url_for("settings"))
    return _form_page("edit", cam, camera_id)


@app.route("/settings/delete/<int:camera_id>", methods=["POST"])
def settings_delete(camera_id):
    result = db.delete_camera(camera_id)
    if result["cameras"]:
        flash(f"Camera removed. Its {_plural(result['inspections'], 'previous inspection')} and reports are kept.", "info")
    else:
        flash("That camera was already removed.", "warning")
    return _back("settings")


@app.route("/settings/delete_selected", methods=["POST"])
def settings_delete_selected():
    """Delete the ticked cameras - or EVERY camera matching the current search / terminal filter."""
    q = request.form.get("q", "").strip()
    terminal = request.form.get("terminal") or None
    if request.form.get("scope") == "filtered":
        ids = db.list_camera_ids(terminal=terminal, search=q or None)
    else:
        ids = [int(x) for x in request.form.getlist("camera_ids") if x.isdigit()]
    if not ids:
        flash("No cameras selected.", "warning")
    else:
        try:
            result = db.delete_cameras(ids)
            flash(f"Removed {_plural(result['cameras'], 'camera')}. Their {_plural(result['inspections'], 'previous inspection')} and reports are kept.", "success")
        except Exception as e:
            flash(f"Nothing was deleted: {e}", "error")
    return redirect(url_for("settings", q=q or None, terminal=terminal))


@app.route("/settings/toggle/<int:camera_id>", methods=["POST"])
def settings_toggle(camera_id):
    cam = db.get_camera(camera_id)
    if cam and not cam.get("deleted"):
        db.update_camera(camera_id, active=0 if cam["active"] else 1)
    return _back("settings")


@app.route("/settings/test/<int:camera_id>", methods=["POST"])
def settings_test(camera_id):
    """Manual trigger: capture + diagnose this one camera right now."""
    inspection_id = capture.run_inspection_for_camera(camera_id)
    if inspection_id:
        flash("Test capture complete — check the Diagnose tab.", "success")
    else:
        flash("Camera is inactive or not found.", "warning")
    return _back("settings")


# ---------------------------------------------------------------------------
# SETTINGS > IMPORT (Excel / CSV)
# ---------------------------------------------------------------------------
@app.route("/settings/import", methods=["GET", "POST"])
def settings_import():
    if request.method == "GET":
        return render_template("settings_import.html", section="import", result=None, total_cameras=db.count_cameras())
    upload = request.files.get("file")
    update_existing = request.form.get("existing") == "update"
    if not upload or not upload.filename:
        flash("Choose an Excel (.xlsx) or CSV file first.", "error")
        return redirect(url_for("settings_import"))
    try:
        rows, problems, info = importer.read_cameras(upload.filename, upload.read())
        outcome = db.bulk_import_cameras(rows, update_existing=update_existing)
    except importer.ImportFileError as e:
        flash(str(e), "error")
        return redirect(url_for("settings_import"))
    except Exception as e:
        flash(f"Import failed and nothing was changed: {e}", "error")
        return redirect(url_for("settings_import"))
    result = {**outcome, "problems": problems, "info": info, "filename": upload.filename,
              "update_existing": update_existing, "shown_problems": problems[:200]}
    return render_template("settings_import.html", section="import", result=result, total_cameras=db.count_cameras())


@app.route("/settings/import/template")
def settings_import_template():
    return send_file(io.BytesIO(importer.build_template()), as_attachment=True,
                     download_name="camera_import_template.xlsx",
                     mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")


@app.errorhandler(413)
def too_large(_e):
    flash("That file is too large (limit 20 MB). Split it into smaller files.", "error")
    return redirect(url_for("settings_import"))


# ---------------------------------------------------------------------------
# SETTINGS > SCHEDULE
# ---------------------------------------------------------------------------
@app.route("/settings/schedule", methods=["GET", "POST"])
def settings_schedule():
    if request.method == "POST":
        time_text = request.form.get("schedule_time", "").strip()
        pause_text = request.form.get("pause_seconds", "").strip()
        if not _valid_time(time_text) or not pause_text.isdigit() or not 0 <= int(pause_text) <= 600:
            flash("Enter a start time (HH:MM) and a pause between 0 and 600 seconds.", "error")
            return _schedule_page(time_text or DEFAULT_TIME, pause_text or str(_pause_seconds()))
        workers_text = request.form.get("workers", "").strip()
        if not workers_text.isdigit() or not 1 <= int(workers_text) <= capture.MAX_WORKERS:
            flash(f"Cameras at the same time must be between 1 and {capture.MAX_WORKERS}.", "error")
            return _schedule_page(time_text, pause_text, workers_text)
        hour, minute = _parse_time(time_text)
        freq, error = _read_frequency(request.form, hour, minute)
        if error:
            flash(error, "error")
            return _schedule_page(time_text, pause_text, workers_text, sched=freq)
        db.set_setting("schedule_time", f"{hour:02d}:{minute:02d}")
        db.set_setting("pause_seconds", int(pause_text))
        db.set_setting("workers", int(workers_text))
        db.set_setting("schedule_frequency", freq["frequency"])
        db.set_setting("schedule_every_days", freq["every_days"])
        db.set_setting("schedule_weekdays", ",".join(freq["weekdays"]))
        db.set_setting("schedule_month_day", freq["month_day"])
        db.set_setting("schedule_start_date", freq["start_date"].isoformat())
        _save_daily_rules(request.form)
        on = set(request.form.getlist("detect"))
        db.set_setting("disabled_detections", json.dumps([k for k, _ in diagnosis.SWITCHABLE if k not in on]))
        _refresh_schedule()
        flash(f"Schedule saved — the inspection runs {capture.describe_schedule(**_schedule_config())}.", "success")
        return redirect(url_for("settings_schedule"))
    hour, minute = _parse_time(db.get_setting("schedule_time", DEFAULT_TIME))
    return _schedule_page(f"{hour:02d}:{minute:02d}", str(_pause_seconds()))


def _read_frequency(form, hour, minute):
    """Frequency fields of the Schedule form -> (schedule dict, error text or None)."""
    freq = {"hour": hour, "minute": minute,
            "frequency": form.get("frequency", "daily"),
            "every_days": (form.get("every_days") or "").strip(),
            "weekdays": [d for d in form.getlist("weekdays") if d in dict(capture.WEEKDAYS)],
            "month_day": (form.get("month_day") or "1").strip(),
            "start_date": _parse_date(form.get("start_date"))}
    error = None
    if freq["frequency"] not in dict(capture.FREQUENCIES):
        freq["frequency"], error = "daily", "Choose how often the inspection runs."
    if freq["frequency"] == "every_n":
        if not freq["every_days"].isdigit() or not 2 <= int(freq["every_days"]) <= capture.MAX_EVERY_DAYS:
            error = f"\"Every N days\" needs a number of days between 2 and {capture.MAX_EVERY_DAYS}."
        if not freq["start_date"]:
            error = error or "Choose the date of the first run (Starting on)."
    if freq["frequency"] == "weekly" and not freq["weekdays"]:
        error = "Tick at least one weekday for a weekly inspection."
    if freq["month_day"] != "last" and not (freq["month_day"].isdigit() and 1 <= int(freq["month_day"]) <= 28):
        freq["month_day"] = "1"
    saved = _schedule_config()                   # fields of the other frequencies keep their saved values
    try:
        freq["every_days"] = int(freq["every_days"])
    except ValueError:
        freq["every_days"] = saved["every_days"]
    freq["start_date"] = freq["start_date"] or saved["start_date"]
    freq["weekdays"] = freq["weekdays"] or saved["weekdays"]
    return freq, error


def _save_daily_rules(form):
    """Daily inspection switch + which terminals / machines take part (unticked ones are skipped)."""
    included = set(form.getlist("include"))
    skip_terminals, skip_machines = [], []
    for t in _group_tree():
        values = [f"{t['value']}||{m['name']}" for m in t["machines"]]
        ticked = [v for v in values if v in included]
        if not ticked:
            skip_terminals.append(t["value"])             # the whole terminal is off (also machines added later)
        else:
            skip_machines += [v for v in values if v not in included]
    db.set_daily_rules(bool(form.get("daily_enabled")), skip_terminals, skip_machines)


def _schedule_page(time_value, pause_value, workers_value=None, sched=None):
    job = scheduler.get_job(capture.DAILY_JOB_ID)
    next_run = getattr(job, "next_run_time", None)
    rules = db.get_daily_rules()
    cameras = len(db.scheduled_cameras()) if rules["enabled"] else 0
    pause = int(pause_value) if str(pause_value).isdigit() else _pause_seconds()
    workers_value = str(workers_value if workers_value is not None else capture._worker_limit())
    workers = int(workers_value) if workers_value.isdigit() else capture.DEFAULT_WORKERS
    norm = lambda v: " ".join((v or "").split()).lower()
    skip_t = {norm(t) for t in rules["skip_terminals"]}
    skip_m = {(norm(v.partition("||")[0]), norm(v.partition("||")[2])) for v in rules["skip_machines"]}
    tree = _group_tree()
    for t in tree:
        for m in t["machines"]:
            m["on"] = norm(t["value"]) not in skip_t and (norm(t["value"]), norm(m["name"])) not in skip_m
        t["on_count"] = sum(m["count"] for m in t["machines"] if m["on"])
    sched = sched or _schedule_config()
    return render_template(
        "settings_schedule.html", section="schedule", time_value=time_value, pause_value=pause_value,
        workers_value=workers_value, max_workers=capture.MAX_WORKERS, rules=rules, tree=tree,
        sched=sched, frequencies=capture.FREQUENCIES, weekdays=capture.WEEKDAYS, max_every_days=capture.MAX_EVERY_DAYS,
        sched_text=capture.describe_schedule(**_schedule_config()),
        detections=[{"key": k, "label": l, "on": k not in capture.disabled_detections()} for k, l in diagnosis.SWITCHABLE],
        cameras=cameras, estimate=_duration_text(cameras, pause, workers), per_capture=SECONDS_PER_CAPTURE,
        next_run=next_run.strftime("%A %d %B, %H:%M") if next_run else "—",
        last_run=(db.get_setting("last_run_started") or "").replace("T", " ") or "—",
    )


# ---------------------------------------------------------------------------
# DIAGNOSE TAB
# ---------------------------------------------------------------------------
def _read_filters(args):
    def as_int(v):
        try:
            return int(v)
        except (TypeError, ValueError):
            return None

    def as_pct(v):
        try:
            return max(0.0, min(100.0, float(v)))
        except (TypeError, ValueError):
            return None

    def many(name):                      # a filter may hold several values: ?machine=A101&machine=A102
        seen = []
        for v in args.getlist(name):
            v = (v or "").strip()
            if v and v not in seen:
                seen.append(v)
        return seen

    filters = {
        "status": [s for s in many("status") if s in STATUS_LABELS],
        "camera_id": [int(v) for v in many("camera_id") if v.isdigit()],
        "terminal": many("terminal"),
        "machine": many("machine"),
        "date_from": args.get("date_from") or None,         # typed in Dubai time; converted in _db_filters
        "date_to": args.get("date_to") or None,
        "latest_only": args.get("view") == "latest",
        "verdict": [v for v in many("verdict") if v in inspection_query.VERDICT_KEYS],
        "conf_min": as_pct(args.get("conf_min")), "conf_max": as_pct(args.get("conf_max")),
        "learned_min": as_pct(args.get("learned_min")), "learned_max": as_pct(args.get("learned_max")),
        "last": (lambda n: n if n and n > 0 else None)(as_int(args.get("last"))),
    }
    sort = {"sort_by": args.get("sort_by", "timestamp"), "sort_dir": args.get("sort_dir", "desc")}
    return filters, sort


def _db_filters(filters):
    """The filters as the database wants them: date boxes (Dubai time) turned into stored UTC text."""
    out = dict(filters)
    out["date_from"] = timeutil.local_input_to_utc(filters.get("date_from"))
    out["date_to"] = timeutil.local_input_to_utc(filters.get("date_to"), end=True)
    return out


def _group_tree():
    """Terminal -> machines (with camera counts) for the 'Run diagnosis now' picker."""
    tree = {}
    for g in db.list_camera_groups():
        t = (g["terminal"] or "").strip()
        node = tree.setdefault(t, {"value": t, "label": t or "No terminal", "machines": [], "count": 0})
        node["machines"].append({"name": g["machine_name"], "count": g["n"]})
        node["count"] += g["n"]
    for node in tree.values():
        node["machines"].sort(key=lambda m: db.natural_key(m["name"]))
    return sorted(tree.values(), key=lambda n: (n["value"] == "", db.natural_key(n["value"])))


VERDICT_FILTERS = [("awaiting", "No engineer verdict yet"), ("verified", "Verified by an engineer"),
                   ("auto", "Auto-matched"), ("worse", "Worse than last check")]


def _filter_options(filters):
    """Choices for the multi-select filters. Machines and cameras follow the chosen terminals (and machines);
    anything already chosen always stays in its list."""
    terms = filters["terminal"]
    terminal_opts = [(t, t) for t in db.list_terminals(include_deleted=True)] + [(db.NO_TERMINAL, "No terminal")]
    if terms:
        names = set()
        for t in terms:
            names.update(db.list_machines(t, include_deleted=True))
    else:
        names = set(db.list_machines(None, include_deleted=True))
    names.update(filters["machine"])
    machine_opts = [(m, m) for m in sorted(names, key=db.natural_key)]
    chosen_cams = set(filters["camera_id"])
    camera_opts = []
    for c in db.list_cameras(include_deleted=True):
        t = (c.get("terminal") or "").strip() or db.NO_TERMINAL
        in_scope = (not terms or t in terms) and (not filters["machine"] or c["machine_name"] in filters["machine"])
        if in_scope or c["id"] in chosen_cams:
            label = " / ".join(x for x in (c.get("terminal"), c["machine_name"], c["camera_name"]) if x)
            camera_opts.append((str(c["id"]), label + (" (removed)" if c.get("deleted") else "")))
    return {"terminal": terminal_opts, "machine": machine_opts, "camera_id": camera_opts,
            "status": list(STATUS_LABELS.items()), "verdict": VERDICT_FILTERS}


@app.route("/diagnose")
def diagnose():
    filters, sort = _read_filters(request.args)
    dbf = _db_filters(filters)
    summary = inspection_query.inspection_summary(**dbf)
    inspections = inspection_query.list_inspections(**dbf, **sort, limit=DISPLAY_LIMIT)
    fb_map = db.get_feedback_by_inspection_ids([i["id"] for i in inspections])
    for insp in inspections:
        insp["metrics"] = json.loads(insp["metrics_json"] or "{}")
        insp["feedback"] = fb_map.get(insp["id"])
        insp["final"] = insp.get("final_status") or insp["status"]        # what is reported: detection or engineer's correction
        insp["status_label"] = STATUS_LABELS.get(insp["final"], insp["final"])
        insp["detected_label"] = STATUS_LABELS.get(insp["status"], insp["status"])

    selected = {k: {str(v) for v in filters[k]} for k in ("terminal", "machine", "camera_id", "status", "verdict")}
    return render_template(
        "diagnose.html", inspections=inspections, summary=summary, shown=len(inspections),
        options=_filter_options(filters), selected=selected,
        no_terminal=db.NO_TERMINAL, tree=_group_tree(), pause_seconds=_pause_seconds(),
        status_labels=STATUS_LABELS, verdict_labels=VERDICT_LABELS,
        verdict_choices=VERDICT_CHOICES, reason_labels=REASON_LABELS,
        f=filters, current_view="latest" if filters["latest_only"] else "all", **sort,
    )


@app.route("/diagnose/run", methods=["POST"])
def diagnose_run():
    """'Run diagnosis now': queue every active camera in the ticked terminals / machines."""
    pairs = []
    for value in request.form.getlist("groups"):
        terminal, _, machine = value.partition("||")
        pairs.append((terminal, machine))
    cameras = db.cameras_for_groups(pairs)
    if not cameras:
        flash("Tick at least one terminal or machine that has active cameras.", "warning")
        return redirect(url_for("diagnose"))
    added, skipped = capture.enqueue([c["id"] for c in cameras])
    text = f"Queued {_plural(added, 'camera')} for diagnosis. They are captured a few at a time; results appear below."
    if skipped:
        text += f" ({skipped} already waiting in the queue.)"
    flash(text, "success")
    return redirect(url_for("diagnose"))


@app.route("/diagnose/stop", methods=["POST"])
def diagnose_stop():
    removed = capture.cancel_pending()
    flash(f"Stopped — {_plural(removed, 'camera')} removed from the queue.", "info")
    return redirect(url_for("diagnose"))


@app.route("/diagnose/<int:inspection_id>/feedback", methods=["POST"])
def diagnose_feedback(inspection_id):
    verdict = request.form["verdict"]
    if verdict not in VERDICT_LABELS:
        return "Unknown verdict", 400
    reason = request.form.get("reason", "").strip() if verdict == "normal" else ""
    if verdict == "normal" and reason not in REASON_LABELS:
        reason = "OK"                                # no reason chosen: the picture itself was fine
    comment = request.form.get("comment", "").strip()
    engineer_name = request.form.get("engineer_name", "").strip()
    db.add_feedback(inspection_id, verdict, comment, engineer_name, reason=reason)
    if request.headers.get("X-Requested-With") == "fetch":
        # saved from the Diagnose page without reloading it (so the page keeps its scroll position)
        insp = db.get_inspection(inspection_id) or {}
        fb = db.get_feedback_for_inspection(inspection_id) or {}
        final = insp.get("final_status") or insp.get("status")
        sev = "ok" if final == "OK" else ("error" if final == "NO_VIEW" else "attention")
        return jsonify({
            "ok": True,
            "verdict": VERDICT_LABELS.get(verdict, verdict),
            "reason": REASON_LABELS.get(reason, reason) if reason else "",
            "comment": comment,
            "engineer": engineer_name or "unnamed",
            "when": timeutil.fmt(fb.get("created_at")),
            "final_label": STATUS_LABELS.get(final, final),
            "detected_label": STATUS_LABELS.get(insp.get("status"), insp.get("status")),
            "changed": final != insp.get("status"),
            "sev": sev,
        })
    flash("Feedback recorded.", "success")
    return _back("diagnose")


@app.template_filter("local")
def _local_time(value, seconds=True):
    """Stored UTC time -> Dubai time text."""
    return timeutil.fmt(value, seconds)


@app.route("/diagnose/delete_selected", methods=["POST"])
def diagnose_delete_selected():
    """Delete the ticked inspections for good - with their verdicts and their picture files."""
    ids = [int(x) for x in request.form.getlist("inspection_ids") if x.isdigit()]
    if not ids:
        flash("No inspections selected.", "warning")
        return _back("diagnose")
    try:
        n = db.delete_inspections(ids)
        flash(f"Deleted {_plural(n, 'inspection')} with their verdicts and pictures.", "success")
    except Exception as e:
        flash(f"Nothing was deleted: {e}", "error")
    return _back("diagnose")


@app.route("/diagnose/<int:inspection_id>/image")
def diagnose_image(inspection_id):
    insp = db.get_inspection(inspection_id)
    if not insp or not insp.get("image_path") or not os.path.exists(insp["image_path"]):
        return "No image", 404
    return send_file(insp["image_path"])


@app.route("/diagnose/<int:inspection_id>/report")
def diagnose_report(inspection_id):
    path = report.generate_single_report(inspection_id)
    return send_file(path, as_attachment=True)


@app.route("/diagnose/export", methods=["POST"])
def diagnose_export():
    """PDF of the inspections whose checkboxes are ticked."""
    ids = [int(x) for x in request.form.getlist("inspection_ids")]
    if not ids:
        flash("No inspections selected.", "warning")
        return _back("diagnose")
    return send_file(report.generate_batch_report(ids), as_attachment=True)


@app.route("/diagnose/export_filtered")
def diagnose_export_filtered():
    """PDF of EVERYTHING matching the current filters (terminal, machine, dates, ...)."""
    filters, sort = _read_filters(request.args)
    filters = _db_filters(filters)
    total = inspection_query.inspection_summary(**filters)["total"]
    if total == 0:
        flash("Nothing matches these filters, so there is no report to download.", "warning")
        return redirect(url_for("diagnose", **request.args.to_dict(flat=False)))
    if total > MAX_REPORT_ROWS:
        flash(f"{total:,} inspections match; one report holds at most {MAX_REPORT_ROWS:,}. "
              "Narrow the filters (fewer terminals, a date range, or 'Latest per camera').", "warning")
        return redirect(url_for("diagnose", **request.args.to_dict(flat=False)))
    rows = inspection_query.list_inspections(**filters, **sort, limit=MAX_REPORT_ROWS)
    return send_file(report.generate_batch_report([r["id"] for r in rows]), as_attachment=True)


@app.route("/diagnose/export_csv")
def diagnose_export_csv():
    filters, sort = _read_filters(request.args)
    inspections = inspection_query.list_inspections(**_db_filters(filters), **sort, limit=50000)
    fb_map = db.get_feedback_by_inspection_ids([i["id"] for i in inspections])

    buf = io.StringIO()
    writer = csv.writer(buf)
    writer.writerow(["Terminal", "Machine", "Camera", "IP", "Timestamp (Dubai)", "Final status", "Detected status",
                     "Detection confidence",
                     "Learned confidence", "Learned result", "Auto-matched", "Worse than last check",
                     "Verdict", "Reason", "Comment", "Engineer"])
    for i in inspections:
        fb = fb_map.get(i["id"])
        writer.writerow([
            i["terminal"] or "", i["machine_name"], i["camera_name"], i["ip"], timeutil.fmt(i["timestamp"]),
            i.get("final_status") or i["status"], i["status"], i["confidence"],
            "" if i.get("learned_confidence") is None else i["learned_confidence"], i.get("learned_status") or "",
            bool(i["auto_matched"]), bool(i.get("worse_flag")),
            fb["verdict"] if fb else "", (fb.get("reason") or "") if fb else "", fb["comment"] if fb else "",
            fb["engineer_name"] if fb else "",
        ])
    return app.response_class(
        buf.getvalue(), mimetype="text/csv",
        headers={"Content-Disposition": "attachment; filename=inspections.csv"},
    )


@app.route("/api/run_all_now", methods=["POST"])
def api_run_all_now():
    return jsonify({"ok": True, "queued": capture.run_all_inspections()})


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5070, debug=False, use_reloader=False)
