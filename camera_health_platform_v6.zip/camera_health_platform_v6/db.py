"""
SQLite storage layer for the camera health platform.
Everything is local - no external DB server needed (offline-friendly).
Existing databases are upgraded automatically (new columns/tables are added
on start-up; your cameras and inspection history are kept).
"""
import sqlite3
import json
import os
import re
from datetime import datetime

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "camera_platform.db")
SCREENSHOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "screenshots")
NO_TERMINAL = "__none__"      # filter value meaning "cameras without a terminal"

SCHEMA = """
CREATE TABLE IF NOT EXISTS cameras (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    machine_name TEXT NOT NULL,
    camera_name TEXT NOT NULL,
    ip TEXT NOT NULL,
    username TEXT,
    password TEXT,
    rtsp_path TEXT DEFAULT '/Streaming/Channels/101',
    description TEXT,
    active INTEGER DEFAULT 1,
    created_at TEXT
);

CREATE TABLE IF NOT EXISTS inspections (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    camera_id INTEGER NOT NULL,
    timestamp TEXT NOT NULL,
    image_path TEXT,
    status TEXT,
    confidence REAL,
    metrics_json TEXT,
    auto_matched INTEGER DEFAULT 0,
    matched_from_inspection_id INTEGER,
    worse_flag INTEGER DEFAULT 0,
    learned_confidence REAL,
    learned_status TEXT,
    final_status TEXT,
    FOREIGN KEY(camera_id) REFERENCES cameras(id)
);

CREATE TABLE IF NOT EXISTS feedback (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    inspection_id INTEGER NOT NULL,
    verdict TEXT NOT NULL,          -- 'same' | 'normal' (false detection) | older: 'old_camera' | 'other'
    reason TEXT,                    -- for 'normal': OLD_CAMERA | OK | a detection code such as DIRTY_OR_BLURRY
    comment TEXT,
    engineer_name TEXT,
    created_at TEXT,
    FOREIGN KEY(inspection_id) REFERENCES inspections(id)
);

CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT
);
"""

INDEXES = """
CREATE INDEX IF NOT EXISTS idx_insp_camera   ON inspections(camera_id, timestamp);
CREATE INDEX IF NOT EXISTS idx_insp_status   ON inspections(status);
CREATE INDEX IF NOT EXISTS idx_fb_inspection ON feedback(inspection_id);
CREATE INDEX IF NOT EXISTS idx_cam_terminal  ON cameras(terminal);
CREATE INDEX IF NOT EXISTS idx_insp_time     ON inspections(timestamp);
"""


def get_conn():
    conn = sqlite3.connect(DB_PATH, timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db():
    conn = get_conn()
    conn.executescript(SCHEMA)
    cols = {r["name"] for r in conn.execute("PRAGMA table_info(cameras)")}
    if "terminal" not in cols:                       # upgrade older databases
        conn.execute("ALTER TABLE cameras ADD COLUMN terminal TEXT DEFAULT ''")
    if "deleted" not in cols:                        # "removed" cameras keep their history
        conn.execute("ALTER TABLE cameras ADD COLUMN deleted INTEGER DEFAULT 0")
        conn.execute("ALTER TABLE cameras ADD COLUMN deleted_at TEXT")
    icols = {r["name"] for r in conn.execute("PRAGMA table_info(inspections)")}
    if "worse_flag" not in icols:
        conn.execute("ALTER TABLE inspections ADD COLUMN worse_flag INTEGER DEFAULT 0")
    if "learned_confidence" not in icols:
        conn.execute("ALTER TABLE inspections ADD COLUMN learned_confidence REAL")
    if "learned_status" not in icols:
        conn.execute("ALTER TABLE inspections ADD COLUMN learned_status TEXT")
    need_final = "final_status" not in icols
    if need_final:
        conn.execute("ALTER TABLE inspections ADD COLUMN final_status TEXT")
    if "reason" not in {r["name"] for r in conn.execute("PRAGMA table_info(feedback)")}:
        conn.execute("ALTER TABLE feedback ADD COLUMN reason TEXT")
    if need_final:                                   # work out the final status of everything already stored
        rows = conn.execute(
            """SELECT i.id, i.status, f.verdict, f.reason FROM inspections i
               LEFT JOIN feedback f ON f.id = (SELECT id FROM feedback WHERE inspection_id = i.id
                                               ORDER BY created_at DESC, id DESC LIMIT 1)""").fetchall()
        conn.executemany("UPDATE inspections SET final_status = ? WHERE id = ?",
                         [(final_status_for(r["status"], r["verdict"], r["reason"]), r["id"]) for r in rows])
    conn.executescript(INDEXES)
    try:
        conn.execute("PRAGMA journal_mode=WAL")      # lets the background worker and the web pages write together
    except sqlite3.DatabaseError:
        pass
    conn.commit()
    conn.close()


def effective_status(verdict, reason, detected):
    """What an engineer's verdict means for a picture: 'OK', 'OLD_CAMERA' or a detection code."""
    if verdict == "normal":
        return reason or "OK"
    if verdict == "old_camera":
        return "OLD_CAMERA"
    return detected                                      # 'same' / 'other': the detection stands


def final_status_for(detected, verdict=None, reason=None):
    """The status that is reported: the platform's detection unless an engineer's verdict corrects it."""
    if not verdict:
        return detected
    eff = effective_status(verdict, reason, detected)
    return "OK" if eff == "OLD_CAMERA" else eff


def natural_key(text):
    """Sort 'Terminal 2' before 'Terminal 10'."""
    return [int(t) if t.isdigit() else t.lower() for t in re.split(r"(\d+)", text or "")]


# ---------------- Settings (key / value) ----------------

def get_setting(key, default=None):
    conn = get_conn()
    row = conn.execute("SELECT value FROM settings WHERE key = ?", (key,)).fetchone()
    conn.close()
    return row["value"] if row else default


def set_setting(key, value):
    conn = get_conn()
    conn.execute("INSERT INTO settings (key, value) VALUES (?, ?) "
                 "ON CONFLICT(key) DO UPDATE SET value = excluded.value", (key, str(value)))
    conn.commit()
    conn.close()


# ---------------- Cameras ----------------

CAMERA_FIELDS = {"machine_name", "camera_name", "terminal", "ip", "username", "password",
                 "rtsp_path", "description", "active"}


def add_camera(machine_name, camera_name, ip, username, password, rtsp_path, description, terminal=""):
    """Add a camera.  If a REMOVED camera has the same terminal + machine + camera name, it is
    brought back with the new details (new brand / IP ...) and keeps all its old inspections.
    Returns {'id': camera id, 'restored': True/False}."""
    conn = get_conn()
    try:
        key = _key(terminal, machine_name, camera_name)
        for r in conn.execute("SELECT id, terminal, machine_name, camera_name FROM cameras WHERE deleted = 1"):
            if _key(r["terminal"], r["machine_name"], r["camera_name"]) == key:
                conn.execute(
                    """UPDATE cameras SET machine_name=?, camera_name=?, terminal=?, ip=?, username=?, password=?,
                       rtsp_path=?, description=?, active=1, deleted=0, deleted_at=NULL WHERE id=?""",
                    (machine_name, camera_name, terminal, ip, username, password, rtsp_path, description, r["id"]))
                conn.commit()
                return {"id": r["id"], "restored": True}
        cur = conn.execute(
            """INSERT INTO cameras (machine_name, camera_name, terminal, ip, username, password,
               rtsp_path, description, created_at) VALUES (?,?,?,?,?,?,?,?,?)""",
            (machine_name, camera_name, terminal, ip, username, password, rtsp_path, description,
             datetime.utcnow().isoformat()),
        )
        conn.commit()
        return {"id": cur.lastrowid, "restored": False}
    finally:
        conn.close()


def update_camera(camera_id, **fields):
    fields = {k: v for k, v in fields.items() if k in CAMERA_FIELDS}
    if not fields:
        return
    conn = get_conn()
    cols = ", ".join(f"{k} = ?" for k in fields)
    conn.execute(f"UPDATE cameras SET {cols} WHERE id = ?", (*fields.values(), camera_id))
    conn.commit()
    conn.close()


def _chunks(items, size=500):
    """SQLite allows only a limited number of ? placeholders, so work in chunks."""
    for start in range(0, len(items), size):
        yield items[start:start + size]


def delete_cameras(camera_ids):
    """Remove cameras from the platform but KEEP their inspections, engineer verdicts and
    screenshots (the camera is only marked as removed and no longer inspected).  Adding a
    camera with the same terminal + machine + camera name later brings the history back.
    Returns {'cameras': n, 'inspections': m (history kept)}."""
    ids = [int(i) for i in camera_ids]
    if not ids:
        return {"cameras": 0, "inspections": 0}
    n_cam = n_insp = 0
    now = datetime.utcnow().isoformat()
    conn = get_conn()
    try:
        for chunk in _chunks(ids):
            ph = ",".join("?" for _ in chunk)
            n_insp += conn.execute(f"SELECT COUNT(*) FROM inspections i JOIN cameras c ON c.id = i.camera_id "
                                   f"WHERE c.id IN ({ph}) AND c.deleted = 0", chunk).fetchone()[0]
            n_cam += conn.execute(f"UPDATE cameras SET deleted = 1, deleted_at = ?, active = 0 "
                                  f"WHERE id IN ({ph}) AND deleted = 0", [now, *chunk]).rowcount
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()
    return {"cameras": n_cam, "inspections": n_insp}


def delete_camera(camera_id):
    return delete_cameras([camera_id])


def _remove_screenshots(paths):
    """Remove stored screenshot files - only ever files inside the screenshots folder."""
    root = os.path.abspath(SCREENSHOT_DIR)
    for p in paths:
        try:
            full = os.path.abspath(p)
            if os.path.commonpath([root, full]) == root and os.path.isfile(full):
                os.remove(full)
        except (OSError, ValueError):
            pass


def _camera_where(active_only=False, terminal=None, machine=None, search=None, include_deleted=False):
    where, params = ["1=1"], []
    if not include_deleted:
        where.append("c.deleted = 0")
    if active_only:
        where.append("c.active = 1")
    if terminal == NO_TERMINAL:
        where.append("(c.terminal IS NULL OR c.terminal = '')")
    elif terminal:
        where.append("c.terminal = ?")
        params.append(terminal)
    if machine:
        where.append("c.machine_name = ?")
        params.append(machine)
    if search:
        like = f"%{search}%"
        where.append("(c.machine_name LIKE ? OR c.camera_name LIKE ? OR c.ip LIKE ? OR c.terminal LIKE ?)")
        params += [like] * 4
    return " AND ".join(where), params


def list_cameras(active_only=False, terminal=None, machine=None, search=None, limit=None, offset=0,
                 include_deleted=False):
    where, params = _camera_where(active_only, terminal, machine, search, include_deleted)
    q = (f"SELECT c.* FROM cameras c WHERE {where} "
         "ORDER BY c.terminal COLLATE NOCASE, c.machine_name COLLATE NOCASE, c.camera_name COLLATE NOCASE")
    if limit:
        q += " LIMIT ? OFFSET ?"
        params += [limit, offset]
    conn = get_conn()
    rows = conn.execute(q, params).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def count_cameras(active_only=False, terminal=None, machine=None, search=None):
    where, params = _camera_where(active_only, terminal, machine, search)
    conn = get_conn()
    n = conn.execute(f"SELECT COUNT(*) FROM cameras c WHERE {where}", params).fetchone()[0]
    conn.close()
    return n


def list_camera_ids(terminal=None, machine=None, search=None):
    where, params = _camera_where(False, terminal, machine, search)
    conn = get_conn()
    rows = conn.execute(f"SELECT c.id FROM cameras c WHERE {where}", params).fetchall()
    conn.close()
    return [r["id"] for r in rows]


def _key(terminal, machine, camera):
    norm = lambda v: " ".join((v or "").split()).lower()
    return (norm(terminal), norm(machine), norm(camera))


def bulk_import_cameras(rows, update_existing=False):
    """Insert many cameras in ONE transaction (fast for thousands).
    A camera already exists when terminal + machine + camera name match (ignoring case).
    A removed camera with the same names is brought back (with its history) and counted as 'restored'.
    Returns {'added': n, 'updated': n, 'skipped': n, 'restored': n, 'existing_rows': [row numbers]}."""
    conn = get_conn()
    added = updated = skipped = restored = 0
    existing_rows = []
    try:
        existing, gone = {}, {}
        for r in conn.execute("SELECT id, terminal, machine_name, camera_name, deleted FROM cameras"):
            (gone if r["deleted"] else existing)[_key(r["terminal"], r["machine_name"], r["camera_name"])] = r["id"]
        now = datetime.utcnow().isoformat()
        for row in rows:
            key = _key(row["terminal"], row["machine_name"], row["camera_name"])
            if key in existing:
                existing_rows.append(row["row"])
                if not update_existing:
                    skipped += 1
                    continue
                changes = {k: row[k] for k in ("ip", "username", "password", "rtsp_path", "description")
                           if row.get(k)}                      # an empty cell keeps the current value
                if row.get("active") is not None:
                    changes["active"] = row["active"]
                if changes:
                    cols = ", ".join(f"{k} = ?" for k in changes)
                    conn.execute(f"UPDATE cameras SET {cols} WHERE id = ?", (*changes.values(), existing[key]))
                updated += 1
            elif key in gone:                                  # same names as a removed camera: bring it back
                cid = gone.pop(key)
                conn.execute(
                    """UPDATE cameras SET machine_name=?, camera_name=?, terminal=?, ip=?, username=?, password=?,
                       rtsp_path=?, description=?, active=?, deleted=0, deleted_at=NULL WHERE id=?""",
                    (row["machine_name"], row["camera_name"], row["terminal"], row["ip"],
                     row.get("username", ""), row.get("password", ""),
                     row.get("rtsp_path") or "/Streaming/Channels/101", row.get("description", ""),
                     1 if row.get("active") is None else row["active"], cid))
                existing[key] = cid
                restored += 1
            else:
                cur = conn.execute(
                    """INSERT INTO cameras (machine_name, camera_name, terminal, ip, username, password,
                       rtsp_path, description, active, created_at) VALUES (?,?,?,?,?,?,?,?,?,?)""",
                    (row["machine_name"], row["camera_name"], row["terminal"], row["ip"],
                     row.get("username", ""), row.get("password", ""),
                     row.get("rtsp_path") or "/Streaming/Channels/101", row.get("description", ""),
                     1 if row.get("active") is None else row["active"], now))
                existing[key] = cur.lastrowid
                added += 1
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()
    return {"added": added, "updated": updated, "skipped": skipped, "restored": restored,
            "existing_rows": existing_rows}


def get_camera(camera_id):
    conn = get_conn()
    row = conn.execute("SELECT * FROM cameras WHERE id = ?", (camera_id,)).fetchone()
    conn.close()
    return dict(row) if row else None


def list_terminals(include_deleted=False):
    conn = get_conn()
    rows = conn.execute("SELECT DISTINCT terminal FROM cameras "
                        "WHERE terminal IS NOT NULL AND terminal != ''"
                        + ("" if include_deleted else " AND deleted = 0")).fetchall()
    conn.close()
    return sorted((r["terminal"] for r in rows), key=natural_key)


def list_machines(terminal=None, include_deleted=False):
    where, params = _camera_where(terminal=terminal, include_deleted=include_deleted)
    conn = get_conn()
    rows = conn.execute(f"SELECT DISTINCT c.machine_name FROM cameras c WHERE {where}", params).fetchall()
    conn.close()
    return sorted((r["machine_name"] for r in rows), key=natural_key)


def list_camera_groups():
    """Active cameras counted per (terminal, machine) - used by the 'Run diagnosis now' picker."""
    conn = get_conn()
    rows = conn.execute("SELECT COALESCE(terminal, '') AS terminal, machine_name, COUNT(*) AS n "
                        "FROM cameras WHERE active = 1 AND deleted = 0 GROUP BY COALESCE(terminal, ''), machine_name").fetchall()
    conn.close()
    return [dict(r) for r in rows]


def cameras_for_groups(pairs):
    """Active cameras whose (terminal, machine) is in `pairs` (a list of (terminal, machine))."""
    wanted = {((t or "").strip(), (m or "").strip()) for t, m in pairs}
    return [c for c in list_cameras(active_only=True)
            if ((c.get("terminal") or "").strip(), (c.get("machine_name") or "").strip()) in wanted]


# ---------------- Inspections ----------------

def add_inspection(camera_id, image_path, status, confidence, metrics: dict,
                    auto_matched=False, matched_from_inspection_id=None, worse=False,
                    learned_confidence=None, learned_status=None, final_status=None):
    conn = get_conn()
    cur = conn.execute(
        """INSERT INTO inspections (camera_id, timestamp, image_path, status, confidence,
           metrics_json, auto_matched, matched_from_inspection_id, worse_flag,
           learned_confidence, learned_status, final_status)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
        (camera_id, datetime.utcnow().isoformat(), image_path, status, confidence,
         json.dumps(metrics), int(auto_matched), matched_from_inspection_id, int(worse),
         learned_confidence, learned_status, final_status or status),
    )
    conn.commit()
    inspection_id = cur.lastrowid
    conn.close()
    return inspection_id


def get_inspection(inspection_id):
    conn = get_conn()
    row = conn.execute("SELECT * FROM inspections WHERE id = ?", (inspection_id,)).fetchone()
    conn.close()
    return dict(row) if row else None


def _inspection_where(status=None, camera_id=None, terminal=None, machine=None, date_from=None,
                      date_to=None, latest_only=False, verdict=None, conf_min=None, conf_max=None,
                      learned_min=None, learned_max=None):
    """date_from / date_to must already be stored-UTC text (see timeutil.local_input_to_utc)."""
    where, params = ["1=1"], []
    if status:                         # the FINAL status (detection, or what the engineer corrected it to)
        where.append("COALESCE(i.final_status, i.status) = ?")
        params.append(status)
    if camera_id:
        where.append("i.camera_id = ?")
        params.append(camera_id)
    if terminal == NO_TERMINAL:
        where.append("(c.terminal IS NULL OR c.terminal = '')")
    elif terminal:
        where.append("c.terminal = ?")
        params.append(terminal)
    if machine:
        where.append("c.machine_name = ?")
        params.append(machine)
    if date_from:
        where.append("i.timestamp >= ?")
        params.append(date_from)
    if date_to:
        where.append("i.timestamp <= ?")
        params.append(date_to)
    if verdict == "awaiting":          # a flagged camera that no engineer has looked at yet
        where.append("i.status != 'OK' AND NOT EXISTS (SELECT 1 FROM feedback f WHERE f.inspection_id = i.id)")
    elif verdict == "verified":        # an engineer gave a verdict
        where.append("EXISTS (SELECT 1 FROM feedback f WHERE f.inspection_id = i.id "
                     "AND COALESCE(f.engineer_name, '') != 'auto-match')")
    elif verdict == "auto":
        where.append("i.auto_matched = 1")
    elif verdict == "worse":
        where.append("i.worse_flag = 1")
    for col, lo, hi in (("i.confidence", conf_min, conf_max), ("i.learned_confidence", learned_min, learned_max)):
        if lo is not None:
            where.append(f"{col} >= ?")
            params.append(lo)
        if hi is not None:
            where.append(f"{col} <= ?")
            params.append(hi)
    if latest_only:
        where.append("i.id IN (SELECT MAX(id) FROM inspections GROUP BY camera_id)")
        where.append("c.deleted = 0")
    return " AND ".join(where), params


def _newest_n(where, params, last):
    """Keep only the newest `last` inspections among those matching `where`."""
    if not last:
        return where, params
    sub = ("SELECT i.id FROM inspections i JOIN cameras c ON i.camera_id = c.id "
           f"WHERE {where} ORDER BY i.timestamp DESC, i.id DESC LIMIT ?")
    return f"i.id IN ({sub})", params + [int(last)]


SORT_COLUMNS = {"timestamp": "i.timestamp", "status": "COALESCE(i.final_status, i.status)", "confidence": "i.confidence",
                "learned_confidence": "i.learned_confidence",
                "machine_name": "c.machine_name", "camera_name": "c.camera_name", "terminal": "c.terminal"}


def list_inspections(sort_by="timestamp", sort_dir="desc", limit=200, last=None, **filters):
    where, params = _inspection_where(**filters)
    where, params = _newest_n(where, params, last)
    col = SORT_COLUMNS.get(sort_by, "i.timestamp")
    direction = "ASC" if str(sort_dir).lower() == "asc" else "DESC"
    q = (f"SELECT i.*, c.machine_name, c.camera_name, c.ip, c.terminal, c.deleted AS camera_removed "
         f"FROM inspections i JOIN cameras c ON i.camera_id = c.id WHERE {where} "
         f"ORDER BY {col} {direction}, i.id DESC LIMIT ?")
    conn = get_conn()
    rows = conn.execute(q, params + [limit]).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def inspection_summary(last=None, **filters):
    """Totals over ALL inspections matching the filters (not just the ones shown on screen)."""
    where, params = _inspection_where(**filters)
    where, params = _newest_n(where, params, last)
    q = f"""SELECT COUNT(*) AS total,
                   COALESCE(SUM(CASE WHEN COALESCE(i.final_status, i.status) != 'OK' THEN 1 ELSE 0 END), 0) AS issues,
                   COALESCE(SUM(CASE WHEN i.status != 'OK' AND NOT EXISTS
                        (SELECT 1 FROM feedback f WHERE f.inspection_id = i.id) THEN 1 ELSE 0 END), 0) AS awaiting,
                   COALESCE(SUM(i.auto_matched), 0) AS auto_matched
            FROM inspections i JOIN cameras c ON i.camera_id = c.id WHERE {where}"""
    conn = get_conn()
    row = conn.execute(q, params).fetchone()
    conn.close()
    return dict(row)


def latest_status_counts():
    """{status: number of active cameras whose most recent inspection has that status}
    (the final status: a detection an engineer corrected to OK counts as OK)"""
    conn = get_conn()
    rows = conn.execute(f"""SELECT COALESCE(i.final_status, i.status) AS st,
                                  COUNT(*) AS n FROM inspections i
                           JOIN cameras c ON c.id = i.camera_id
                           WHERE c.active = 1 AND c.deleted = 0
                             AND i.id IN (SELECT MAX(id) FROM inspections GROUP BY camera_id)
                           GROUP BY st""").fetchall()
    conn.close()
    return {r["st"]: r["n"] for r in rows}


def verdict_streak(camera_id, detected, final):
    """How many of this camera's most recent inspections in a row had this detection and this final status
    with a verdict behind them (an engineer's own confirmation or an automatic copy)."""
    conn = get_conn()
    rows = conn.execute(
        """SELECT i.status, COALESCE(i.final_status, i.status) AS fin, i.auto_matched,
                  EXISTS (SELECT 1 FROM feedback f WHERE f.inspection_id = i.id
                          AND COALESCE(f.engineer_name, '') != 'auto-match') AS engineer
           FROM inspections i WHERE i.camera_id = ? ORDER BY i.timestamp DESC, i.id DESC LIMIT 100""",
        (camera_id,)).fetchall()
    conn.close()
    n = 0
    for r in rows:
        if r["status"] == detected and r["fin"] == final and (r["auto_matched"] or r["engineer"]):
            n += 1
        else:
            break
    return n


def delete_inspections(inspection_ids):
    """Delete inspections for good: their engineer verdicts and their stored picture files too.
    Returns the number of inspections removed."""
    ids = [int(i) for i in inspection_ids]
    if not ids:
        return 0
    images, n = [], 0
    conn = get_conn()
    try:
        for chunk in _chunks(ids):
            ph = ",".join("?" for _ in chunk)
            images += [r[0] for r in conn.execute(
                f"SELECT image_path FROM inspections WHERE id IN ({ph}) AND image_path IS NOT NULL", chunk)]
            conn.execute(f"UPDATE inspections SET matched_from_inspection_id = NULL "
                         f"WHERE matched_from_inspection_id IN ({ph})", chunk)
            conn.execute(f"DELETE FROM feedback WHERE inspection_id IN ({ph})", chunk)
            n += conn.execute(f"DELETE FROM inspections WHERE id IN ({ph})", chunk).rowcount
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()
    _remove_screenshots(images)
    return n


def camera_labels(camera_ids):
    """{id: ((terminal, machine) key, 'Terminal / Machine / Camera')} for the queue."""
    out, ids = {}, [int(i) for i in camera_ids]
    conn = get_conn()
    for chunk in _chunks(ids):
        ph = ",".join("?" for _ in chunk)
        for r in conn.execute(f"SELECT id, terminal, machine_name, camera_name FROM cameras WHERE id IN ({ph})", chunk):
            key = ((r["terminal"] or "").strip().lower(), (r["machine_name"] or "").strip().lower())
            label = " / ".join(x for x in (r["terminal"], r["machine_name"], r["camera_name"]) if x)
            out[r["id"]] = (key, label)
    conn.close()
    return out


# ---------------- Daily inspection rules (which terminals / machines are inspected every day) ----------------

def get_daily_rules():
    """{'enabled': bool, 'skip_terminals': [...], 'skip_machines': ['terminal||machine', ...]}"""
    try:
        data = json.loads(get_setting("daily_skip", "{}") or "{}")
    except ValueError:
        data = {}
    return {"enabled": get_setting("daily_enabled", "1") != "0",
            "skip_terminals": list(data.get("terminals", [])),
            "skip_machines": list(data.get("machines", []))}


def set_daily_rules(enabled, skip_terminals, skip_machines):
    set_setting("daily_enabled", "1" if enabled else "0")
    set_setting("daily_skip", json.dumps({"terminals": sorted(skip_terminals), "machines": sorted(skip_machines)}))


def scheduled_cameras():
    """Active cameras that belong to the daily inspection (not switched off by terminal or machine)."""
    rules = get_daily_rules()
    norm = lambda v: " ".join((v or "").split()).lower()
    skip_t = {norm(t) for t in rules["skip_terminals"]}
    skip_m = set()
    for v in rules["skip_machines"]:
        t, _, m = v.partition("||")
        skip_m.add((norm(t), norm(m)))
    return [c for c in list_cameras(active_only=True)
            if norm(c.get("terminal")) not in skip_t
            and (norm(c.get("terminal")), norm(c.get("machine_name"))) not in skip_m]


def latest_verified_inspection(camera_id, status):
    """The newest inspection of this camera with this detection that an ENGINEER verified
    (automatic copies are ignored, so the comparison point cannot drift)."""
    conn = get_conn()
    row = conn.execute(
        """SELECT i.* FROM inspections i WHERE i.camera_id = ? AND i.status = ?
           AND EXISTS (SELECT 1 FROM feedback f WHERE f.inspection_id = i.id
                       AND COALESCE(f.engineer_name, '') != 'auto-match')
           ORDER BY i.timestamp DESC, i.id DESC LIMIT 1""", (camera_id, status)).fetchone()
    conn.close()
    return dict(row) if row else None


def latest_engineer_feedback(inspection_id):
    conn = get_conn()
    row = conn.execute(
        """SELECT * FROM feedback WHERE inspection_id = ? AND COALESCE(engineer_name, '') != 'auto-match'
           ORDER BY created_at DESC, id DESC LIMIT 1""", (inspection_id,)).fetchone()
    conn.close()
    return dict(row) if row else None


def previous_inspections_for_camera(camera_id, status, exclude_id=None, limit=20):
    """Past inspections for this camera with the same detected status, newest first."""
    conn = get_conn()
    q = """SELECT * FROM inspections WHERE camera_id = ? AND status = ?"""
    params = [camera_id, status]
    if exclude_id:
        q += " AND id != ?"
        params.append(exclude_id)
    q += " ORDER BY timestamp DESC LIMIT ?"
    params.append(limit)
    rows = conn.execute(q, params).fetchall()
    conn.close()
    return [dict(r) for r in rows]


# ---------------- Feedback ----------------

def add_feedback(inspection_id, verdict, comment, engineer_name, reason=""):
    conn = get_conn()
    conn.execute(
        """INSERT INTO feedback (inspection_id, verdict, reason, comment, engineer_name, created_at)
           VALUES (?,?,?,?,?,?)""",
        (inspection_id, verdict, reason or "", comment, engineer_name, datetime.utcnow().isoformat()),
    )
    row = conn.execute("SELECT status FROM inspections WHERE id = ?", (inspection_id,)).fetchone()
    if row:                                                  # the reported status follows the newest verdict
        conn.execute("UPDATE inspections SET final_status = ? WHERE id = ?",
                     (final_status_for(row["status"], verdict, reason), inspection_id))
    conn.commit()
    conn.close()


def get_feedback_for_inspection(inspection_id):
    conn = get_conn()
    row = conn.execute(
        "SELECT * FROM feedback WHERE inspection_id = ? ORDER BY created_at DESC LIMIT 1",
        (inspection_id,),
    ).fetchone()
    conn.close()
    return dict(row) if row else None


def get_feedback_by_inspection_ids(inspection_ids):
    if not inspection_ids:
        return {}
    out = {}
    ids = list(inspection_ids)
    conn = get_conn()
    for start in range(0, len(ids), 500):              # SQLite limits the number of ? placeholders
        chunk = ids[start:start + 500]
        q = (f"SELECT * FROM feedback WHERE inspection_id IN ({','.join('?' for _ in chunk)}) "
             "ORDER BY created_at DESC")
        for r in conn.execute(q, chunk).fetchall():
            d = dict(r)
            out.setdefault(d["inspection_id"], d)      # keep most recent only
    conn.close()
    return out
