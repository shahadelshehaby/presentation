"""
Capture + diagnose cameras.

* Cameras are captured through a queue: a few at a time (Settings > Schedule >
  Cameras at the same time, never two of the same machine together), with a short
  pause between cameras, so a run over 1000 cameras never floods the network.
* The scheduled run (time and frequency set in Settings > Schedule: every day, every
  N days, chosen weekdays or one day a month) puts every included camera in that queue.
  "Run diagnosis now" on the Diagnose page puts the selected cameras in the same queue.
* The picture is analysed at full resolution, then a smaller copy (max width
  SAVE_MAX_WIDTH) is stored to keep disk usage low.
"""
from __future__ import annotations

import os
# TCP is the most reliable way to pull RTSP over a LAN. Must be set before the first capture.
os.environ.setdefault("OPENCV_FFMPEG_CAPTURE_OPTIONS", "rtsp_transport;tcp")

import json
import queue
import random
import secrets
import socket
import struct
import subprocess
import sys
import threading
import time
from datetime import datetime
from urllib.parse import quote, urlparse

import cv2

import db
import diagnosis

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
SCREENSHOT_DIR = os.path.join(BASE_DIR, "screenshots")
os.makedirs(SCREENSHOT_DIR, exist_ok=True)

# ---- Things you may want to tune ------------------------------------------------
SAVE_MAX_WIDTH = 1280        # stored screenshots are shrunk to this width (analysis uses the full frame)
SAVE_JPEG_QUALITY = 80
OPEN_TIMEOUT_MS = int(os.environ.get("CAMERA_OPEN_TIMEOUT_MS", 8000))   # give up on an unreachable camera after this long
READ_TIMEOUT_MS = int(os.environ.get("CAMERA_READ_TIMEOUT_MS", 8000))
USE_GRAB_PROCESSES = True    # each capture worker uses its own helper process so connections really overlap
REACHABLE_TIMEOUT_S = 3.0    # a camera that does not answer on its RTSP port within this time is "No view" at once
GRAB_HARD_LIMIT_S = 45.0     # a camera that has not finished by then is cut off (counted as "No view")
FRAMES_TO_READ = 5           # first frames of a stream are often grey - keep the last good one
DEFAULT_PAUSE_SECONDS = 2    # used until you change it in Settings > Schedule
DAILY_JOB_ID = "daily_inspection"


# --------------------------------------------------------------------------------
# Getting a picture from a camera
# --------------------------------------------------------------------------------
def build_rtsp_url(camera: dict) -> str:
    ip = (camera.get("ip") or "").strip()
    path = (camera.get("rtsp_path") or "/Streaming/Channels/101").strip()
    for value in (path, ip):                       # accept a pasted full rtsp://... URL
        if value.lower().startswith("rtsp://"):
            u = urlparse(value)
            ip = u.netloc.split("@")[-1]
            path = (u.path or "/") + (f"?{u.query}" if u.query else "")
            break
    if not path.startswith("/"):
        path = "/" + path
    host = ip if ":" in ip else f"{ip}:554"        # for another port enter e.g. 192.168.1.69:8554
    auth = ""
    if camera.get("username"):
        auth = f"{quote(camera['username'], safe='')}:{quote(camera.get('password') or '', safe='')}@"
    return f"rtsp://{auth}{host}{path}"


def _open_capture(source):
    try:
        return cv2.VideoCapture(source, cv2.CAP_FFMPEG,
                                [cv2.CAP_PROP_OPEN_TIMEOUT_MSEC, OPEN_TIMEOUT_MS,
                                 cv2.CAP_PROP_READ_TIMEOUT_MSEC, READ_TIMEOUT_MS])
    except Exception:                              # older OpenCV without timeout options
        return cv2.VideoCapture(source)


def _frame_from_rtsp(url):
    cap = _open_capture(url)
    try:
        if not cap.isOpened():
            return None
        frame = None
        for _ in range(FRAMES_TO_READ):
            ok, f = cap.read()
            if ok and f is not None:
                frame = f
        return frame
    finally:
        cap.release()


def _frame_from_video_file(path):
    cap = cv2.VideoCapture(path)
    try:
        if not cap.isOpened():
            return None
        n = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
        if n > 1:
            cap.set(cv2.CAP_PROP_POS_FRAMES, random.randrange(n))
        ok, frame = cap.read()
        return frame if ok else None
    finally:
        cap.release()


def grab_frame(camera: dict):
    """One picture from the camera (numpy array) or None.
    Testing without a camera: put  video:C:\\path\\clip.mp4  or  testimg:test_images/normal.jpg  in the IP box."""
    source = (camera.get("ip") or "").strip()
    low = source.lower()
    if low.startswith("video:"):
        return _frame_from_video_file(source[6:].strip())
    if low.startswith("testimg:"):
        path = source[8:].strip()
        return cv2.imread(path if os.path.isabs(path) else os.path.join(BASE_DIR, path))
    return _frame_from_rtsp(build_rtsp_url(camera))


def _save_frame(frame, camera_id: int) -> str:
    """Store a (possibly shrunk) JPEG in screenshots/<date>/ and return its path."""
    h, w = frame.shape[:2]
    if w > SAVE_MAX_WIDTH:
        frame = cv2.resize(frame, (SAVE_MAX_WIDTH, int(h * SAVE_MAX_WIDTH / w)), interpolation=cv2.INTER_AREA)
    folder = os.path.join(SCREENSHOT_DIR, datetime.utcnow().strftime("%Y-%m-%d"))
    os.makedirs(folder, exist_ok=True)
    name = f"cam{camera_id}_{datetime.utcnow():%H%M%S_%f}.jpg"
    path = os.path.join(folder, name)
    cv2.imwrite(path, frame, [cv2.IMWRITE_JPEG_QUALITY, SAVE_JPEG_QUALITY])
    return path


def capture_screenshot(camera: dict) -> str | None:
    """Grab one frame and save it. Returns the file path, or None on failure."""
    frame = grab_frame(camera)
    return None if frame is None else _save_frame(frame, camera["id"])


# --------------------------------------------------------------------------------
# Capture + analysis, optionally inside a helper process (see grab_worker.py)
# --------------------------------------------------------------------------------
def grab_and_analyze(camera: dict):
    """Connect to the camera, analyse the picture and save it.  Returns {'result', 'image_path'} or None (no picture)."""
    frame = grab_frame(camera)
    if frame is None:
        return None
    result = diagnosis.analyze_frame(frame, camera.get("_disabled") or ())
    return {"result": result, "image_path": _save_frame(frame, camera["id"])}


def send_message(sock, data: bytes):
    sock.sendall(struct.pack("!Q", len(data)) + data)


def _recv_exact(sock, n):
    buf = b""
    while len(buf) < n:
        chunk = sock.recv(n - len(buf))
        if not chunk:
            return None
        buf += chunk
    return buf


def recv_message(sock):
    head = _recv_exact(sock, 8)
    if head is None:
        return None
    return _recv_exact(sock, struct.unpack("!Q", head)[0])


def _rtsp_reachable(camera: dict) -> bool:
    """Quick check that something answers on the camera's RTSP port (only for real network cameras)."""
    source = (camera.get("ip") or "").strip().lower()
    if source.startswith(("video:", "testimg:")):
        return True
    try:
        u = urlparse(build_rtsp_url(camera))
        with socket.create_connection((u.hostname, u.port or 554), timeout=REACHABLE_TIMEOUT_S):
            return True
    except (OSError, ValueError):
        return False


class _GrabProcess:
    """One helper process (grab_worker.py) owned by one capture worker thread."""

    def __init__(self):
        self.proc = None
        self.sock = None

    def _start(self):
        token = secrets.token_hex(16)
        server = socket.socket()
        server.bind(("127.0.0.1", 0))
        server.listen(1)
        server.settimeout(30)
        port = server.getsockname()[1]
        kwargs = {"creationflags": 0x08000000} if os.name == "nt" else {}      # no console window on Windows
        self.proc = subprocess.Popen(
            [sys.executable, os.path.join(BASE_DIR, "grab_worker.py"), str(port)],
            env={**os.environ, "GRAB_TOKEN": token}, cwd=BASE_DIR,
            stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, **kwargs)
        try:
            conn, _ = server.accept()
            conn.settimeout(15)
            if _recv_exact(conn, 32) != token.encode():
                conn.close()
                raise OSError("helper process did not identify itself")
            self.sock = conn
        finally:
            server.close()

    def run(self, camera, timeout):
        """Returns grab_and_analyze's answer, or None. Raises OSError if the helper cannot be used."""
        if self.proc is None or self.proc.poll() is not None or self.sock is None:
            self.close()
            self._start()
        try:
            self.sock.settimeout(timeout)
            send_message(self.sock, json.dumps(camera, default=str).encode("utf-8"))
            data = recv_message(self.sock)
        except socket.timeout:                      # the camera hung: cut it off and start a fresh helper
            self.close()
            return None
        except OSError:
            self.close()
            raise
        if data is None:
            self.close()
            raise OSError("helper process stopped")
        out = json.loads(data.decode("utf-8"))
        if out is None or out.get("error"):
            return None
        return out

    def close(self):
        for closer in (lambda: self.sock and self.sock.close(), lambda: self.proc and self.proc.kill(),
                       lambda: self.proc and self.proc.wait(timeout=3)):
            try:
                closer()
            except Exception:
                pass
        self.proc = self.sock = None


_local = threading.local()          # per capture worker thread: .in_worker and .grabber


def _close_grabber():
    g = getattr(_local, "grabber", None)
    if g is not None:
        g.close()
        _local.grabber = None


def disabled_detections() -> list:
    """Detections switched off in Settings > Schedule (stored as a JSON list)."""
    try:
        return [k for k in json.loads(db.get_setting("disabled_detections", "[]") or "[]")]
    except (ValueError, TypeError):
        return []


def _capture_and_analyze(camera: dict):
    camera = dict(camera, _disabled=disabled_detections())
    if not _rtsp_reachable(camera):
        return None                                  # nothing answers on the RTSP port: No view, without waiting
    if USE_GRAB_PROCESSES and getattr(_local, "in_worker", False):
        try:
            g = getattr(_local, "grabber", None)
            if g is None:
                g = _local.grabber = _GrabProcess()
            return g.run(camera, GRAB_HARD_LIMIT_S)
        except Exception as e:                        # helper unusable: capture inside this program instead
            print(f"[capture] helper process failed ({e}); capturing in-process")
            _close_grabber()
    return grab_and_analyze(camera)


# --------------------------------------------------------------------------------
# One camera: capture -> diagnose -> auto-match with the engineer's earlier verdicts
# --------------------------------------------------------------------------------
def run_inspection_for_camera(camera_id: int):
    camera = db.get_camera(camera_id)
    if not camera or camera.get("deleted") or not camera.get("active", 1):
        return None

    out = _capture_and_analyze(camera)
    if out is None:
        result = {"status": "NO_VIEW", "confidence": 99.9,
                  "metrics": {"reason": "connection_or_read_failed"}}
        image_path = None
    else:
        result, image_path = out["result"], out["image_path"]

    status, confidence, metrics = result["status"], result["confidence"], result["metrics"]

    # Auto-match against earlier inspections of THIS camera with the same status
    # that an engineer already verified.
    # Compared with the LATEST inspection of this camera, with the same detection, that an engineer
    # verified: same or better -> copy his verdict; clearly worse -> do not copy, flag it for a re-check.
    auto_matched, matched_from_id, worse, prev_fb = False, None, False, None
    learned_conf = learned_stat = final = None
    if status != "OK":
        base = db.latest_verified_inspection(camera_id, status)
        prev_fb = db.latest_engineer_feedback(base["id"]) if base else None
        if base and prev_fb:
            if diagnosis.compare_to_verified(confidence, base.get("confidence")) == "worse":
                worse = True
            else:
                auto_matched, matched_from_id = True, base["id"]
                # trust grows with every consecutive confirmation of the same engineer verdict
                learned_stat = db.effective_status(prev_fb["verdict"], prev_fb.get("reason"), status)
                final = db.final_status_for(status, prev_fb["verdict"], prev_fb.get("reason"))
                # trust grows with every consecutive confirmation (engineer's or automatic) of the same result
                learned_conf = diagnosis.learned_confidence(max(db.verdict_streak(camera_id, status, final), 1))

    inspection_id = db.add_inspection(
        camera_id=camera_id, image_path=image_path, status=status, confidence=confidence,
        metrics=metrics, auto_matched=auto_matched, matched_from_inspection_id=matched_from_id,
        worse=worse, learned_confidence=learned_conf, learned_status=learned_stat,
        final_status=final or status,
    )

    if auto_matched and matched_from_id and prev_fb:
        db.add_feedback(
            inspection_id=inspection_id,
            verdict=prev_fb["verdict"],
            reason=prev_fb.get("reason") or "",
            comment=f"(auto-applied, matches inspection #{matched_from_id}) {prev_fb['comment'] or ''}".strip(),
            engineer_name="auto-match",
        )
    return inspection_id


# --------------------------------------------------------------------------------
# The queue: a few cameras at a time (Settings > Schedule), never two from the same machine together
# --------------------------------------------------------------------------------
DEFAULT_WORKERS = 8          # cameras captured at the same time until you change it in Settings > Schedule
MAX_WORKERS = 32

_lock = threading.Lock()
_cond = threading.Condition(_lock)
_waiting: list = []          # [(camera_id, machine_key, label)] not started yet
_pending: set = set()        # camera ids waiting or in progress (so none is queued twice)
_in_progress: dict = {}      # camera_id -> (machine_key, label)
_busy_machines: set = set()  # machines with a capture in progress right now
_threads: dict = {}          # worker number -> Thread
_state = {"running": False, "total": 0, "done": 0, "current": None}
_last_error = {"at": None, "message": None}


def _pause_seconds() -> float:
    try:
        return max(0.0, float(db.get_setting("pause_seconds", DEFAULT_PAUSE_SECONDS)))
    except (TypeError, ValueError):
        return float(DEFAULT_PAUSE_SECONDS)


def _worker_limit() -> int:
    try:
        return min(MAX_WORKERS, max(1, int(float(db.get_setting("workers", DEFAULT_WORKERS)))))
    except (TypeError, ValueError):
        return DEFAULT_WORKERS


def _interleave(entries):
    """Order cameras so neighbours belong to different machines (spreads the load over the network)."""
    groups, order = {}, []
    for e in entries:
        if e[1] not in groups:
            groups[e[1]] = []
            order.append(e[1])
        groups[e[1]].append(e)
    out, depth = [], 0
    while len(out) < len(entries):
        for key in order:
            if depth < len(groups[key]):
                out.append(groups[key][depth])
        depth += 1
    return out


def _pick_locked():
    """First waiting camera whose machine is not being captured right now (caller holds the lock)."""
    for idx, entry in enumerate(_waiting):
        if entry[1] not in _busy_machines:
            _waiting.pop(idx)
            _busy_machines.add(entry[1])
            _in_progress[entry[0]] = (entry[1], entry[2])
            return entry
    return None


def _worker_loop(number):
    _local.in_worker = True
    while True:
        limit = _worker_limit()                       # read the setting without holding the lock
        with _cond:
            if number >= limit:                       # the number of workers was lowered
                _threads.pop(number, None)
                _close_grabber()
                return
            entry = _pick_locked()
            if entry is None:
                if not _waiting and not _in_progress:
                    _close_grabber()                  # run finished: free the helper process (memory)
                _cond.wait(timeout=5)
                continue
        camera_id, machine_key, _label = entry
        try:
            run_inspection_for_camera(camera_id)
        except Exception as e:                        # one bad camera must never stop the run
            print(f"[capture] camera {camera_id} failed: {e}")
            _last_error.update(at=datetime.now(), message=f"camera {camera_id}: {e}")
        finally:
            with _cond:
                _pending.discard(camera_id)
                _in_progress.pop(camera_id, None)
                _busy_machines.discard(machine_key)
                _state["done"] += 1
                if not _waiting and not _in_progress:
                    _state["running"] = False
                _cond.notify_all()
        if _waiting:
            time.sleep(_pause_seconds())


def _ensure_workers():
    limit = _worker_limit()
    with _cond:
        for number in range(limit):
            t = _threads.get(number)
            if t is None or not t.is_alive():
                t = threading.Thread(target=_worker_loop, args=(number,), name=f"capture-worker-{number}", daemon=True)
                _threads[number] = t
                t.start()
        _cond.notify_all()


def enqueue(camera_ids):
    """Queue cameras for inspection. Returns (added, already_queued)."""
    camera_ids = list(camera_ids)
    labels = db.camera_labels(camera_ids)
    fresh = []
    with _cond:
        if not _state["running"]:
            _state.update(total=0, done=0)
        for cid in camera_ids:
            if cid in _pending or cid not in labels:
                continue
            _pending.add(cid)
            fresh.append((cid, labels[cid][0], labels[cid][1]))
        if fresh:
            _waiting.extend(_interleave(fresh))
            _state["running"] = True
            _state["total"] += len(fresh)
        added = len(fresh)
    if added:
        _ensure_workers()
    return added, len(camera_ids) - added


def cancel_pending() -> int:
    """Remove everything that has not started yet (cameras in progress finish)."""
    with _cond:
        removed = len(_waiting)
        for cid, _key, _label in _waiting:
            _pending.discard(cid)
        _waiting.clear()
        _state["total"] -= removed
        if not _in_progress:
            _state["running"] = False
        _cond.notify_all()
    return removed


def last_error():
    """{'at': datetime, 'message': str} of the last unexpected failure while inspecting, or None."""
    return dict(_last_error) if _last_error["at"] else None


def progress() -> dict:
    with _lock:
        labels = [v[1] for v in list(_in_progress.values())]
        current = ", ".join(labels[:2]) + (f" (+{len(labels) - 2} more)" if len(labels) > 2 else "")
        return {"running": _state["running"], "total": _state["total"], "done": _state["done"],
                "current": current}


def run_all_inspections():
    """Queue every active camera (used by 'run all now'). Returns how many were queued."""
    added, _ = enqueue([c["id"] for c in db.list_cameras(active_only=True)])
    return added


# --------------------------------------------------------------------------------
# Schedule (Settings > Schedule): every day, every N days, chosen weekdays, or one day a month
# --------------------------------------------------------------------------------
FREQUENCIES = [
    ("daily", "Every day"),
    ("every_n", "Every few days (every N days)"),
    ("weekly", "Weekly (on chosen weekdays)"),
    ("monthly", "Monthly (on one day of the month)"),
]
WEEKDAYS = [("mon", "Monday"), ("tue", "Tuesday"), ("wed", "Wednesday"), ("thu", "Thursday"),
            ("fri", "Friday"), ("sat", "Saturday"), ("sun", "Sunday")]
MAX_EVERY_DAYS = 60


def run_scheduled_inspection():
    """The scheduled run: only the cameras whose terminal / machine are switched on in Settings > Schedule."""
    rules = db.get_daily_rules()
    if not rules["enabled"]:
        db.set_setting("last_run_started", "skipped - scheduled inspection is switched off")
        return
    db.set_setting("last_run_started", datetime.now().isoformat(timespec="seconds"))
    enqueue([c["id"] for c in db.scheduled_cameras()])


def schedule_inspection(scheduler, hour: int, minute: int, frequency: str = "daily", every_days: int = 2,
                        weekdays=("mon",), month_day: str = "1", start_date=None):
    """(Re)creates the one scheduled job. Safe to call again whenever the schedule changes.
    frequency  'daily'   - every day at hour:minute
               'every_n' - every `every_days` days at hour:minute, counted from `start_date` (a date)
               'weekly'  - on the `weekdays` given ('mon' ... 'sun') at hour:minute
               'monthly' - on `month_day` ('1' ... '28' or 'last') at hour:minute
    Times are this computer's clock.  If the computer was asleep, a run starts on wake-up within 3 hours."""
    common = dict(id=DAILY_JOB_ID, replace_existing=True, misfire_grace_time=3 * 3600, coalesce=True, max_instances=1)
    if frequency == "every_n":
        days = min(MAX_EVERY_DAYS, max(1, int(every_days or 1)))
        first = datetime.combine(start_date or datetime.now().date(), datetime.min.time()).replace(hour=hour, minute=minute)
        scheduler.add_job(run_scheduled_inspection, "interval", days=days, start_date=first, **common)
    elif frequency == "weekly":
        days = [d for d in (weekdays or ()) if d in dict(WEEKDAYS)] or ["mon"]
        scheduler.add_job(run_scheduled_inspection, "cron", day_of_week=",".join(days), hour=hour, minute=minute, **common)
    elif frequency == "monthly":
        day = "last" if str(month_day) == "last" else str(min(28, max(1, int(month_day or 1))))
        scheduler.add_job(run_scheduled_inspection, "cron", day=day, hour=hour, minute=minute, **common)
    else:
        scheduler.add_job(run_scheduled_inspection, "cron", hour=hour, minute=minute, **common)


def schedule_daily(scheduler, hour: int, minute: int):
    """Kept for older callers: the same as schedule_inspection(..., frequency='daily')."""
    schedule_inspection(scheduler, hour, minute, "daily")


def describe_schedule(hour: int, minute: int, frequency: str = "daily", every_days: int = 2,
                      weekdays=("mon",), month_day: str = "1", start_date=None) -> str:
    """Plain-language summary, e.g. 'every Monday and Thursday at 09:00'."""
    at = f"at {hour:02d}:{minute:02d}"
    if frequency == "every_n":
        n = min(MAX_EVERY_DAYS, max(1, int(every_days or 1)))
        since = f", counted from {start_date:%d %b %Y}" if start_date else ""
        return f"every {n} days {at}{since}" if n > 1 else f"every day {at}"
    if frequency == "weekly":
        names = [name for key, name in WEEKDAYS if key in (weekdays or ())] or ["Monday"]
        text = names[0] if len(names) == 1 else ", ".join(names[:-1]) + " and " + names[-1]
        return f"every {text} {at}"
    if frequency == "monthly":
        if str(month_day) == "last":
            return f"on the last day of every month {at}"
        d = min(28, max(1, int(month_day or 1)))
        suffix = "th" if 10 <= d % 100 <= 20 else {1: "st", 2: "nd", 3: "rd"}.get(d % 10, "th")
        return f"on the {d}{suffix} of every month {at}"
    return f"every day {at}"


def add_optional_connectivity_ping(scheduler, camera_ids: list[int], every_hours=2):
    """OPTIONAL and OFF by default: a light 'can I still grab a frame?' check between the daily runs.
    Not recommended for 1000 cameras (it would load the network all day)."""
    def ping(cam_id):
        camera = db.get_camera(cam_id)
        if camera and grab_frame(camera) is None:
            db.add_inspection(cam_id, None, "NO_VIEW", 90.0, {"reason": "connectivity_ping_failed"})

    for cam_id in camera_ids:
        scheduler.add_job(ping, "interval", hours=every_hours, args=[cam_id],
                          id=f"ping_cam_{cam_id}", replace_existing=True)
