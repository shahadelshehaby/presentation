# Camera Health Platform (offline)

A local web app to monitor IP camera health: daily staggered screenshots,
automatic diagnosis (no view / dirty / color cast / dark / overexposed /
partial occlusion), confidence scoring, engineer verification, and
per-camera learning from past feedback. Runs entirely on your local
network — no internet or cloud services required.

## Setup — just run one file

You don't need to install anything manually first. Just run:

- **`run.py`** — double-click it (or `python run.py`) on any OS with Python
  installed. It installs any missing packages automatically, starts the
  server, and opens your browser to the dashboard.
- **`run.bat`** — Windows convenience double-click wrapper around `run.py`
  (keeps the console window open so you can see logs/errors).
- **`run.command`** — macOS convenience double-click wrapper around `run.py`.

Manual alternative, if you prefer:
```bash
pip install -r requirements.txt
python app.py
```

Either way, the dashboard opens at **http://localhost:5070** (or the
machine's LAN IP from another device on the network).

## How it works

1. **Settings tab** has three sub-tabs:
   - **Cameras** - the list (search, filter by terminal, 50 per page) with *Edit*, *Test capture now*, *Disable* and *Delete* for each camera.
   - **Import from Excel** - load many cameras at once from an .xlsx or .csv file (see below).
   - **Add camera** - terminal, machine name, camera name, IP, username, password, RTSP path and description.
     Typing a terminal or machine suggests the existing names, so spellings stay identical.
   - **Schedule** - how often (every day, every N days, chosen weekdays or monthly), the start time, the pause between cameras (see below).
2. **Edit a camera** - *Edit* opens the same form filled in. Leave the password empty to keep the current one.
   Past inspections are kept. Un-tick "Include this camera in the daily inspection" to pause a camera.
3. **Diagnosis** (`diagnosis.py`) — classical computer-vision checks run on
   each screenshot: brightness, sharpness (Laplacian variance), per-channel
   color balance, and a spatial grid sharpness check for partial occlusion.
   No internet-dependent model is used, so it works fully offline.
   Haze: a milky / washed-out picture (no real blacks and little contrast) is reported as Dirty / blurry lens. The date and
   camera-name text at the top of the picture is ignored in all measurements (`overlay_top_fraction`, `overlay_bottom_fraction`
   in `diagnosis.py`; thresholds `haze_black_level_thresh` and `haze_contrast_range_thresh`).
4. **Confidence score** — a 50-99.9% heuristic based on how far a metric
   sits past its decision threshold (a value barely past threshold reads
   ~55-65%, a value clearly past it reads ~95-99%). This is not a
   statistical probability — it's meant as a relative signal for engineers.
5. **Engineer verification** (Diagnose tab) - for each inspection the engineer picks **Same as detected** or
   **Normal / false detection**. For a false detection a second list asks *why*: Old camera, OK (the scene caused it,
   e.g. a red car), or the real problem (Dirty / blurry lens, Partial occlusion, tints ...). Add a name and remark if wanted.
   Older verdicts (Old camera / Other issue) are still shown.
6. **Per-camera learning** - the new picture is compared with the **latest inspection of the same camera and the same
   detection that an engineer verified**. If it is the **same or better** (confidence not more than 15 points higher), his verdict
   and reason are copied and flagged "auto-matched". If it is clearly **worse**, nothing is copied and it is flagged
   "Worse than last check" so someone looks again. Auto-copies are never used as the comparison point.
   Tune `worse_confidence_points` in `diagnosis.py`.
7. **Filter / sort** — by terminal, machine, camera, status, verdict (each can hold several values), date range, confidence, etc.
8. **Reports** — download a PDF per inspection (machine name, camera name,
   photo, status, confidence, engineer remarks), a batch PDF for a
   filtered/selected set, or a CSV export of everything.

## Daily inspection for many cameras (for example 1000)

- Settings > Schedule sets the **start time** (default 09:00) and the **pause between cameras** (default 2 s).
  Changes apply immediately - no restart.
- Cameras are captured **one at a time** through a queue, never together. With 1000 cameras and a 2 s pause a run takes
  roughly 1 h 25 min. The Schedule page shows a live estimate.
- The platform must be running at the start time. If the computer was asleep and wakes within 3 hours after it, the run starts then.
- Stored screenshots are shrunk to 1280 px wide (the diagnosis itself uses the full picture). Roughly 100-150 KB each, so about
  100-150 MB per day for 1000 cameras. Change `SAVE_MAX_WIDTH` / `SAVE_JPEG_QUALITY` in `capture.py` if you want smaller or larger.
  Old screenshots are not deleted automatically.

## Importing many cameras from Excel

Settings > **Import from Excel**: download the template, fill one camera per row, upload it, press Import.
- Required columns: **Terminal, Machine, Camera, IP**. Optional: Username, Password, RTSP path, Description, Active (Yes/No).
- Column order does not matter and the header may have a few title rows above it; common alternative names (Machine name, Camera IP, ...) are recognised.
- A camera that already exists (same Terminal + Machine + Camera name) is skipped, or updated if you choose "Update" (empty cells keep the current value).
- Rows with a problem are listed with their row number and skipped; every other row is still imported. 2,500 cameras import in about a second.

## Deleting cameras

- **Delete** on a row removes the camera from the list and from the daily inspection, but **keeps all its previous inspections, engineer
  verdicts, screenshots and reports** (they still appear in Diagnose and in PDF/CSV reports, marked "Removed").
- If you later add (or import) a camera with the **same Terminal + Machine + Camera name** - for example a replacement with a different brand
  and IP - the old history is linked to it again automatically.
- Tick several cameras (or the header box for the whole page) and press **Delete selected**. After ticking a whole page, "Select all N cameras"
  extends the selection to every page of the current search / terminal filter. More than 10 cameras asks you to type DELETE.

## Run diagnosis now (Diagnose tab)

Open "Run diagnosis now", tick terminals (all machines in them) and/or single machines, and press **Diagnose N cameras**.
They join the same one-at-a-time queue; a progress bar shows how far it is and **Stop** removes the rest.

## Filters and reports

The Diagnose tab filters by terminal, machine, camera, status, verdict, dates, and "All inspections / Latest per camera".
- **Several values per filter:** Terminal, Machine, Camera, Status and Verdict open a list of tick boxes - tick as many as you need
  (e.g. machines A101 + A102 + B201, or Status No view + Too dark) and press Apply. Ticks inside one filter mean "any of these";
  different filters are combined ("these machines AND these statuses"). Nothing ticked = all. The Machine and Camera lists have a
  search box and follow the chosen terminals (and machines). Old single-value links keep working. Code: `inspection_query.py`.
- The Status filter and the "Issues detected" count use the final status (the engineer's correction when there is one), the same as the cards.
- **Download report (PDF)** - everything matching the filters, including multi-value ones (up to 2000 inspections per report).
- **Export CSV** - the same, as a spreadsheet.
- Tick inspections and use "Download selected as report (PDF)" to export just those.

## Theme ("Engineering Building" design system)

The whole look lives in **one file: `static/style.css`**. Colours, fonts and
sizes are CSS variables at the top (`:root`), with a dark mode that follows
the computer's light/dark setting. Change a variable there and every page
updates.

- **Company logo:** put your logo at `static/logo.png` (or `static/logo.svg`).
  It appears top-left in the header (32px high) and is used as the browser-tab
  icon. In dark mode it sits on a small white plate; to turn that off, set
  `--logo-plate: transparent;` in the dark block of `style.css`.
  The PDF reports also show the logo, but PNG only (SVG is skipped there).
- **Header status text** (next to the page title) refreshes every 30 seconds
  from `/api/status` and turns red if a camera has no view or the server
  can't be reached.
- `static/app.js` only adds small extras (live status, "Working..." button
  states, Save-bar messages). The pages still work without it.

## Recommended addition (not enabled by default)

Daily-only screenshots will miss issues that appear intra-day (e.g. a
camera going dark at 2pm). `capture.py` includes
`add_optional_connectivity_ping()` — a lightweight "can I grab a frame"
check (no full image analysis) you can schedule every 1-2 hours per
camera to catch dropped connections faster, without adding much network
load. Call it once in `app.py` after `_refresh_schedule()` if you want it.

## Notes / things to harden before production use

- Camera passwords are currently stored in plain text in the SQLite file
  (`camera_platform.db`). For a production deployment, encrypt them at
  rest or use a secrets manager.
- The dev Flask server (`app.run(...)`) is fine for local/LAN use; for
  anything more exposed, run behind a proper WSGI server (gunicorn/waitress).
- RTSP path defaults to a Hikvision-style path
  (`/Streaming/Channels/101`) — adjust per camera brand in Settings.
- Thresholds in `diagnosis.py` (`CONFIG` dict) are starting points; the
  auto-matching/learning system is what actually adapts per camera over
  time as your engineers verify results.

## Engineering Building integration

`building_status.py` adds a read-only page **`GET /building/status`** (JSON: status, current job, counters for today / last hour,
last error and the "team" of roles that would do this work by hand). It is cached for 5 seconds, catches every error and
never slows the platform. The platform now runs on **port 5070**.
In the building: Settings > Floors > Add floor, open the new floor's tab, enter `http://<this PC's IP>:5070` and press Test
next to "Status page". Edit the `TEAM` list at the top of `building_status.py` to change roles or the manual minutes per camera.

## Latest additions

- **Dubai time everywhere.** Times are stored in UTC and shown in Dubai time (pages, CSV, PDF, filters). The From / To filter boxes
  take a date **and time** in Dubai time. Code: `timeutil.py`.
- **Learned confidence.** When a new picture is auto-matched to an engineer's verdict, it gets a *learned confidence* (trust in that
  verdict) that grows with every consecutive confirmation: about 68% on the first repeat, 77%, 84%, 88%, 92% ... up to 99%.
  A "false detection - OK / old camera" verdict makes the learned result "OK" and the picture no longer counts as an issue.
  The PDF shows the learned confidence only; the CSV has both numbers. Tune `learned_*` in `diagnosis.py`.
- **More filters (Diagnose):** verdict (no engineer verdict yet / verified / auto-matched / worse), newest N results, date + time,
  detection confidence min-max, learned confidence min-max.
- **Picture pop-up:** click a picture to see it large; arrow keys or buttons move between pictures, Esc closes.
- **Delete selected inspections** (Diagnose, bottom bar): removes the inspections, their verdicts and their picture files. Typing DELETE is
  required for more than 10.
- **Daily inspection switch** (Settings > Schedule): switch the daily run off, or leave out terminals / machines (tree with tick boxes).
- **Cameras at the same time** (Settings > Schedule): the run captures several cameras at once (default 8) - 3,600 cameras take about
  25 minutes at 8, about 15 at 12-16. Two cameras of the same machine are never captured together. 1 = one after another.

## Final status (what the reports show)

Every result has one **final status**: the platform's detection, unless an engineer's verdict corrects it.
- "Same as detected" keeps the detection. "Normal / false detection" with reason *OK* or *Old camera* makes it **OK**; with a real problem
  as the reason (e.g. Dirty / blurry lens) it becomes that problem.
- The engineer's verdict becomes the **baseline** of that camera. A later reading with the same detection that is the same or better
  (confidence not more than `worse_confidence_points` = 15 higher) gets the baseline's final status automatically; a clearly worse one does not,
  and is tagged "Worse than last check".
- The PDF Status column, the Diagnose status tag (with a small "detected: ..." when different), the issue counts and the Status filter all use the
  final status. The CSV has both the final and the detected status.
- Learned confidence grows with every consecutive confirmation of the same result, whether it was the engineer's own or an automatic copy.

## Capture speed (helper processes)

OpenCV opens RTSP streams one at a time inside one program, so many workers did not really overlap.
Now every capture worker starts its own small helper process (`grab_worker.py`, about 100-150 MB of
memory each, closed when the run ends), so connections run truly in parallel. A camera that does not
answer on its RTSP port within 3 seconds is "No view" immediately, and a camera that has not finished
after 45 seconds is cut off. If a helper cannot start, capture falls back to the old way.
Settings are at the top of `capture.py` (`USE_GRAB_PROCESSES`, `REACHABLE_TIMEOUT_S`, `GRAB_HARD_LIMIT_S`).

## Choosing which detections are checked

Settings > Schedule > Detections: untick Too dark, Overexposed, Dirty / blurry, Red / Green / Blue tint or
Partial occlusion and that problem is no longer checked on new inspections. Old results and reports are not
changed. "No view" is always checked. Saved with the other schedule settings (Save button).

## How often the inspection runs

Settings > Schedule > **How often**:
- **Every day** (default) at the start time.
- **Every few days** - every 2 to 60 days, counted from a start date (every 5 days from 1 October = 1, 6, 11, 16 ... and on into
  the next month). Uses an interval job, so the count is not reset at the start of a month.
- **Weekly** - on any ticked weekdays (one day = once a week, two days = twice a week).
- **Monthly** - on day 1 to 28, or the last day of the month (29-31 are not offered because some months do not have them).

The page shows the saved schedule in words ("the inspection runs every Wednesday and Sunday at 09:00") and Status > Next run.
Changes apply when you press Save, without a restart. Which cameras, detections, pause, cameras at the same time and the
3-hour wake-up rule work the same for every frequency. Settings are stored as `schedule_frequency`, `schedule_every_days`,
`schedule_start_date`, `schedule_weekdays` and `schedule_month_day`; the job is built by `capture.schedule_inspection()`
(`schedule_daily()` still works for older callers). Existing installations keep running every day until changed.
