"""
timeutil.py - the platform stores every time in UTC (safe and unambiguous) and shows every time in
Dubai time (Asia/Dubai, UTC+04:00, no daylight saving).  If this computer has no time-zone database
(some Windows installs), a fixed +04:00 offset is used - the result is identical for Dubai.
"""
from datetime import datetime, timedelta, timezone

try:
    from zoneinfo import ZoneInfo
    LOCAL_TZ = ZoneInfo("Asia/Dubai")
except Exception:                                   # no zoneinfo / no tzdata
    LOCAL_TZ = timezone(timedelta(hours=4))

LABEL = "Dubai time"


def now_local():
    return datetime.now(LOCAL_TZ)


def parse_utc(text):
    """'2026-10-13T03:44:12.123456' (stored UTC) -> aware datetime, or None."""
    if not text:
        return None
    try:
        dt = datetime.fromisoformat(str(text).replace("Z", ""))
    except ValueError:
        return None
    return dt.replace(tzinfo=timezone.utc) if dt.tzinfo is None else dt


def to_local(text):
    dt = parse_utc(text)
    return dt.astimezone(LOCAL_TZ) if dt else None


def fmt(text, seconds=True):
    """Stored UTC text -> 'YYYY-MM-DD HH:MM:SS' in Dubai time ('' when empty)."""
    dt = to_local(text)
    if not dt:
        return str(text or "")
    return dt.strftime("%Y-%m-%d %H:%M:%S" if seconds else "%Y-%m-%d %H:%M")


def local_input_to_utc(text, end=False):
    """A filter box value typed in Dubai time ('YYYY-MM-DD' or 'YYYY-MM-DDTHH:MM') -> stored-UTC text.
    end=True means 'up to the end of that day / minute'.  Returns None when empty or not understood."""
    text = (text or "").strip()
    if not text:
        return None
    try:
        if len(text) <= 10:
            dt = datetime.strptime(text, "%Y-%m-%d")
            if end:
                dt = dt.replace(hour=23, minute=59, second=59, microsecond=999999)
        else:
            dt = datetime.strptime(text[:16].replace(" ", "T"), "%Y-%m-%dT%H:%M")
            if end:
                dt = dt.replace(second=59, microsecond=999999)
    except ValueError:
        return None
    return dt.replace(tzinfo=LOCAL_TZ).astimezone(timezone.utc).replace(tzinfo=None).isoformat(timespec="microseconds")
