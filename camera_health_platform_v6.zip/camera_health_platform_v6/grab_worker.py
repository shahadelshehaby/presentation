"""
grab_worker.py - a small helper process started by capture.py (you never run this yourself).

Why it exists: OpenCV's FFmpeg part lets only ONE thread at a time connect to a camera, so "15 cameras at the
same time" inside one program really connected one after another.  Every capture worker therefore owns one of
these helper processes (each has its own lock), so connections truly overlap.  The helper connects to the camera,
analyses the picture and saves it, and sends back only a small result.
"""
import json
import os
import socket
import sys


def main():
    port = int(sys.argv[1])
    token = os.environ.get("GRAB_TOKEN", "")
    sock = socket.create_connection(("127.0.0.1", port), timeout=30)
    sock.settimeout(None)
    sock.sendall(token.encode().ljust(32, b" ")[:32])           # proves to capture.py that we are its helper
    import capture                                              # heavy import, done once per helper
    while True:
        data = capture.recv_message(sock)
        if data is None:                                        # capture.py closed the connection: finish
            return
        try:
            out = capture.grab_and_analyze(json.loads(data.decode("utf-8")))
        except Exception as e:                                  # never let one camera kill the helper
            out = {"error": str(e)}
        capture.send_message(sock, json.dumps(out).encode("utf-8"))


if __name__ == "__main__":
    try:
        main()
    except (OSError, KeyboardInterrupt):
        pass
