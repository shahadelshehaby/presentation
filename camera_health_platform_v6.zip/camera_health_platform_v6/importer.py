"""
Reads a camera list from an Excel (.xlsx) or CSV file.

* The header row may be anywhere in the first 15 rows, and column order does not matter.
* Header names are matched loosely ("Machine name", "machine", "MACHINE" all work).
* Required columns: Terminal, Machine, Camera, IP.
* Optional columns: Username, Password, RTSP path, Description, Active.
* Rows with a problem are reported (with their row number) and skipped; good rows are still imported.
"""
from __future__ import annotations

import csv
import io
import re

MAX_ROWS = 20000
HEADER_SCAN_ROWS = 15
DEFAULT_RTSP_PATH = "/Streaming/Channels/101"

FIELD_ALIASES = {
    "terminal": {"terminal", "terminalname", "site"},
    "machine_name": {"machine", "machinename", "equipment", "equipmentname", "asset"},
    "camera_name": {"camera", "cameraname", "name", "cameraid"},
    "ip": {"ip", "ipaddress", "cameraip", "address", "host", "ipsource"},
    "username": {"username", "user", "login", "usr"},
    "password": {"password", "pass", "pwd"},
    "rtsp_path": {"rtsppath", "rtsp", "path", "streampath", "stream"},
    "description": {"description", "desc", "notes", "note", "remarks", "remark", "comment", "comments"},
    "active": {"active", "enabled", "status", "dailyinspection"},
}
REQUIRED = ["terminal", "machine_name", "camera_name", "ip"]
LABELS = {"terminal": "Terminal", "machine_name": "Machine", "camera_name": "Camera", "ip": "IP",
          "username": "Username", "password": "Password", "rtsp_path": "RTSP path",
          "description": "Description", "active": "Active"}

TRUE_WORDS = {"1", "yes", "y", "true", "active", "enabled", "on"}
FALSE_WORDS = {"0", "no", "n", "false", "inactive", "disabled", "off"}


class ImportFileError(Exception):
    """The whole file cannot be read (wrong type, no header, ...). The message is meant for the user."""


def _norm_header(value) -> str:
    return re.sub(r"[^a-z0-9]", "", str(value or "").lower())


def _text(value, collapse=True) -> str:
    if value is None:
        return ""
    if isinstance(value, float) and value.is_integer():
        value = int(value)                              # Excel stores 5 as 5.0
    text = str(value).strip()
    return " ".join(text.split()) if collapse else text


def _read_xlsx(file_obj) -> list[tuple]:
    try:
        from openpyxl import load_workbook
    except ImportError:
        raise ImportFileError("The 'openpyxl' package is missing. Run:  py -m pip install openpyxl  and restart the platform.")
    try:
        wb = load_workbook(file_obj, read_only=True, data_only=True)
    except Exception:
        raise ImportFileError("That file could not be opened as an Excel workbook. Save it as .xlsx and try again.")
    sheet = wb["Cameras"] if "Cameras" in wb.sheetnames else wb.worksheets[0]
    rows = []
    for row in sheet.iter_rows(values_only=True):
        rows.append(row)
        if len(rows) > MAX_ROWS + HEADER_SCAN_ROWS + 5:
            break
    wb.close()
    return rows


def _read_csv(raw: bytes) -> list[tuple]:
    for encoding in ("utf-8-sig", "cp1252"):
        try:
            text = raw.decode(encoding)
            break
        except UnicodeDecodeError:
            continue
    else:
        raise ImportFileError("The CSV file's text encoding is not supported. Save it as UTF-8 CSV or as .xlsx.")
    sample = text[:4096]
    try:
        dialect = csv.Sniffer().sniff(sample, delimiters=",;\t")
    except csv.Error:
        dialect = csv.excel
    return [tuple(r) for r in csv.reader(io.StringIO(text), dialect)]


def _find_header(rows):
    """Returns (index_of_header_row, {field: column_index})."""
    best = (None, {})
    for idx, row in enumerate(rows[:HEADER_SCAN_ROWS]):
        mapping = {}
        for col, cell in enumerate(row):
            norm = _norm_header(cell)
            if not norm:
                continue
            for field, aliases in FIELD_ALIASES.items():
                if norm in aliases and field not in mapping:
                    mapping[field] = col
                    break
        if len(mapping) > len(best[1]):
            best = (idx, mapping)
    return best


def read_cameras(filename: str, raw: bytes):
    """Parse an uploaded file.
    Returns (rows, problems, info):
      rows     - valid cameras, each a dict (with 'row' = the row number in the file)
      problems - list of {'row': n, 'message': text} for rows that were skipped
      info     - {'rows_read': n, 'columns': [labels found]}"""
    name = (filename or "").lower()
    if name.endswith(".xlsx") or name.endswith(".xlsm"):
        table = _read_xlsx(io.BytesIO(raw))
    elif name.endswith(".csv"):
        table = _read_csv(raw)
    elif name.endswith(".xls"):
        raise ImportFileError("Old .xls files are not supported. In Excel choose File > Save As > Excel Workbook (.xlsx).")
    else:
        raise ImportFileError("Please upload an Excel file (.xlsx) or a CSV file.")

    header_idx, mapping = _find_header(table)
    missing = [LABELS[f] for f in REQUIRED if f not in mapping]
    if header_idx is None or missing:
        raise ImportFileError(
            "Could not find these column headers: " + ", ".join(missing or [LABELS[f] for f in REQUIRED]) +
            ". The first row of the sheet must contain the column names (download the template to see them).")

    rows, problems, seen = [], [], {}
    data_rows = table[header_idx + 1:]
    if len(data_rows) > MAX_ROWS:
        raise ImportFileError(f"The file has more than {MAX_ROWS:,} rows. Split it into smaller files.")
    rows_read = 0
    for offset, cells in enumerate(data_rows):
        row_no = header_idx + 2 + offset                          # the row number shown in Excel
        values = {f: (cells[c] if c < len(cells) else None) for f, c in mapping.items()}
        if all(_text(v) == "" for v in values.values()):
            continue                                              # blank line
        rows_read += 1
        rec = {"row": row_no}
        for field in ("terminal", "machine_name", "camera_name", "ip", "username", "rtsp_path", "description"):
            rec[field] = _text(values.get(field))
        rec["password"] = _text(values.get("password"), collapse=False)

        missing_here = [LABELS[f] for f in REQUIRED if not rec[f]]
        if missing_here:
            problems.append({"row": row_no, "message": "Missing " + ", ".join(missing_here)})
            continue
        if rec["ip"].lower().startswith("rtsp://"):
            problems.append({"row": row_no, "message":
                             "IP contains a full rtsp:// address. Put only the IP (for example 192.168.1.69) in IP "
                             "and the part after it (for example /Stream/Live/101) in RTSP path."})
            continue
        if re.search(r"\s", rec["ip"]):
            problems.append({"row": row_no, "message": f"IP '{rec['ip']}' contains a space"})
            continue
        if rec["rtsp_path"] and not rec["rtsp_path"].startswith("/"):
            rec["rtsp_path"] = "/" + rec["rtsp_path"]

        active = None
        if "active" in mapping:
            word = _text(values.get("active")).lower()
            if word in TRUE_WORDS:
                active = 1
            elif word in FALSE_WORDS:
                active = 0
            elif word:
                problems.append({"row": row_no, "message": f"Active should be Yes or No, not '{word}'"})
                continue
        rec["active"] = active

        key = tuple(" ".join(rec[f].split()).lower() for f in ("terminal", "machine_name", "camera_name"))
        if key in seen:
            problems.append({"row": row_no, "message":
                             f"Same terminal, machine and camera name as row {seen[key]} (skipped)"})
            continue
        seen[key] = row_no
        rows.append(rec)

    info = {"rows_read": rows_read, "columns": [LABELS[f] for f in LABELS if f in mapping]}
    return rows, problems, info


def build_template() -> bytes:
    """An empty, ready-to-fill Excel file (header row + a how-to sheet)."""
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Font, PatternFill
    from openpyxl.utils import get_column_letter

    wb = Workbook()
    ws = wb.active
    ws.title = "Cameras"
    headers = ["Terminal", "Machine", "Camera", "IP", "Username", "Password", "RTSP path", "Description", "Active"]
    ws.append(headers)
    fill = PatternFill("solid", fgColor="243447")
    for col, header in enumerate(headers, start=1):
        cell = ws.cell(row=1, column=col)
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = fill
        ws.column_dimensions[get_column_letter(col)].width = {"Description": 36, "RTSP path": 26, "IP": 20}.get(header, 16)
    ws.freeze_panes = "A2"
    for col in (4, 5, 6, 7):                                  # IP, username, password, path stay text
        for r in range(2, 3002):
            ws.cell(row=r, column=col).number_format = "@"

    guide = wb.create_sheet("How to fill")
    lines = [
        ("How to fill the 'Cameras' sheet", True),
        ("One camera per row. Start on row 2 (row 1 holds the column names - do not rename them).", False),
        ("", False),
        ("Required columns:", True),
        ("Terminal      e.g.  Terminal 2", False),
        ("Machine       e.g.  A203          (the machine the camera is mounted on)", False),
        ("Camera        e.g.  Overhead      (must be different for each camera on the same machine)", False),
        ("IP            e.g.  192.168.1.69  (add the port only if it is not 554:  192.168.1.69:8554)", False),
        ("", False),
        ("Optional columns:", True),
        ("Username, Password, RTSP path (only the part after the IP, e.g. /Stream/Live/101; empty = /Streaming/Channels/101),", False),
        ("Description, and Active (Yes or No; empty = Yes).", False),
        ("", False),
        ("Good to know:", True),
        ("- A camera that already exists (same Terminal + Machine + Camera) is skipped, or updated if you choose 'Update'.", False),
        ("- When updating, an empty cell keeps the camera's current value.", False),
        ("- Rows with a problem are listed after the import with their row number; all the other rows are still imported.", False),
        ("- Passwords that are only digits: keep the Password column formatted as Text so leading zeros are not lost.", False),
        ("- Do not paste a full rtsp://... address into the IP column.", False),
    ]
    for text, bold in lines:
        guide.append([text])
        guide.cell(row=guide.max_row, column=1).font = Font(bold=bold)
        guide.cell(row=guide.max_row, column=1).alignment = Alignment(wrap_text=False)
    guide.column_dimensions["A"].width = 110
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()
