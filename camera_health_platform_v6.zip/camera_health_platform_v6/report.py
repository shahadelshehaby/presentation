"""
PDF report: ONE landscape table, one row per inspection (not one page per
camera). Columns: # | Terminal | Equipment type | Machine | Camera |
IP / source | Inspected (Dubai) | Status | Learned conf. | Verdict | Image

- Company logo (static/logo.png or .jpg) sits top-left of the title block.
- Terminal / Equipment type columns appear only if your cameras have those
  fields filled in; otherwise they are left out and the space is shared.
- Screenshots are shrunk to small thumbnails so big batches stay small.
- Uses Segoe UI when installed (Windows), otherwise Helvetica.
"""
from __future__ import annotations

import io
import os
from collections import Counter
from datetime import datetime
from xml.sax.saxutils import escape

from PIL import Image as PILImage
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_RIGHT
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.utils import ImageReader
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (SimpleDocTemplate, Table, TableStyle, Paragraph,
                                 Spacer, Image as RLImage)

import db
import timeutil

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
REPORT_DIR = os.path.join(BASE_DIR, "reports")
os.makedirs(REPORT_DIR, exist_ok=True)

# ---- Settings you may want to change ---------------------------------------
LOGO_HEIGHT_PT = 48          # logo height in the PDF header (points)
THUMB_W, THUMB_H = 108, 61   # screenshot thumbnail box in the table (points)

# ---- Colours ------------------------------------------------------------------
TEXT = colors.HexColor("#2C2C2A")
TEXT2 = colors.HexColor("#5F5E5A")
NAVY = colors.HexColor("#243447")
ZEBRA = colors.HexColor("#F5F7FA")
GRID = colors.HexColor("#C5CFDA")
SUBTLE = colors.HexColor("#5B6B7F")
AUTO_BLUE = colors.HexColor("#5B5FAF")
STATUS_BG = {"ok": colors.HexColor("#E1F0E5"),
             "attention": colors.HexColor("#FDEFDC"),
             "error": colors.HexColor("#FBE4E4")}

STATUS_LABELS = {
    "OK": "OK", "NO_VIEW": "No view", "TOO_DARK": "Too dark", "OVEREXPOSED": "Overexposed",
    "COLOR_CAST_GREEN": "Green tint", "COLOR_CAST_BLUE": "Blue tint", "COLOR_CAST_RED": "Red tint",
    "DIRTY_OR_BLURRY": "Dirty / blurry lens", "PARTIAL_OCCLUSION": "Partial occlusion",
}
VERDICT_LABELS = {
    "same": "Same as detected", "normal": "Normal / false detection",
    "old_camera": "Old camera (expected for this unit)", "other": "Other issue",
}
REASON_LABELS = {"OLD_CAMERA": "Old camera", "OK": "OK (scene caused it)"}


# ---- Fonts ---------------------------------------------------------------------
def _register_fonts(fonts_dir=None):
    fonts_dir = fonts_dir or os.path.join(os.environ.get("WINDIR", r"C:\Windows"), "Fonts")
    files = {"SegoeUI": "segoeui.ttf", "SegoeUI-Bold": "segoeuib.ttf",
             "SegoeUI-Italic": "segoeuii.ttf", "SegoeUI-BoldItalic": "segoeuiz.ttf"}
    try:
        for name, fname in files.items():
            pdfmetrics.registerFont(TTFont(name, os.path.join(fonts_dir, fname)))
        pdfmetrics.registerFontFamily("SegoeUI", normal="SegoeUI", bold="SegoeUI-Bold",
                                      italic="SegoeUI-Italic", boldItalic="SegoeUI-BoldItalic")
        return "SegoeUI", "SegoeUI-Bold"
    except Exception:
        return "Helvetica", "Helvetica-Bold"


FONT, FONT_BOLD = _register_fonts()


def _styles():
    cell = ParagraphStyle("cell", fontName=FONT, fontSize=8, leading=10, textColor=TEXT)
    return {
        "title": ParagraphStyle("title", fontName=FONT_BOLD, fontSize=17, leading=21, textColor=colors.black),
        "sub": ParagraphStyle("sub", fontName=FONT, fontSize=9, leading=12, textColor=SUBTLE),
        "head": ParagraphStyle("head", fontName=FONT_BOLD, fontSize=8, leading=10, textColor=colors.white),
        "cell": cell,
        "right": ParagraphStyle("right", parent=cell, alignment=TA_RIGHT),
        "center": ParagraphStyle("center", parent=cell, alignment=TA_CENTER, textColor=TEXT2),
    }


# ---- Small helpers ---------------------------------------------------------------
def _e(value):
    """Escape text coming from the database so it can't break the PDF markup."""
    return escape("" if value is None else str(value))


def _first(d: dict, *keys):
    for k in keys:
        v = d.get(k)
        if v not in (None, ""):
            return v
    return ""


def _sev(status):
    return "ok" if status == "OK" else ("error" if status == "NO_VIEW" else "attention")


def _logo():
    """Company logo, keeping its proportions (PNG/JPG only). None if not found."""
    for name in ("logo.png", "logo.jpg", "logo.jpeg"):
        path = os.path.join(BASE_DIR, "static", name)
        if os.path.exists(path):
            try:
                w, h = ImageReader(path).getSize()
                return RLImage(path, width=LOGO_HEIGHT_PT * w / h, height=LOGO_HEIGHT_PT)
            except Exception:
                return None
    return None


def _thumbnail(path, styles):
    """Small JPEG thumbnail that fits the box while keeping proportions."""
    if not path or not os.path.exists(path):
        return Paragraph("No image", styles["center"])
    try:
        with PILImage.open(path) as im:
            im = im.convert("RGB")
            im.thumbnail((320, 180))
            w, h = im.size
            buf = io.BytesIO()
            im.save(buf, "JPEG", quality=80)
        buf.seek(0)
        scale = min(THUMB_W / w, THUMB_H / h)
        return RLImage(buf, width=w * scale, height=h * scale)
    except Exception:
        return Paragraph("Image unavailable", styles["center"])


def _footer(canvas, doc):
    canvas.saveState()
    canvas.setFont(FONT, 7)
    canvas.setFillColor(SUBTLE)
    canvas.drawString(doc.leftMargin, 24, "Camera Health Platform - inspection report")
    canvas.drawRightString(doc.pagesize[0] - doc.rightMargin, 24, f"Page {doc.page}")
    canvas.restoreState()


# ---- Report building ----------------------------------------------------------------
def _load_items(inspection_ids):
    fb_map = db.get_feedback_by_inspection_ids(list(inspection_ids))
    items = []
    for iid in inspection_ids:
        insp = db.get_inspection(iid)
        if not insp:
            continue
        cam = db.get_camera(insp["camera_id"]) or {}
        items.append((insp, cam, fb_map.get(iid)))
    return items


def _header_block(items, styles):
    verified = sum(1 for _, _, fb in items if fb)
    counts = Counter((i.get("final_status") or i["status"]) for i, _, _ in items)
    n = len(items)
    line1 = (f"Generated {timeutil.now_local():%Y-%m-%d %H:%M} | {n} inspection{'' if n == 1 else 's'} | "
             f"{verified} verified, {n - verified} pending")
    line2 = " | ".join(f"{STATUS_LABELS.get(s, s)}: {c}" for s, c in counts.most_common())

    text = [Paragraph("Camera Inspection Report", styles["title"]),
            Paragraph(_e(line1), styles["sub"]),
            Paragraph(_e(line2), styles["sub"])]
    logo = _logo()
    if not logo:
        return text + [Spacer(1, 10)]
    head = Table([[logo, text]], colWidths=[logo.drawWidth + 14, None])
    head.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                              ("LEFTPADDING", (0, 0), (-1, -1), 0),
                              ("RIGHTPADDING", (0, 0), (-1, -1), 0),
                              ("TOPPADDING", (0, 0), (-1, -1), 0),
                              ("BOTTOMPADDING", (0, 0), (-1, -1), 0)]))
    head.hAlign = "LEFT"
    return [head, Spacer(1, 12)]


def _build_table(items, styles, available_width):
    show_terminal = any(_first(c, "terminal", "terminal_name") for _, c, _ in items)
    show_equipment = any(_first(c, "equipment_type", "equipment", "equipment_name") for _, c, _ in items)

    # (key, header, base width in points)
    cols = [("num", "#", 20)]
    if show_terminal:
        cols.append(("terminal", "Terminal", 51))
    if show_equipment:
        cols.append(("equipment", "Equipment type", 52))
    cols += [("machine", "Machine", 54), ("camera", "Camera", 62), ("ip", "IP / source", 75),
             ("time", "Inspected (Dubai)", 60), ("status", "Status", 51), ("conf", "Learned conf.", 42),
             ("verdict", "Verdict", 66)]
    image_w = THUMB_W + 8
    base_total = sum(w for _, _, w in cols)
    scale = (available_width - image_w) / base_total      # share any spare room
    widths = [w * scale for _, _, w in cols] + [image_w]
    keys = [k for k, _, _ in cols] + ["image"]

    data = [[Paragraph(_e(h), styles["head"]) for _, h, _ in cols] + [Paragraph("Image", styles["head"])]]
    for n, (insp, cam, fb) in enumerate(items, start=1):
        ts = timeutil.fmt(insp.get("timestamp"))              # stored in UTC, shown in Dubai time
        when = f"{_e(ts[:10])}<br/>{_e(ts[11:19])}"
        conf = insp.get("learned_confidence")                 # the report shows the learned confidence only
        if fb:
            verdict = _e(VERDICT_LABELS.get(fb["verdict"], fb["verdict"]))
            if fb.get("reason"):
                verdict += "<br/>Reason: " + _e(REASON_LABELS.get(fb["reason"], STATUS_LABELS.get(fb["reason"], fb["reason"])))
            if insp.get("auto_matched"):
                verdict += f'<br/><font size="6.5" color="{AUTO_BLUE.hexval().replace("0x", "#")}"><i>(auto-matched)</i></font>'
        else:
            verdict = f'<font color="{TEXT2.hexval().replace("0x", "#")}"><i>Pending</i></font>'
            if insp.get("worse_flag"):
                verdict += '<br/><font size="6.5" color="#A32D2D"><i>(worse than last check)</i></font>'
        cells = {
            "num": Paragraph(str(n), styles["right"]),
            "terminal": Paragraph(_e(_first(cam, "terminal", "terminal_name")), styles["cell"]),
            "equipment": Paragraph(_e(_first(cam, "equipment_type", "equipment", "equipment_name")), styles["cell"]),
            "machine": Paragraph(_e(cam.get("machine_name")), styles["cell"]),
            "camera": Paragraph(_e(cam.get("camera_name")), styles["cell"]),
            "ip": Paragraph(_e(cam.get("ip")), styles["cell"]),
            "time": Paragraph(when, styles["cell"]),
            "status": Paragraph(_e(STATUS_LABELS.get(insp.get("final_status") or insp["status"],
                                                    insp.get("final_status") or insp["status"])), styles["cell"]),
            "conf": Paragraph(f"{conf:.1f}%" if conf is not None else "-", styles["right"]),
            "verdict": Paragraph(verdict, styles["cell"]),
            "image": _thumbnail(insp.get("image_path"), styles),
        }
        data.append([cells[k] for k in keys])

    table = Table(data, colWidths=widths, repeatRows=1)
    status_col = keys.index("status")
    cmds = [
        ("BACKGROUND", (0, 0), (-1, 0), NAVY),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, ZEBRA]),
        ("INNERGRID", (0, 0), (-1, -1), 0.5, GRID),
        ("BOX", (0, 0), (-1, -1), 0.5, GRID),
        ("LEFTPADDING", (0, 0), (-1, -1), 4), ("RIGHTPADDING", (0, 0), (-1, -1), 4),
        ("TOPPADDING", (0, 0), (-1, -1), 4), ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
    ]
    for r, (insp, _, _) in enumerate(items, start=1):
        cmds.append(("BACKGROUND", (status_col, r), (status_col, r), STATUS_BG[_sev(insp.get("final_status") or insp["status"])]))
    table.setStyle(TableStyle(cmds))
    return table


def _build_pdf(path, inspection_ids):
    items = _load_items(inspection_ids)
    styles = _styles()
    doc = SimpleDocTemplate(path, pagesize=landscape(A4), leftMargin=28, rightMargin=28,
                            topMargin=34, bottomMargin=40, title="Camera Inspection Report")
    available = doc.pagesize[0] - doc.leftMargin - doc.rightMargin
    story = _header_block(items, styles)
    if items:
        story.append(_build_table(items, styles, available))
    else:
        story.append(Paragraph("No inspections to show.", styles["cell"]))
    doc.build(story, onFirstPage=_footer, onLaterPages=_footer)
    return path


def generate_batch_report(inspection_ids: list[int], filename: str | None = None) -> str:
    """One table covering all the given inspections (in the order given)."""
    filename = filename or f"camera_report_{timeutil.now_local():%Y%m%d_%H%M%S}.pdf"
    return _build_pdf(os.path.join(REPORT_DIR, filename), inspection_ids)


def generate_single_report(inspection_id: int) -> str:
    """Same layout as the batch report, with just one row."""
    return _build_pdf(os.path.join(REPORT_DIR, f"report_inspection_{inspection_id}.pdf"), [inspection_id])
