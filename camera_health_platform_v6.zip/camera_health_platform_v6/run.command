#!/bin/bash
# macOS double-click launcher for the Camera Health Platform.
cd "$(dirname "$0")"
python3 run.py
