"""
Generates synthetic sample images (one per detectable condition) plus a short
test video, so the platform can be tried without real cameras.

    python generate_test_images.py

Then in Settings add a camera with IP, for example:
    testimg:test_images/green_tint.jpg     (always that one image)
    video:test_images/test_video.mp4       (random frame each capture)
"""
import os
import cv2
import numpy as np

OUT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "test_images")
W, H = 960, 540
rng = np.random.default_rng(42)


def base_scene(seed=0):
    """A busy, sharp 'industrial' scene with detail in every part of the frame."""
    r = np.random.default_rng(seed)
    img = np.full((H, W, 3), 120, np.uint8)
    # gradient sky/floor
    for y in range(H):
        img[y, :] = (110 + y * 60 // H, 115 + y * 50 // H, 120 + y * 40 // H)
    # structural beams, boxes, pipes everywhere
    for _ in range(140):
        x, y = int(r.integers(0, W)), int(r.integers(0, H))
        w, h = int(r.integers(15, 120)), int(r.integers(15, 120))
        c = tuple(int(v) for v in r.integers(30, 230, 3))
        cv2.rectangle(img, (x, y), (x + w, y + h), c, -1)
        cv2.rectangle(img, (x, y), (x + w, y + h), (20, 20, 20), 2)
    for _ in range(60):
        p1 = (int(r.integers(0, W)), int(r.integers(0, H)))
        p2 = (int(r.integers(0, W)), int(r.integers(0, H)))
        cv2.line(img, p1, p2, tuple(int(v) for v in r.integers(0, 255, 3)), 2)
    for i in range(0, W, 120):
        cv2.putText(img, f"BAY-{i // 120}", (i + 5, H - 15), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (240, 240, 240), 2)
    noise = r.normal(0, 6, img.shape)
    return np.clip(img.astype(np.float32) + noise, 0, 255).astype(np.uint8)


def tint(img, channel, gain):
    out = img.astype(np.float32)
    for c in range(3):
        out[:, :, c] *= gain if c == channel else 0.75
    return np.clip(out, 0, 255).astype(np.uint8)


def make_images():
    os.makedirs(OUT_DIR, exist_ok=True)
    scene = base_scene(1)
    images = {
        "normal": scene,
        "no_view": np.full((H, W, 3), 16, np.uint8),
        "dark": np.clip(scene.astype(np.float32) * 0.12, 0, 255).astype(np.uint8),
        "overexposed": np.clip(scene.astype(np.float32) * 0.3 + 215, 0, 255).astype(np.uint8),
        "green_tint": tint(scene, 1, 1.35),
        "blue_tint": tint(scene, 0, 1.35),
        "red_tint": tint(scene, 2, 1.35),
        "blurry": cv2.GaussianBlur(scene, (0, 0), 6),
    }
    occluded = scene.copy()
    # something (mud, a tarp, a cable) covering the left ~60% of the lens
    occluded[:, : int(W * 0.6)] = cv2.GaussianBlur(occluded[:, : int(W * 0.6)], (0, 0), 25)
    occluded[:, : int(W * 0.6)] = (occluded[:, : int(W * 0.6)] * 0.5 + 40).astype(np.uint8)
    images["occluded"] = occluded

    for name, img in images.items():
        path = os.path.join(OUT_DIR, f"{name}.jpg")
        cv2.imwrite(path, img, [cv2.IMWRITE_JPEG_QUALITY, 92])
        print("wrote", path)


def make_video(seconds=15, fps=8, size=(640, 360)):
    """A camera on a moving machine: the scene pans, and for a few seconds the
    lens gets dirty, then dark — so random frames hit different diagnoses."""
    path = os.path.join(OUT_DIR, "test_video.mp4")
    wide = np.concatenate([base_scene(2), base_scene(3)], axis=1)
    vw = cv2.VideoWriter(path, cv2.VideoWriter_fourcc(*"mp4v"), fps, size)
    total = seconds * fps
    for i in range(total):
        x = int((wide.shape[1] - W) * i / total)
        frame = wide[:, x:x + W].copy()
        t = i / total
        if 0.55 < t < 0.70:
            frame = cv2.GaussianBlur(frame, (0, 0), 6)          # dirty lens
        elif 0.80 < t < 0.90:
            frame = (frame * 0.1).astype(np.uint8)              # lights off
        vw.write(cv2.resize(frame, size, interpolation=cv2.INTER_AREA))
    vw.release()
    print("wrote", path)


if __name__ == "__main__":
    make_images()
    make_video()
    print("\nDone. Use these in Settings, e.g. IP = testimg:test_images/blurry.jpg")
