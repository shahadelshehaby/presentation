# Camera Health Platform — Project Description

## What this is
A local, offline web application that monitors IP camera health for
cameras mounted on movable objects (so the view isn't fixed/consistent).
It captures a daily screenshot per camera, runs classical computer-vision
diagnosis on it, and lets an engineer verify/correct the result — with the
system learning from that feedback over time, per camera.

Runs entirely on the local network. No cloud services, no external APIs,
no internet dependency at runtime (only needed once, to `pip install`
dependencies).

## Problem it solves
- Cameras are on movable machinery, so a fixed background-reference
  approach (typical for static CCTV health checks) doesn't work.
- Detects: no view / signal loss, too dark, overexposed, green tint, blue
  tint, dirty or blurry lens, partial occlusion, and OK.
- Different camera models (e.g. old 2K vs. new Hikvision 4K) naturally
  produce different baseline image statistics, so fixed global thresholds
  cause false positives (e.g. an old camera's normal softness gets flagged
  as "dirty"). The system addresses this by learning per-camera from
  engineer feedback rather than relying on one global threshold set.

## How it works, end to end
1. **Settings tab** — add a camera: terminal, equipment type, machine
   name, camera name, IP, username, password, RTSP path, description.
2. **Scheduler** — each active camera gets a daily capture job, staggered
   across a window (default 30 minutes from 9:00 AM local time, editable
   in the Settings tab and stored in the database), so cameras aren't all
   polled simultaneously (avoids network overload). An optional lightweight
   hourly "connectivity ping" (no full analysis) can also be enabled to
   catch drops between daily captures.
3. **Capture** — grabs one frame from the camera's RTSP stream via OpenCV
   (RTSP over TCP, a few warm-up frames skipped, 10 s connect timeout)
   and saves it as a JPEG. For testing, the IP field also accepts
   `video:<file>` (random frame from a local video), `testimg:<file>`,
   `host:port`, or a full `rtsp://` URL.
4. **Diagnosis engine** (classical CV, no ML model / no internet needed):
   - No view: near-uniform frame (very low pixel std-dev), or the stream
     couldn't be read at all.
   - Too dark / overexposed: mean brightness thresholds.
   - Color cast (green/blue/red tint): per-channel (B/G/R) mean ratio
     comparison.
   - Dirty/blurry lens: Laplacian variance (a focus/sharpness measure).
   - Partial occlusion: the frame is split into a grid and sharpness is
     compared cell-to-cell — catches something blocking part of the lens
     that a whole-frame average would miss.
   - Each detection also gets a heuristic 50–99.9% "confidence" score
     based on how far past the decision threshold the measured value is
     (not a statistical probability — a relative signal for engineers).
5. **Diagnose tab** — shows every inspection: photo, detected status,
   confidence, and full metrics. Filterable by status, terminal, equipment
   type, machine, camera, verdict (incl. Pending) and date range; sortable
   by time, confidence, status, terminal, equipment type, machine, camera.
   The **Capture now** button captures only active cameras matching the
   Terminal / Equipment type / Machine / Camera dropdowns, one at a time,
   with a lock so two manual runs can't overlap.
6. **Engineer verification** — for any inspection, an engineer picks one
   of: *Same as detected*, *Normal / false positive*, *Old camera
   (expected for this unit)*, *Other issue*, plus a free-text comment and
   their name.
7. **Per-camera learning (auto-match)** — before storing a new inspection,
   the system looks at that SAME camera's past inspections with the SAME
   detected status. If an engineer already verified one of those, and the
   new image's metrics (brightness, focus, color ratio, dominant channel)
   are close enough (within tolerance) to that past one, the old verdict
   is copied forward automatically and flagged "auto-matched" — still
   visible and editable by an engineer, never silently hidden. This
   matching is always scoped to a single camera, so different camera
   models never share thresholds or history.
8. **Reports** — landscape PDF table, one row per inspection (terminal,
   equipment type, machine, camera, IP, time, status, confidence, verdict,
   engineer, remark) with a downscaled photo in the last column, about 6
   rows per page. For one inspection, the selected ones, or all inspections
   matching the current filters. CSV export of everything. Credentials in
   `rtsp://` URLs are masked everywhere they are displayed.

The dashboard runs at **http://127.0.0.1:5002**.

## Tech stack
- **Backend**: Python, Flask (routes/views), SQLite (storage — cameras,
  inspections, feedback tables), APScheduler (staggered daily capture
  jobs).
- **Computer vision**: OpenCV (`opencv-python-headless`) + NumPy —
  brightness, Laplacian sharpness, per-channel color ratios, grid-based
  sharpness map.
- **Frontend**: server-rendered Jinja2 templates + a small hand-written
  CSS file (no CDN dependency, by design, to keep the app fully offline).
- **Reports**: ReportLab (PDF generation).
- **Launcher**: `run.py` auto-installs any missing pip packages, starts
  the Flask app + scheduler, and opens the browser automatically.
  `run.bat` (Windows) / `run.command` (Mac) are double-click wrappers
  around it; `run.bat` prefers the `py` launcher over `python` to avoid
  PATH-order issues with multiple installed Python versions.

## File map

| File | Purpose |
|---|---|
| `app.py` | Flask app: all routes for Settings tab and Diagnose tab, scheduler wiring |
| `db.py` | SQLite schema, automatic in-place migration of older databases, all data access (cameras, inspections, feedback, capture schedule), credential masking |
| `diagnosis.py` | The CV diagnosis engine — analyzes one image, returns status/confidence/metrics; also the metric-similarity function used for auto-matching |
| `capture.py` | Frame capture (RTSP, `host:port`, full `rtsp://` URL, `video:` file, `testimg:` image), the staggered scheduler builder (reads schedule from DB, wraps past midnight), and the per-camera auto-match logic that runs on every new inspection |
| `report.py` | PDF report as a landscape table, one row per inspection, image in last column (ReportLab) |
| `run.py` | Single entry point: installs missing deps, starts the app, opens the browser |
| `run.bat` / `run.command` | Windows/Mac double-click launchers wrapping `run.py` |
| `start_test_camera.bat` | Loops a video file as a live RTSP camera via MediaMTX + ffmpeg, for realistic testing |
| `generate_test_images.py` | Generates synthetic sample images (one per detectable condition) for offline testing without real cameras |
| `test_images/*` | Pre-generated samples: normal, no_view, dark, overexposed, green/blue/red tint, blurry, occluded, plus `test_video.mp4` |
| `requirements.txt` | Python dependencies: flask, opencv-python-headless, numpy, apscheduler, reportlab |
| `templates/base.html` | Shared layout, nav tabs, flash messages |
| `templates/settings.html` | Add/list/enable-disable/delete cameras, "test capture now" |
| `templates/diagnose.html` | Filter/sort bar, inspection cards (photo, status, confidence, metrics, engineer verdict form), report download, batch export |
| `static/style.css` | Hand-written CSS, no external/CDN dependency |
| `README.md` | Setup instructions, how the learning/auto-match logic works, testing-without-cameras walkthrough |

## Known limitations / things to harden before wider production use
- Camera passwords are stored in plaintext in the SQLite file — should be
  encrypted at rest or moved to a secrets manager for production.
- Uses Flask's built-in dev server — fine for local/LAN use; swap to a
  proper WSGI server (gunicorn/waitress) if exposing more broadly.
- RTSP path defaults to a Hikvision-style path
  (`/Streaming/Channels/101`); adjust per camera brand in Settings.
- Thresholds in `diagnosis.py`'s `CONFIG` dict are starting points — the
  auto-match/learning system is what actually adapts per camera as
  engineers verify results over time.
